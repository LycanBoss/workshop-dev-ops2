# SecureAccess City

Controle de acesso físico aos prédios públicos de uma cidade inteligente. Catracas e portas leem crachás ou digitais e perguntam a uma API se a pessoa pode entrar. A API decide, registra cada tentativa e transforma comportamentos suspeitos em alertas: força bruta na leitora, crachá clonado testado em vários prédios, crachá revogado, porta forçada, entrada de carona e sabotagem do leitor.

- **Front:** Python (Flask), painel do operador.
- **Back:** Node.js, API de controle de acesso.
- **Banco:** MySQL 8.4.
- **Implantação:** Kubernetes (MicroK8s na AWS) com chart Helm próprio, ambientes de homologação e produção.
- **Foco:** DevSecOps, com gestão de segredos, análise de dependências e auditoria (SIEM).

> Todos os nomes e documentos dos dados de demonstração são fictícios. Os documentos começam com `000` para deixar claro que não são CPFs reais.

## Estrutura

```
secureaccess-city/
├── api/                      API em Node.js (sem framework; só o driver mysql2)
│   ├── src/                  servidor, regras de acesso, JWT, criptografia, logs, simulador
│   ├── db/migrations/        esquema do MySQL (aplicado pela própria API)
│   ├── test/                 testes de integração (node --test)
│   └── Dockerfile
├── web/                      front em Python (Flask + gunicorn)
│   ├── templates/  static/   páginas, CSS e JS (sem CDN externa)
│   ├── tests/                testes (unittest)
│   └── Dockerfile
├── helm/secureaccess/        chart Helm
│   ├── Chart.yaml            dependência do subchart MySQL
│   ├── values.yaml           valores padrão, documentados
│   ├── values-staging.yaml   homologação
│   ├── values-prod.yaml      produção
│   ├── templates/            api, web, simulador, ingress, secret, networkpolicy, hpa, quota...
│   └── charts/mysql/         subchart do banco (StatefulSet + volume)
├── observability/            rsyslog, logrotate e painel do Grafana (SIEM)
├── scripts/                  instalador da EC2, build com scan, deploy e demo de upgrade/rollback
├── .github/workflows/        pipeline DevSecOps (GitHub Actions)
├── docker-compose.yml        ambiente local completo
└── docs/relatorio-tecnico.md roteiro do relatório, com os problemas reais enfrentados
```

> Ao entregar no repositório da disciplina, renomeie a pasta e os arquivos conforme a convenção definida pelo professor em `desafios/`.

## Arquitetura

```mermaid
flowchart LR
  subgraph Internet
    C["Celular dos avaliadores"]
    T["Catracas reais (futuro)"]
  end
  subgraph EC2["EC2 Ubuntu + MicroK8s"]
    I["Traefik + cert-manager<br/>HTTPS Let's Encrypt"]
    subgraph NS["namespace secureaccess-prod (release Helm)"]
      W["Front Python<br/>Flask"]
      A["API Node<br/>regras, JWT, criptografia"]
      S["Simulador de catracas"]
      M[("MySQL 8.4<br/>dados pessoais cifrados")]
    end
    R["rsyslog do nó<br/>/var/log/secureaccess"]
    O["Loki + Prometheus + Grafana"]
  end
  GH["GitHub Actions<br/>Gitleaks, npm audit, pip-audit, Trivy"] -->|"imagem aprovada"| REG["Registro de imagens"]
  C -->|HTTPS| I --> W --> A --> M
  T -->|"HTTPS /api"| I --> A
  S --> A
  A -->|"syslog UDP"| R
  A -->|"logs JSON e métricas"| O
```

O navegador conversa só com o front. O front guarda o token da API numa sessão assinada (cookie HttpOnly) e chama a API de servidor para servidor, então nenhum JavaScript da página tem acesso ao token.

## Como os três pilares de DevSecOps foram atendidos

| Pilar | O que foi feito | Onde está |
|---|---|---|
| **Gestão de segredos** | Rotação obrigatória e automática das chaves que assinam os JWT (15 min em homologação, 60 min em produção), com `kid` no token: a chave antiga para de assinar, mas continua validando tokens já emitidos até expirarem. Rotação manual pelo painel. Segredos das chaves cifrados no banco com uma chave mestra (KEK) que vem do Secret do Kubernetes. Nome e documento dos cidadãos cifrados com AES-256-GCM por campo. Busca por documento via índice cego (HMAC). Senhas com scrypt. Tokens curtos. Cada pod recebe só os segredos de que precisa. | `api/src/keyring.js`, `api/src/crypto.js`, `helm/.../templates/secret.yaml`, tela **Segurança** |
| **Análise de dependências** | Pipeline que roda Gitleaks, testes, `npm audit`, `pip-audit` e Trivy no código antes de gerar a imagem. Depois, Trivy na imagem bloqueia a publicação se houver CVE alta ou crítica com correção. Gera SBOM (CycloneDX). Dependabot abre PRs de atualização. Versões fixadas, `npm --ignore-scripts`, imagens finais sem npm nem pip. | `.github/workflows/devsecops.yml`, `scripts/build-local.sh`, `.github/dependabot.yml` |
| **Auditoria (SIEM)** | Todo evento vira log JSON estruturado (`category`, `event`, porta, crachá, motivo), sem nomes de pessoas. Tentativas negadas, alertas de invasão e falhas de login também saem por syslog (RFC 5424, facility 13, "log audit") para o rsyslog do nó. Métricas Prometheus. Trilha de auditoria no banco (quem fez o quê, de onde). Painel Grafana pronto. | `api/src/services/`, `api/src/logger.js`, `observability/` |

Outros controles: NetworkPolicy (só a API fala com o banco), contêineres sem root e com sistema de arquivos somente leitura, sem token de service account montado, CSP sem `unsafe-inline`, proteção CSRF, bloqueio de conta após 5 senhas erradas, limitação de requisições, HSTS em produção, cota de recursos por namespace e Secret mantido mesmo após `helm uninstall` (sem ele os dados cifrados ficariam ilegíveis).

**Sobre "criptografia de ponta a ponta":** o tráfego é cifrado do celular ou da catraca até o cluster (TLS) e os dados pessoais ficam cifrados em repouso, com a chave fora do banco. Dentro do cluster, do Traefik até os pods, o tráfego é HTTP, isolado por NetworkPolicy. Para TLS também nesse trecho, o passo seguinte é um service mesh com mTLS (Linkerd ou Istio), que o próprio material da disciplina indica como estudo avançado.

## Rodar localmente

Com Docker instalado:

```bash
docker compose up --build
```

Painel em <http://localhost:8000>, usuário `admin`, senha `Admin@SecureAccess1` (só em desenvolvimento).

Testes automatizados, sem banco nem Docker:

```bash
cd api && npm test                                   # 18 testes da API
cd web && pip install -r requirements.txt && python -m unittest discover -s tests   # 13 testes do front
```

## Implantar no MicroK8s da AWS

### Instalação em um comando

Na EC2 (Ubuntu 24.04, pelo menos 4 GB de RAM, portas 80 e 443 liberadas no grupo de segurança e o domínio do DuckDNS apontando para o IP elástico), copie o projeto e rode:

```bash
sudo apt install -y unzip && unzip secureaccess-city.zip && cd secureaccess-city
bash scripts/instalar-ec2.sh meudesafio.duckdns.org seu@email.com
```

O instalador confere a máquina, ativa os addons do MicroK8s, instala Docker e Helm se faltarem, confere o DNS, cria o emissor de certificados, configura o rsyslog, gera e analisa as imagens e faz o deploy de produção e homologação com Helm. No fim, mostra o endereço e as senhas. Pode ser executado de novo sem problema.

Opções: `SEM_STAGING=1` instala só a produção; `SCAN=0` pula a análise de vulnerabilidades (só para destravar, e registre isso no relatório); um terceiro argumento define o domínio da homologação.

As seções abaixo explicam o que o instalador faz, passo a passo, caso você prefira executar manualmente.

### Passo a passo manual

Pré-requisito: a VM já preparada, com MicroK8s, os addons `hostpath-storage ingress metrics-server cert-manager dashboard registry`, `kubectl` apontando para o cluster (`microk8s config > ~/.kube/config`) e o grupo de segurança liberando as portas 80 e 443.

### 1. Ferramentas na VM

```bash
sudo snap install helm --classic
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER && newgrp docker
```

### 2. Código na VM

```bash
git clone https://github.com/<seu-usuario>/secureaccess-city.git
cd secureaccess-city
```

### 3. Gerar, escanear e publicar as imagens

```bash
bash scripts/build-local.sh 1.0.0
```

O script escaneia o código, gera as duas imagens, escaneia cada imagem e só envia para o registro local do MicroK8s (`localhost:32000`) se nada alto ou crítico for encontrado.

Na primeira vez, gere o `package-lock.json` para o build ficar reproduzível, e faça commit dele:

```bash
cd api && docker run --rm -v "$PWD:/app" -w /app node:22.22-alpine npm install --package-lock-only --ignore-scripts && cd ..
```

### 4. Emissor de certificados (uma vez por cluster)

```bash
cat <<EOF | kubectl apply -f -
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: seu@email.com
    privateKeySecretRef:
      name: letsencrypt-key
    solvers:
      - http01:
          ingress:
            ingressClassName: traefik
EOF
```

### 5. Domínios

No DuckDNS, aponte `meudesafio.duckdns.org` para o IP elástico. Subdomínios como `staging.meudesafio.duckdns.org` normalmente resolvem para o mesmo IP; confira com `getent hosts staging.meudesafio.duckdns.org`. Se não resolver, crie um segundo subdomínio no DuckDNS para a homologação.

### 6. Deploy dos dois ambientes

```bash
bash scripts/deploy.sh staging staging.meudesafio.duckdns.org 1.0.0
bash scripts/deploy.sh prod meudesafio.duckdns.org 1.0.0
```

O script roda `helm lint`, `helm upgrade --install --wait`, o teste de fumaça (`helm test`) e mostra o histórico de revisões.

### 7. Senha do administrador

```bash
kubectl -n secureaccess-prod get secret sa-prod-secrets -o jsonpath='{.data.ADMIN_PASSWORD}' | base64 -d; echo
```

Os usuários `operador` e `auditor` têm senhas próprias no mesmo Secret (`OPERATOR_PASSWORD`, `AUDITOR_PASSWORD`).

### 8. Conferir

```bash
kubectl -n secureaccess-prod get pods,svc,ingress,hpa,networkpolicy
kubectl -n secureaccess-prod logs deploy/sa-prod-api | grep -E 'MIGRACAO_APLICADA|API_PRONTA'
kubectl -n secureaccess-prod get certificate
```

Abra `https://meudesafio.duckdns.org` no celular.

### Usando o GitHub Container Registry em vez do registro local

Com o pipeline publicando em `ghcr.io/<seu-usuario>`, troque o registro no deploy:

```bash
helm upgrade --install sa-prod ./helm/secureaccess -n secureaccess-prod --create-namespace \
  -f helm/secureaccess/values-prod.yaml --set ingress.host=meudesafio.duckdns.org \
  --set image.registry=ghcr.io/<seu-usuario> --set image.tag=<sha-curto>
```

Os pacotes do GHCR nascem privados. Torne-os públicos nas configurações do pacote ou crie um `imagePullSecret` e informe em `image.pullSecrets`.

## Syslog no nó (rsyslog)

Os valores de homologação e produção usam `api.syslog.mode: node`: a API envia os eventos de segurança por UDP para o rsyslog do próprio nó.

```bash
sudo install -d -o syslog -g adm -m 0750 /var/log/secureaccess
sudo cp observability/rsyslog-secureaccess.conf /etc/rsyslog.d/30-secureaccess.conf
sudo cp observability/logrotate-secureaccess /etc/logrotate.d/secureaccess
sudo systemctl restart rsyslog
sudo tail -f /var/log/secureaccess/seguranca.log
```

`eventos.log` recebe tudo; `seguranca.log` só negações, alertas e falhas. Não abra a porta 514 no grupo de segurança. O arquivo já traz, comentado, o encaminhamento com fila para o Sentinela ou outro SIEM.

## Grafana, Loki e Prometheus

```bash
microk8s enable observability
```

O addon instala Prometheus, Loki e Grafana no namespace `observability` e já coleta os logs de todos os pods. Em produção o chart cria um ServiceMonitor para as métricas da API.

1. Descubra a senha do Grafana: `kubectl -n observability get secret kube-prom-stack-grafana -o jsonpath='{.data.admin-password}' | base64 -d; echo` (o nome do Secret pode variar; liste com `kubectl -n observability get secrets`).
2. Acesse com um túnel, sem expor o Grafana na internet: `kubectl -n observability port-forward svc/kube-prom-stack-grafana 3000:80` e, no seu computador, `ssh -L 3000:localhost:3000 ubuntu@<ip>`.
3. Importe `observability/grafana-dashboard-siem.json` (Dashboards, Import) e escolha as fontes Loki e Prometheus.

O addon consome uns 2 GB de RAM. Se a VM ficar apertada, mantenha só produção e observabilidade, ou desligue o simulador da homologação.

## Demonstração de upgrade e rollback

```bash
bash scripts/demo-upgrade-rollback.sh staging staging.meudesafio.duckdns.org
```

O roteiro mostra o histórico, faz um upgrade (rotação de 5 minutos e 2 réplicas da API), confere os pods, faz o rollback e mostra o histórico de novo. Banco e segredos não mudam no rollback.

Comandos avulsos úteis para os slides:

```bash
helm list -A
helm history sa-prod -n secureaccess-prod
helm get values sa-prod -n secureaccess-prod
helm diff upgrade ...            # se instalar o plugin helm-diff
helm rollback sa-prod 1 -n secureaccess-prod
```

## Se algo não funcionar

| Sintoma | O que fazer |
|---|---|
| Login volta para a tela de login sem erro | Acesse por `https://`. Em homologação e produção o cookie de sessão só trafega em HTTPS. |
| Certificado não sai (`kubectl get certificate` com READY `False`) | `kubectl describe certificate -n <namespace>`; confira o DNS do DuckDNS e se a porta 80 está aberta. |
| Site responde 502 ou 504 | Confira os pods (`kubectl get pods -n <namespace>`). Se estiverem prontos, teste sem as NetworkPolicies: `helm upgrade ... --reuse-values --set networkPolicy.enabled=false`. |
| API em `CrashLoopBackOff` | `kubectl logs deploy/<release>-api -n <namespace>`: o evento `CONFIGURACAO_INVALIDA` ou `INICIALIZACAO_FALHOU` diz o motivo. A API espera o MySQL por até 3 minutos. |
| Pods `Pending` | Falta de memória ou cota: `kubectl describe pod ...` e `kubectl describe resourcequota -n <namespace>`. |
| `ImagePullBackOff` | A imagem não está no registro: rode `bash scripts/build-local.sh` com a mesma tag do deploy. |
| A análise do Trivy barra o build | Leia o pacote e a versão corrigida que ele aponta e atualize a dependência ou a imagem base. Para destravar um deploy urgente, `SCAN=0`, e registre no relatório. |
| `permission denied` no Docker | Saia e entre de novo no SSH (grupo docker) ou rode com `DOCKER="sudo docker"`. |

## Usuários e perfis

| Usuário | Perfil | Pode |
|---|---|---|
| `admin` | Administrador | tudo: emitir, suspender, revogar e reativar crachás; rotacionar chaves; ver auditoria; simulador (só em homologação) |
| `operador` | Operador | acompanhar o painel, tratar alertas, suspender crachás |
| `auditor` | Auditor | ver tudo, incluindo chaves e trilha de auditoria, sem alterar nada |

## API

Rotas de operador exigem `Authorization: Bearer <token do login>`. Rotas de catraca exigem o token obtido em `/api/devices/token`.

| Método e rota | Quem | Para quê |
|---|---|---|
| `GET /healthz`, `GET /readyz` | público | sondas do Kubernetes |
| `GET /api/info` | público | versão e ambiente |
| `POST /api/auth/login` | público | login do operador (bloqueia após 5 erros) |
| `POST /api/auth/refresh`, `GET /api/auth/me` | operador | renovar token, ver sessão |
| `POST /api/devices/token` | catraca | autenticar o equipamento com o segredo dele |
| `POST /api/access/validate` | catraca | `{"method":"CRACHA","credential":"SA-10001"}` ou `{"method":"BIOMETRIA","credential":"<template>"}` |
| `POST /api/devices/events` | catraca | reportar `PORTA_FORCADA`, `CARONA`, `PORTA_ABERTA_EXCEDIDO`, `SABOTAGEM` |
| `POST /api/devices/heartbeat` | catraca | sinal de vida |
| `GET /api/dashboard`, `GET /api/feed` | todos os perfis | painel ao vivo |
| `GET /api/events`, `GET /api/alerts` | todos os perfis | histórico com filtros |
| `POST /api/alerts/:id/ack`, `/resolve` | admin, operador | tratar alerta |
| `GET /api/citizens`, `POST /api/citizens` | todos / admin | listar e emitir crachás |
| `POST /api/citizens/:id/status` | admin, operador | suspender, revogar, reativar |
| `GET /api/doors`, `GET /api/buildings` | todos os perfis | equipamentos e prédios |
| `GET /api/security/keys`, `POST /api/security/keys/rotate` | admin, auditor / admin | chaves JWT |
| `GET /api/audit` | admin, auditor | trilha de auditoria |
| `POST /api/simulate` | admin | cenários de incidente (desligado em produção) |
| `GET /metrics` (porta 9464) | Prometheus | métricas, fora do ingress |

## Decisões e limitações conhecidas

- **API sem framework.** Roteamento, validação, JWT HS256, cabeçalhos de segurança e limitação de requisições usam só a biblioteca padrão do Node. A única dependência é o `mysql2`. Isso reduz a superfície de CVEs; a contrapartida é manter esse código, coberto pelos testes. Uma alternativa de mercado seria Fastify com `jose`.
- **Limite de requisições em memória.** Com várias réplicas, cada uma conta separado. Para algo mais rígido, mova o contador para o banco ou para um Redis.
- **Segredos das catracas derivados.** Cada porta tem o próprio segredo, derivado de uma chave mestra que o simulador também conhece. Em produção real, cada equipamento receberia um segredo único no provisionamento (ou certificado cliente, com mTLS).
- **Um nó só.** O volume do MySQL fica no disco da EC2 (`hostpath`). Se a instância for apagada, os dados vão junto; por isso o backup para o S3 (`backup.enabled=true`, usando o perfil IAM da EC2).
- **Testes sem MySQL real no desenvolvimento.** Os testes automatizados usam um dublê do banco em memória (SQLite embutido no Node), que lê o mesmo arquivo de migração. A primeira subida no cluster é a validação com o MySQL real: confira os logs `MIGRACAO_APLICADA` e `API_PRONTA`.
- **Subchart local.** Não rode `helm dependency update`: o subchart já está desempacotado em `charts/mysql`.

## Roteiro de demonstração (cerca de 5 minutos)

1. Abra o painel no celular, faça login e mostre as passagens chegando ao vivo.
2. Na homologação, abra **Simulador** e dispare **Força bruta** e **Porta forçada**. Mostre os alertas no painel.
3. No terminal, mostre os mesmos eventos no log estruturado e no rsyslog (`tail /var/log/secureaccess/seguranca.log`).
4. Em **Segurança**, rotacione a chave JWT e mostre que o painel continua funcionando (o token antigo segue válido até expirar).
5. Em **Crachás**, mostre o documento mascarado e explique a cifra por campo; revogue um crachá e mostre a negação seguinte.
6. Mostre o pipeline no GitHub Actions e o SBOM gerado. Para provar o bloqueio, num branch troque uma versão por outra vulnerável (por exemplo `requests==2.25.0` em `web/requirements.txt`) e mostre o job falhando antes do build da imagem.
7. Rode `scripts/demo-upgrade-rollback.sh` e mostre `helm history`.
