'use strict';

// Dados de demonstração. Todos os nomes e documentos são FICTÍCIOS.
// Os documentos começam com "000" para deixar claro que não são CPFs reais.
// Este arquivo é a fonte única usada pelo seed do banco e pelo simulador.

const BUILDINGS = [
  { code: 'PREF', name: 'Sede da Prefeitura', district: 'Santo Antônio', opens: '07:00', closes: '19:00' },
  { code: 'SAUDE', name: 'Secretaria Municipal de Saúde', district: 'Boa Vista', opens: '07:00', closes: '22:00' },
  { code: 'BIBLIO', name: 'Biblioteca Pública Municipal', district: 'Santo Amaro', opens: '08:00', closes: '21:00' },
  { code: 'COP', name: 'Centro de Operações da Cidade', district: 'Bairro do Recife', opens: '00:00', closes: '23:59' },
  { code: 'DATAC', name: 'Data Center Municipal', district: 'Imbiribeira', opens: '00:00', closes: '23:59' },
];

// security_level: 1 = público, 2 = restrito, 3 = crítico
const DOORS = [
  { code: 'PREF-CAT01', building: 'PREF', name: 'Catraca da recepção', kind: 'CATRACA', level: 1 },
  { code: 'PREF-CAT02', building: 'PREF', name: 'Catraca do acesso lateral', kind: 'CATRACA', level: 1 },
  { code: 'PREF-GAB01', building: 'PREF', name: 'Porta do gabinete', kind: 'PORTA', level: 3 },
  { code: 'SAUDE-CAT01', building: 'SAUDE', name: 'Catraca do atendimento', kind: 'CATRACA', level: 1 },
  { code: 'SAUDE-FAR01', building: 'SAUDE', name: 'Porta da farmácia central', kind: 'PORTA', level: 2 },
  { code: 'BIBLIO-CAT01', building: 'BIBLIO', name: 'Catraca da entrada principal', kind: 'CATRACA', level: 1 },
  { code: 'COP-CAT01', building: 'COP', name: 'Catraca da sala de controle', kind: 'CATRACA', level: 2 },
  { code: 'COP-SRV01', building: 'COP', name: 'Porta da sala de servidores', kind: 'PORTA', level: 3 },
  { code: 'DATAC-POR01', building: 'DATAC', name: 'Porta blindada do data center', kind: 'PORTA', level: 3 },
];

// validDays: validade do crachá em dias a partir do seed (null = sem validade)
const CITIZENS = [
  { badge: 'SA-10001', name: 'Marina Albuquerque', category: 'SERVIDOR', department: 'Gabinete do Prefeito', level: 3, buildings: ['PREF'], status: 'ATIVO', allHours: false, validDays: null, biometric: true },
  { badge: 'SA-10002', name: 'João Pedro Tavares', category: 'SERVIDOR', department: 'Secretaria de Saúde', level: 2, buildings: ['SAUDE'], status: 'ATIVO', allHours: false, validDays: null, biometric: false },
  { badge: 'SA-10003', name: 'Larissa Monteiro', category: 'SERVIDOR', department: 'Secretaria de Saúde', level: 1, buildings: ['SAUDE', 'PREF'], status: 'ATIVO', allHours: false, validDays: null, biometric: false },
  { badge: 'SA-10004', name: 'Carlos Eduardo Lins', category: 'SEGURANCA', department: 'Guarda Municipal', level: 3, buildings: ['PREF', 'SAUDE', 'BIBLIO', 'COP', 'DATAC'], status: 'ATIVO', allHours: true, validDays: null, biometric: true },
  { badge: 'SA-10005', name: 'Beatriz Coutinho', category: 'SERVIDOR', department: 'Cultura', level: 1, buildings: ['BIBLIO'], status: 'ATIVO', allHours: false, validDays: null, biometric: false },
  { badge: 'SA-10006', name: 'Rafael Andrade', category: 'TERCEIRIZADO', department: 'Manutenção predial', level: 1, buildings: ['PREF', 'BIBLIO'], status: 'ATIVO', allHours: false, validDays: 120, biometric: false },
  { badge: 'SA-10007', name: 'Juliana Freitas', category: 'SERVIDOR', department: 'Centro de Operações', level: 2, buildings: ['COP'], status: 'ATIVO', allHours: true, validDays: null, biometric: true },
  { badge: 'SA-10008', name: 'Thiago Barreto', category: 'SERVIDOR', department: 'Tecnologia da Informação', level: 3, buildings: ['COP', 'DATAC'], status: 'ATIVO', allHours: true, validDays: null, biometric: false },
  { badge: 'SA-10009', name: 'Helena Vasconcelos', category: 'SERVIDOR', department: 'Finanças', level: 1, buildings: ['PREF'], status: 'SUSPENSO', allHours: false, validDays: null, biometric: false },
  { badge: 'SA-10010', name: 'Gustavo Pimentel', category: 'TERCEIRIZADO', department: 'Limpeza', level: 1, buildings: ['SAUDE'], status: 'ATIVO', allHours: false, validDays: -5, biometric: false },
  { badge: 'SA-10011', name: 'Patrícia Lacerda', category: 'SERVIDOR', department: 'Tecnologia da Informação', level: 2, buildings: ['COP'], status: 'REVOGADO', allHours: false, validDays: null, biometric: false },
  { badge: 'SA-10012', name: 'Diego Cavalcanti', category: 'VISITANTE', department: 'Visitante — atendimento', level: 1, buildings: ['PREF'], status: 'ATIVO', allHours: false, validDays: 30, biometric: false },
  { badge: 'SA-10013', name: 'Aline Moura', category: 'VISITANTE', department: 'Visitante — pesquisa', level: 1, buildings: ['BIBLIO'], status: 'ATIVO', allHours: false, validDays: 30, biometric: false },
  { badge: 'SA-10014', name: 'Fernanda Queiroz', category: 'SERVIDOR', department: 'Defesa Civil', level: 2, buildings: ['COP', 'PREF'], status: 'ATIVO', allHours: true, validDays: null, biometric: true },
];

function fakeDocument(index) {
  const n = (index * 7919 + 12345) % 100000000;
  return '000' + String(n).padStart(8, '0');
}

// Template biométrico simulado. Um leitor real enviaria um template extraído
// da digital; a API nunca guarda o template, só um HMAC dele.
function biometricTemplate(badge) {
  return `TPL:${badge}:v1`;
}

module.exports = { BUILDINGS, DOORS, CITIZENS, fakeDocument, biometricTemplate };
