'use strict';

// Registro mínimo de métricas no formato texto do Prometheus.
class Metrics {
  constructor() {
    this.defs = new Map();
    this.values = new Map();
  }

  define(name, type, help) {
    this.defs.set(name, { type, help });
    if (!this.values.has(name)) this.values.set(name, new Map());
  }

  inc(name, labels = {}, by = 1) {
    const series = this.values.get(name);
    if (!series) throw new Error(`Métrica não definida: ${name}`);
    const key = labelKey(labels);
    const cur = series.get(key);
    series.set(key, { labels, value: (cur ? cur.value : 0) + by });
  }

  set(name, labels = {}, value) {
    const series = this.values.get(name);
    if (!series) throw new Error(`Métrica não definida: ${name}`);
    series.set(labelKey(labels), { labels, value });
  }

  render() {
    const lines = [];
    for (const [name, def] of this.defs) {
      lines.push(`# HELP ${name} ${def.help}`);
      lines.push(`# TYPE ${name} ${def.type}`);
      for (const { labels, value } of this.values.get(name).values()) {
        lines.push(`${name}${formatLabels(labels)} ${Number.isFinite(value) ? value : 0}`);
      }
    }
    return lines.join('\n') + '\n';
  }
}

function labelKey(labels) {
  return Object.keys(labels).sort().map((k) => `${k}=${labels[k]}`).join(',');
}

function escapeLabel(v) {
  return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
}

function formatLabels(labels) {
  const keys = Object.keys(labels);
  if (keys.length === 0) return '';
  return '{' + keys.sort().map((k) => `${k}="${escapeLabel(labels[k])}"`).join(',') + '}';
}

function createMetrics() {
  const m = new Metrics();
  m.define('secureaccess_access_attempts_total', 'counter', 'Tentativas de acesso físico por decisão, prédio e motivo');
  m.define('secureaccess_security_alerts_total', 'counter', 'Alertas de segurança gerados por tipo e severidade');
  m.define('secureaccess_http_requests_total', 'counter', 'Requisições HTTP por rota e status');
  m.define('secureaccess_http_request_duration_seconds_sum', 'counter', 'Soma do tempo de resposta HTTP em segundos');
  m.define('secureaccess_auth_failures_total', 'counter', 'Falhas de autenticação por tipo');
  m.define('secureaccess_jwt_rotations_total', 'counter', 'Rotações de chave JWT por motivo');
  m.define('secureaccess_jwt_active_key_age_seconds', 'gauge', 'Idade da chave JWT ativa em segundos');
  m.define('secureaccess_jwt_keys_valid', 'gauge', 'Quantidade de chaves JWT ainda válidas para verificação');
  m.define('secureaccess_db_up', 'gauge', '1 se o banco respondeu na última verificação');
  return m;
}

module.exports = { createMetrics, Metrics };
