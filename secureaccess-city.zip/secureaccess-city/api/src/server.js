'use strict';

const http = require('node:http');
const mysql = require('mysql2/promise');
const { loadConfig } = require('./config');
const { createApp } = require('./app');

function main() {
  let cfg;
  try {
    cfg = loadConfig();
  } catch (err) {
    process.stderr.write(`${JSON.stringify({ ts: new Date().toISOString(), level: 'critical', event: 'CONFIGURACAO_INVALIDA', error: err.message })}\n`);
    process.exit(1);
  }

  const pool = mysql.createPool({
    host: cfg.db.host,
    port: cfg.db.port,
    user: cfg.db.user,
    password: cfg.db.password,
    database: cfg.db.database,
    connectionLimit: cfg.db.connectionLimit,
    waitForConnections: true,
    queueLimit: 200,
    connectTimeout: 10000,
    enableKeepAlive: true,
    timezone: 'Z',
    multipleStatements: false,
    charset: 'utf8mb4',
  });

  const app = createApp({ cfg, pool });
  const server = http.createServer(app.handle);
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  server.keepAliveTimeout = 5000;
  const metricsServer = http.createServer(app.handleMetrics);

  server.listen(cfg.port, () => app.logger.notice('API_ESCUTANDO', { category: 'application', port: cfg.port, metrics_port: cfg.metricsPort }));
  metricsServer.listen(cfg.metricsPort);

  app.startBackground();
  app.initWithRetry().catch((err) => {
    app.logger.error('INICIALIZACAO_ABORTADA', { category: 'application', error: err.message });
    process.exit(1);
  });

  let shuttingDown = false;
  const shutdown = (signal) => {
    if (shuttingDown) return;
    shuttingDown = true;
    app.logger.notice('API_ENCERRANDO', { category: 'application', signal });
    const force = setTimeout(() => process.exit(0), 10000);
    force.unref();
    server.close(() => {
      metricsServer.close();
      app.stop().finally(() => process.exit(0));
    });
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (err) => {
    app.logger.error('PROMESSA_NAO_TRATADA', { category: 'application', error: err && err.message });
  });
}

main();
