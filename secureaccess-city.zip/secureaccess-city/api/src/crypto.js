'use strict';

const crypto = require('node:crypto');
const { promisify } = require('node:util');

const scrypt = promisify(crypto.scrypt);
const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 32 };

// Cifra um campo com AES-256-GCM. O "context" entra como dado autenticado
// (AAD): um valor cifrado para citizens.name não decifra se for copiado
// para outra coluna.
function encryptField(plaintext, key, context) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(context, 'utf8'));
  const ct = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return ['v1', iv.toString('base64url'), tag.toString('base64url'), ct.toString('base64url')].join('.');
}

function decryptField(token, key, context) {
  const parts = String(token).split('.');
  if (parts.length !== 4 || parts[0] !== 'v1') throw new Error('Formato de dado cifrado desconhecido');
  const [, iv, tag, ct] = parts;
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'base64url'));
  decipher.setAAD(Buffer.from(context, 'utf8'));
  decipher.setAuthTag(Buffer.from(tag, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(ct, 'base64url')), decipher.final()]).toString('utf8');
}

// Índice cego: permite procurar um documento sem guardá-lo em claro.
function blindIndex(value, key) {
  return crypto.createHmac('sha256', key).update(String(value), 'utf8').digest('hex');
}

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(String(password), salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: 64 * 1024 * 1024 });
  return ['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('base64url'), hash.toString('base64url')].join('$');
}

async function verifyPassword(password, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, N, r, p, saltB64, hashB64] = parts;
  const expected = Buffer.from(hashB64, 'base64url');
  const actual = await scrypt(String(password), Buffer.from(saltB64, 'base64url'), expected.length, {
    N: Number(N), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024,
  });
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

// Hash fixo usado quando o usuário não existe, para que o tempo de resposta
// do login não revele quais usuários estão cadastrados.
let dummyHashPromise;
function dummyPasswordHash() {
  dummyHashPromise = dummyHashPromise || hashPassword(crypto.randomBytes(16).toString('hex'));
  return dummyHashPromise;
}

// Segredo de cada catraca, derivado da chave mestra de dispositivos.
// Em produção cada equipamento receberia o seu no provisionamento.
function deviceSecret(doorCode, masterKey) {
  return crypto.createHmac('sha256', masterKey).update(`device:${doorCode}`, 'utf8').digest('base64url');
}

function maskDocument(doc) {
  const d = String(doc).replace(/\D/g, '');
  if (d.length !== 11) return '***';
  return `***.${d.slice(3, 6)}.${d.slice(6, 9)}-**`;
}

function randomToken(bytes = 16) {
  return crypto.randomBytes(bytes).toString('base64url');
}

module.exports = {
  encryptField,
  decryptField,
  blindIndex,
  hashPassword,
  verifyPassword,
  dummyPasswordHash,
  deviceSecret,
  maskDocument,
  randomToken,
};
