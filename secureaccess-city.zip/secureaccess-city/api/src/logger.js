'use strict';

const os = require('node:os');
const dgram = require('node:dgram');

// Severidades no padrão syslog (RFC 5424).
const SEVERITY = { emergency: 0, alert: 1, critical: 2, error: 3, warning: 4, notice: 5, info: 6, debug: 7 };

// Facility 13 = "log audit" (eventos de segurança); 16 = local0 (aplicação).
const FACILITY_AUDIT = 13;
const FACILITY_APP = 16;
const SECURITY_CATEGORIES = new Set(['physical_access', 'security_alert', 'authentication', 'authorization', 'audit', 'key_management']);

class Logger {
  constructor({ service, env, version, syslog, out = process.stdout }) {
    this.base = { service, env, version };
    this.out = out;
    this.hostname = os.hostname();
    this.syslog = null;
    this.syslogErrorReported = false;
    if (syslog && syslog.host) {
      this.syslog = { host: syslog.host, port: syslog.port, appName: syslog.appName };
      this.socket = dgram.createSocket('udp4');
      this.socket.unref();
      this.socket.on('error', () => {});
    }
  }

  log(level, event, fields = {}) {
    const record = { ts: new Date().toISOString(), level, ...this.base, event, ...fields };
    const line = JSON.stringify(record);
    this.out.write(line + '\n');
    if (this.syslog) this.sendSyslog(level, event, fields.category, line);
    return record;
  }

  info(event, fields) { return this.log('info', event, fields); }
  notice(event, fields) { return this.log('notice', event, fields); }
  warning(event, fields) { return this.log('warning', event, fields); }
  error(event, fields) { return this.log('error', event, fields); }

  sendSyslog(level, event, category, json) {
    const severity = SEVERITY[level] ?? SEVERITY.info;
    const facility = SECURITY_CATEGORIES.has(category) ? FACILITY_AUDIT : FACILITY_APP;
    const pri = facility * 8 + severity;
    const msgId = String(event).replace(/[^A-Z0-9_]/gi, '').slice(0, 32) || '-';
    const header = `<${pri}>1 ${new Date().toISOString()} ${this.hostname} ${this.syslog.appName} ${process.pid} ${msgId} -`;
    const payload = Buffer.from(`${header} ${json}`.slice(0, 1400), 'utf8');
    this.socket.send(payload, this.syslog.port, this.syslog.host, (err) => {
      if (err && !this.syslogErrorReported) {
        this.syslogErrorReported = true;
        process.stderr.write(JSON.stringify({ ts: new Date().toISOString(), level: 'warning', event: 'SYSLOG_FALHA_ENVIO', error: err.message }) + '\n');
      }
    });
  }

  close() {
    if (this.socket) this.socket.close();
  }
}

module.exports = { Logger, SEVERITY };
