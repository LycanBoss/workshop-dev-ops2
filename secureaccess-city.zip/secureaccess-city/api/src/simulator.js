'use strict';

// Simulador de catracas e portas da SecureAccess City.
// Cada porta se autentica na API com o próprio segredo (derivado da chave
// mestra de dispositivos) e envia leituras de crachá/biometria. Periodicamente
// o simulador encena ataques: força bruta, varredura de crachá clonado,
// porta forçada, carona (tailgating) e sabotagem do leitor.

const crypto = require('node:crypto');
const { BUILDINGS, DOORS, CITIZENS, biometricTemplate } = require('./seed-data');
const { deviceSecret } = require('./crypto');
const { isWithinHours } = require('./time');

const appEnv = process.env.APP_ENV || 'development';
const API_URL = (process.env.API_URL || 'http://localhost:3000').replace(/\/$/, '');
const INTERVAL_MS = Number(process.env.SIM_INTERVAL_MS || 2500);
const ATTACK_EVERY_MS = Number(process.env.SIM_ATTACK_EVERY_MS || 90000);
const INTRUSION_EVERY_MS = Number(process.env.SIM_INTRUSION_EVERY_MS || 150000);
const TIMEZONE = process.env.CITY_TIMEZONE || 'America/Recife';

function masterKey() {
  const v = process.env.DEVICE_MASTER_KEY;
  if (v) {
    const buf = Buffer.from(v, 'base64');
    if (buf.length !== 32) throw new Error('DEVICE_MASTER_KEY precisa ter 32 bytes em base64');
    return buf;
  }
  if (appEnv === 'development' || appEnv === 'test') {
    return crypto.createHash('sha256').update('secureaccess-dev-only:DEVICE_MASTER_KEY').digest();
  }
  throw new Error('Segredo obrigatório ausente: DEVICE_MASTER_KEY');
}

const MASTER = masterKey();
const buildingByCode = new Map(BUILDINGS.map((b) => [b.code, b]));
const tokens = new Map();
let stopping = false;

function log(level, event, fields = {}) {
  process.stdout.write(`${JSON.stringify({ ts: new Date().toISOString(), level, service: 'secureaccess-simulator', env: appEnv, event, ...fields })}\n`);
}

const pick = (list) => list[crypto.randomInt(0, list.length)];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const isOpen = (buildingCode, now) => {
  const b = buildingByCode.get(buildingCode);
  return isWithinHours(now, TIMEZONE, b.opens, b.closes);
};
const activeCitizens = CITIZENS.filter((c) => c.status === 'ATIVO' && (c.validDays === null || c.validDays > 0));

async function getToken(door) {
  const cached = tokens.get(door);
  if (cached && cached.exp - Date.now() > 30000) return cached.token;
  const res = await fetch(`${API_URL}/api/devices/token`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ door_code: door, secret: deviceSecret(door, MASTER) }),
  });
  if (!res.ok) throw new Error(`Autenticação da ${door} falhou (${res.status})`);
  const body = await res.json();
  tokens.set(door, { token: body.token, exp: new Date(body.expires_at).getTime() });
  return body.token;
}

async function call(door, path, body, retry = true) {
  const token = await getToken(door);
  const res = await fetch(`${API_URL}${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
  });
  if (res.status === 401 && retry) {
    tokens.delete(door);
    return call(door, path, body, false);
  }
  const json = await res.json().catch(() => ({}));
  return { status: res.status, body: json };
}

async function read(door, method, credential, intent) {
  const r = await call(door, '/api/access/validate', { method, credential });
  log('info', 'SIMULADOR_LEITURA', {
    door, method, intent, status: r.status, decision: r.body.decision, reason: r.body.reason,
  });
  return r;
}

// Escolhe o próximo comportamento "normal" da cidade.
async function normalTraffic() {
  const now = new Date();
  const roll = Math.random();

  if (roll < 0.70) {
    const pairs = [];
    for (const c of activeCitizens) {
      for (const d of DOORS) {
        if (c.buildings.includes(d.building) && c.level >= d.level && (c.allHours || isOpen(d.building, now))) pairs.push({ c, d });
      }
    }
    const { c, d } = pick(pairs);
    const bio = c.biometric && Math.random() < 0.35;
    return read(d.code, bio ? 'BIOMETRIA' : 'CRACHA', bio ? biometricTemplate(c.badge) : c.badge, 'acesso_normal');
  }
  if (roll < 0.78) {
    const door = pick(DOORS.filter((d) => d.level === 1));
    return read(door.code, 'CRACHA', `SA-9${crypto.randomInt(1000, 9999)}`, 'cracha_desconhecido');
  }
  if (roll < 0.84) {
    const cases = [['SA-10011', 'COP-CAT01'], ['SA-10009', 'PREF-CAT01'], ['SA-10010', 'SAUDE-CAT01']];
    const [badge, door] = pick(cases);
    return read(door, 'CRACHA', badge, 'cracha_bloqueado');
  }
  if (roll < 0.91) {
    const pairs = [];
    for (const c of activeCitizens) {
      for (const d of DOORS) if (c.buildings.includes(d.building) && c.level < d.level) pairs.push({ c, d });
    }
    const { c, d } = pick(pairs);
    return read(d.code, 'CRACHA', c.badge, 'nivel_insuficiente');
  }
  if (roll < 0.96) {
    const pairs = [];
    for (const c of activeCitizens) {
      for (const d of DOORS) if (!c.buildings.includes(d.building)) pairs.push({ c, d });
    }
    const { c, d } = pick(pairs);
    return read(d.code, 'CRACHA', c.badge, 'predio_nao_autorizado');
  }
  const closed = DOORS.filter((d) => !isOpen(d.building, now));
  if (closed.length) {
    const door = pick(closed);
    const people = activeCitizens.filter((c) => !c.allHours && c.buildings.includes(door.building) && c.level >= door.level);
    if (people.length) return read(door.code, 'CRACHA', pick(people).badge, 'fora_do_horario');
  }
  return read('BIBLIO-CAT01', 'BIOMETRIA', `TPL:desconhecido:${crypto.randomInt(1000, 9999)}`, 'biometria_desconhecida');
}

let attackToggle = false;
async function attack() {
  attackToggle = !attackToggle;
  if (attackToggle) {
    const door = pick(DOORS.filter((d) => d.level === 1)).code;
    log('notice', 'SIMULADOR_ATAQUE', { attack: 'FORCA_BRUTA', door });
    for (let i = 0; i < 7 && !stopping; i += 1) {
      await read(door, 'CRACHA', `SA-8${crypto.randomInt(1000, 9999)}`, 'forca_bruta');
      await sleep(400);
    }
  } else {
    const badge = `SA-7${crypto.randomInt(1000, 9999)}`;
    log('notice', 'SIMULADOR_ATAQUE', { attack: 'VARREDURA_CRACHA', badge });
    for (const door of ['PREF-CAT01', 'SAUDE-CAT01', 'BIBLIO-CAT01', 'COP-CAT01']) {
      if (stopping) break;
      await read(door, 'CRACHA', badge, 'cracha_clonado');
      await sleep(700);
    }
  }
}

async function intrusion() {
  const type = pick(['PORTA_FORCADA', 'CARONA', 'PORTA_ABERTA_EXCEDIDO', 'SABOTAGEM']);
  const door = pick(DOORS.filter((d) => d.level >= 2)).code;
  const notes = {
    PORTA_FORCADA: 'sensor magnético aberto sem leitura válida',
    CARONA: 'sensor de passagem contou 2 pessoas em 1 leitura',
    PORTA_ABERTA_EXCEDIDO: 'porta aberta por mais de 60 segundos',
    SABOTAGEM: 'tampa do leitor removida',
  };
  const r = await call(door, '/api/devices/events', { type, note: notes[type] });
  log('notice', 'SIMULADOR_INVASAO', { door, type, status: r.status, alert_id: r.body.alert_id });
}

async function heartbeats() {
  for (const d of DOORS) {
    if (stopping) return;
    await call(d.code, '/api/devices/heartbeat', {}).catch(() => {});
  }
}

async function waitForApi() {
  for (;;) {
    try {
      const res = await fetch(`${API_URL}/readyz`);
      if (res.ok) return;
    } catch { /* API ainda subindo */ }
    log('info', 'SIMULADOR_AGUARDANDO_API', { api: API_URL });
    await sleep(3000);
  }
}

async function main() {
  log('notice', 'SIMULADOR_INICIADO', { api: API_URL, interval_ms: INTERVAL_MS, doors: DOORS.length });
  await waitForApi();
  await heartbeats();
  let lastAttack = Date.now();
  let lastIntrusion = Date.now() - INTRUSION_EVERY_MS / 2;
  let lastHeartbeat = Date.now();

  while (!stopping) {
    try {
      if (Date.now() - lastAttack >= ATTACK_EVERY_MS) {
        lastAttack = Date.now();
        await attack();
      } else if (Date.now() - lastIntrusion >= INTRUSION_EVERY_MS) {
        lastIntrusion = Date.now();
        await intrusion();
      } else {
        await normalTraffic();
      }
      if (Date.now() - lastHeartbeat >= 60000) {
        lastHeartbeat = Date.now();
        await heartbeats();
      }
    } catch (err) {
      log('warning', 'SIMULADOR_ERRO', { error: err.message });
      await sleep(3000);
    }
    await sleep(INTERVAL_MS * (0.6 + Math.random() * 0.8));
  }
}

process.on('SIGTERM', () => { stopping = true; log('notice', 'SIMULADOR_ENCERRANDO'); setTimeout(() => process.exit(0), 1500).unref(); });
process.on('SIGINT', () => { stopping = true; process.exit(0); });

main().catch((err) => {
  log('error', 'SIMULADOR_FALHOU', { error: err.message });
  process.exit(1);
});
