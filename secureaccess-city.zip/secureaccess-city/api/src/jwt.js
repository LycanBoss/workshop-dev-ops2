'use strict';

const crypto = require('node:crypto');

// JWT HS256 com identificador de chave (kid) no cabeçalho.
// Implementado com a biblioteca padrão do Node para não adicionar
// dependências. Regras de segurança aplicadas na verificação:
//  - só aceita alg HS256 (bloqueia "alg: none" e confusão de algoritmo);
//  - exige kid conhecido e ainda válido;
//  - compara a assinatura em tempo constante;
//  - valida iss, aud, exp e nbf.

class TokenError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

function b64json(obj) {
  return Buffer.from(JSON.stringify(obj), 'utf8').toString('base64url');
}

function parseB64Json(part) {
  try {
    return JSON.parse(Buffer.from(part, 'base64url').toString('utf8'));
  } catch {
    throw new TokenError('TOKEN_MALFORMADO', 'Token malformado');
  }
}

function signToken(payload, { kid, secret }) {
  const header = { alg: 'HS256', typ: 'JWT', kid };
  const data = `${b64json(header)}.${b64json(payload)}`;
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}

async function verifyToken(token, { resolveKey, issuer, audience, now = Date.now(), leewaySec = 5 }) {
  if (typeof token !== 'string' || token.length > 4096) throw new TokenError('TOKEN_MALFORMADO', 'Token malformado');
  const parts = token.split('.');
  if (parts.length !== 3) throw new TokenError('TOKEN_MALFORMADO', 'Token malformado');

  const header = parseB64Json(parts[0]);
  if (header.alg !== 'HS256' || header.typ !== 'JWT') throw new TokenError('ALGORITMO_INVALIDO', 'Algoritmo de assinatura não aceito');
  if (typeof header.kid !== 'string' || !/^[a-z0-9]{6,32}$/.test(header.kid)) throw new TokenError('KID_INVALIDO', 'Identificador de chave inválido');

  const secret = await resolveKey(header.kid);
  if (!secret) throw new TokenError('CHAVE_DESCONHECIDA', 'Chave de assinatura desconhecida ou expirada');

  const expected = crypto.createHmac('sha256', secret).update(`${parts[0]}.${parts[1]}`).digest();
  const given = Buffer.from(parts[2], 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) {
    throw new TokenError('ASSINATURA_INVALIDA', 'Assinatura do token inválida');
  }

  const payload = parseB64Json(parts[1]);
  const nowSec = Math.floor(now / 1000);
  if (payload.iss !== issuer) throw new TokenError('EMISSOR_INVALIDO', 'Emissor do token inválido');
  if (payload.aud !== audience) throw new TokenError('AUDIENCIA_INVALIDA', 'Token não é válido para este recurso');
  if (typeof payload.exp !== 'number' || payload.exp + leewaySec < nowSec) throw new TokenError('TOKEN_EXPIRADO', 'Token expirado');
  if (typeof payload.nbf === 'number' && payload.nbf - leewaySec > nowSec) throw new TokenError('TOKEN_AINDA_INVALIDO', 'Token ainda não é válido');
  return { header, payload };
}

module.exports = { signToken, verifyToken, TokenError };
