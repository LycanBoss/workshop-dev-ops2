'use strict';

const crypto = require('node:crypto');
const { HttpError } = require('./http');
const v = require('./validate');
const { signToken, verifyToken, TokenError } = require('./jwt');
const {
  encryptField, decryptField, blindIndex, verifyPassword, dummyPasswordHash, maskDocument, randomToken,
} = require('./crypto');
const { REASONS, findDoor, touchDoor, validateAccess } = require('./services/access');
const { ALERT_TYPES, DEVICE_EVENT_TYPES, createAlert } = require('./services/alerts');
const { audit } = require('./services/audit');
const { localTime, localDate, startOfLocalDay, isWithinHours } = require('./time');
const { toDate, isDuplicate } = require('./db');
const { CITIZENS: SEED_CITIZENS, DOORS: SEED_DOORS, BUILDINGS: SEED_BUILDINGS, biometricTemplate } = require('./seed-data');

const ROLES = {
  ALL: ['ADMIN', 'OPERADOR', 'AUDITOR'],
  MANAGE: ['ADMIN', 'OPERADOR'],
  ADMIN: ['ADMIN'],
  AUDIT: ['ADMIN', 'AUDITOR'],
};

const CATEGORIES = ['SERVIDOR', 'TERCEIRIZADO', 'VISITANTE', 'SEGURANCA'];
const CODE = /^[A-Z0-9-]{2,32}$/;
const TEXT = /^[\p{L}\p{N} .,;:'()\/–—-]+$/u;

// ---------------------------------------------------------------- tokens --

function issueToken(deps, { sub, aud, role, ttlSec, authTime }) {
  const now = Math.floor(Date.now() / 1000);
  const key = deps.keyring.signingKey();
  const payload = {
    iss: deps.cfg.jwt.issuer, aud, sub, role, iat: now, nbf: now, exp: now + ttlSec, jti: randomToken(12), auth_time: authTime ?? now,
  };
  return {
    token: signToken(payload, key),
    token_type: 'Bearer',
    expires_in: ttlSec,
    expires_at: new Date((now + ttlSec) * 1000).toISOString(),
    kid: key.kid,
  };
}

async function authenticate(deps, ctx, audience, roles) {
  const m = /^Bearer\s+([A-Za-z0-9_\-.]+)$/.exec(String(ctx.req.headers.authorization || ''));
  if (!m) throw new HttpError(401, 'TOKEN_AUSENTE', 'Envie o token no cabeçalho Authorization: Bearer');
  let payload;
  try {
    ({ payload } = await verifyToken(m[1], {
      resolveKey: (kid) => deps.keyring.resolveKey(kid),
      issuer: deps.cfg.jwt.issuer,
      audience,
    }));
  } catch (err) {
    if (!(err instanceof TokenError)) throw err;
    deps.metrics.inc('secureaccess_auth_failures_total', { type: `${audience}_token` });
    deps.logger.log(err.code === 'TOKEN_EXPIRADO' ? 'info' : 'warning', 'TOKEN_REJEITADO', {
      category: 'authentication', reason: err.code, audience, route: ctx.route, source_ip: ctx.ip,
    });
    throw new HttpError(401, err.code === 'TOKEN_EXPIRADO' ? 'TOKEN_EXPIRADO' : 'TOKEN_INVALIDO', err.message);
  }
  if (roles && !roles.includes(payload.role)) {
    deps.logger.warning('ACESSO_API_NEGADO', {
      category: 'authorization', actor: payload.sub, role: payload.role, route: ctx.route, source_ip: ctx.ip,
    });
    throw new HttpError(403, 'PERMISSAO_NEGADA', 'Seu perfil não tem permissão para esta ação');
  }
  return payload;
}

// ------------------------------------------------------------ formatação --

function fmtTime(deps, value) {
  const d = toDate(value);
  if (!d) return { at: null, time_local: null, date_local: null };
  return { at: d.toISOString(), time_local: localTime(d, deps.cfg.timezone), date_local: localDate(d, deps.cfg.timezone) };
}

function decryptName(deps, nameEnc) {
  if (!nameEnc) return null;
  try {
    return decryptField(nameEnc, deps.cfg.keys.data, 'citizens.name');
  } catch {
    return '[dado ilegível]';
  }
}

const EVENT_SELECT = `
  SELECT e.id, e.occurred_at, e.badge_ref, e.method, e.decision, e.reason, e.source,
         d.code AS door_code, d.name AS door_name, b.code AS building_code, b.name AS building_name, c.name_enc
    FROM access_events e
    JOIN doors d ON d.id = e.door_id
    JOIN buildings b ON b.id = e.building_id
    LEFT JOIN citizens c ON c.id = e.citizen_id`;

function formatEvent(deps, r) {
  return {
    id: Number(r.id),
    ...fmtTime(deps, r.occurred_at),
    door: r.door_code,
    door_name: r.door_name,
    building: r.building_code,
    building_name: r.building_name,
    badge: r.badge_ref,
    citizen: decryptName(deps, r.name_enc),
    method: r.method,
    decision: r.decision,
    reason: r.reason,
    reason_text: REASONS[r.reason] || r.reason,
    source: r.source,
  };
}

// Versão 1.1: o alerta traz o nome de quem é dono do crachá citado (quando o
// crachá está cadastrado). O nome continua cifrado no banco e só é decifrado
// aqui, na resposta para operadores autenticados.
const ALERT_SELECT = `
  SELECT a.id, a.occurred_at, a.alert_type, a.severity, a.badge_ref, a.details, a.status, a.handled_by, a.handled_at,
         d.code AS door_code, d.name AS door_name, b.code AS building_code,
         c.name_enc AS titular_enc
    FROM security_alerts a
    LEFT JOIN doors d ON d.id = a.door_id
    LEFT JOIN buildings b ON b.id = a.building_id
    LEFT JOIN citizens c ON c.badge_number = a.badge_ref`;

function formatAlert(deps, r) {
  return {
    id: Number(r.id),
    ...fmtTime(deps, r.occurred_at),
    type: r.alert_type,
    label: ALERT_TYPES[r.alert_type] ? ALERT_TYPES[r.alert_type].label : r.alert_type,
    severity: r.severity,
    door: r.door_code,
    door_name: r.door_name,
    building: r.building_code,
    badge: r.badge_ref,
    // null quando o alerta não cita crachá ou o crachá não existe (ex.: clonado).
    citizen: decryptName(deps, r.titular_enc),
    details: r.details,
    status: r.status,
    handled_by: r.handled_by,
    handled_at: r.handled_at ? toDate(r.handled_at).toISOString() : null,
  };
}

function idParam(ctx) {
  const id = Number(ctx.params.id);
  if (!Number.isInteger(id) || id < 1) throw new HttpError(400, 'PARAMETRO_INVALIDO', 'Identificador inválido');
  return id;
}

// ----------------------------------------------------------------- rotas --

function registerRoutes(router, deps, state) {
  const { cfg, db, logger, metrics, limiter, keyring } = deps;

  // Saúde -------------------------------------------------------------------
  router.add('GET', '/healthz', async () => ({ status: 'ok' }), { quiet: true });

  router.add('GET', '/readyz', async () => {
    if (!state.ready) throw new HttpError(503, 'INICIALIZANDO', 'API ainda inicializando');
    try {
      await db.ping();
    } catch {
      throw new HttpError(503, 'BANCO_INDISPONIVEL', 'Banco de dados indisponível');
    }
    return { status: 'ready' };
  }, { quiet: true });

  router.add('GET', '/api/info', async () => ({
    service: cfg.service, version: cfg.version, commit: cfg.commit, environment: cfg.appEnv,
  }));

  // Autenticação de operadores ---------------------------------------------
  router.add('POST', '/api/auth/login', async (ctx) => {
    const username = v.str(ctx.body, 'username', { min: 3, max: 64, pattern: /^[a-zA-Z0-9._-]+$/ }).toLowerCase();
    const password = v.str(ctx.body, 'password', { min: 1, max: 200 });
    const perUser = limiter.take(`login-user:${username}`, 10, 300);
    if (!perUser.ok) throw new HttpError(429, 'MUITAS_TENTATIVAS', 'Muitas tentativas para este usuário; aguarde', { retry_after: perUser.retryAfter });

    const op = await db.one('SELECT id, username, password_hash, role, failed_attempts, locked_until FROM operators WHERE username = ?', [username]);
    const now = new Date();
    if (op && op.locked_until && toDate(op.locked_until) > now) {
      metrics.inc('secureaccess_auth_failures_total', { type: 'operator_locked' });
      await audit(deps, { actor: username, action: 'LOGIN_BLOQUEADO', outcome: 'FALHA', ip: ctx.ip, details: 'conta temporariamente bloqueada' });
      throw new HttpError(423, 'CONTA_BLOQUEADA', 'Conta bloqueada temporariamente por excesso de tentativas');
    }

    const ok = await verifyPassword(password, op ? op.password_hash : await dummyPasswordHash());
    if (!op || !ok) {
      if (op) {
        const fails = Number(op.failed_attempts) + 1;
        const lockUntil = fails >= 5 ? new Date(now.getTime() + 5 * 60 * 1000) : null;
        await db.exec('UPDATE operators SET failed_attempts = ?, locked_until = ? WHERE id = ?', [lockUntil ? 0 : fails, lockUntil, op.id]);
        if (lockUntil) {
          await audit(deps, { actor: 'sistema', action: 'CONTA_BLOQUEADA', target: username, outcome: 'FALHA', ip: ctx.ip, details: '5 senhas incorretas seguidas' });
        }
      }
      metrics.inc('secureaccess_auth_failures_total', { type: 'operator_login' });
      await audit(deps, {
        actor: username, action: 'LOGIN_FALHA', outcome: 'FALHA', ip: ctx.ip, details: op ? 'senha incorreta' : 'usuário inexistente',
      });
      throw new HttpError(401, 'CREDENCIAIS_INVALIDAS', 'Usuário ou senha inválidos');
    }

    await db.exec('UPDATE operators SET failed_attempts = 0, locked_until = NULL, last_login_at = ? WHERE id = ?', [now, op.id]);
    await audit(deps, { actor: op.username, action: 'LOGIN_SUCESSO', ip: ctx.ip, details: `perfil ${op.role}` });
    return {
      ...issueToken(deps, { sub: op.username, aud: 'operator', role: op.role, ttlSec: cfg.jwt.operatorTtlSec }),
      username: op.username,
      role: op.role,
    };
  }, { rateLimit: { name: 'login', limit: 20, windowSec: 60 } });

  router.add('POST', '/api/auth/refresh', async (ctx) => {
    const p = ctx.auth;
    const nowSec = Math.floor(Date.now() / 1000);
    if (nowSec - Number(p.auth_time) > cfg.jwt.maxSessionSec) {
      throw new HttpError(401, 'SESSAO_EXPIRADA', 'Sessão expirada; faça login novamente');
    }
    const op = await db.one('SELECT username, role, locked_until FROM operators WHERE username = ?', [p.sub]);
    if (!op) throw new HttpError(401, 'TOKEN_INVALIDO', 'Operador não encontrado');
    return {
      ...issueToken(deps, { sub: op.username, aud: 'operator', role: op.role, ttlSec: cfg.jwt.operatorTtlSec, authTime: Number(p.auth_time) }),
      username: op.username,
      role: op.role,
    };
  }, { auth: 'operator', roles: ROLES.ALL });

  router.add('GET', '/api/auth/me', async (ctx) => ({
    username: ctx.auth.sub, role: ctx.auth.role, expires_at: new Date(ctx.auth.exp * 1000).toISOString(),
  }), { auth: 'operator', roles: ROLES.ALL });

  // Dispositivos (catracas e portas) ---------------------------------------
  router.add('POST', '/api/devices/token', async (ctx) => {
    const code = v.str(ctx.body, 'door_code', { min: 3, max: 32, pattern: CODE });
    const secret = v.str(ctx.body, 'secret', { min: 16, max: 128 });
    const door = await findDoor(db, code);
    const ok = await verifyPassword(secret, door ? door.secret_hash : await dummyPasswordHash());
    if (!door || !ok || !Number(door.active)) {
      metrics.inc('secureaccess_auth_failures_total', { type: 'device' });
      logger.warning('DISPOSITIVO_AUTENTICACAO_FALHA', {
        category: 'authentication', door: code, source_ip: ctx.ip,
        reason: !door ? 'porta inexistente' : !ok ? 'segredo incorreto' : 'porta desativada',
      });
      if (door && !limiter.take(`device-fail:${code}`, 5, 300).ok) {
        await createAlert(deps, {
          type: 'DISPOSITIVO_NAO_AUTENTICADO', door, dedupSec: 600,
          details: `Falhas repetidas de autenticação da ${code} vindas de ${ctx.ip}`,
        });
      }
      throw new HttpError(401, 'DISPOSITIVO_NAO_AUTORIZADO', 'Credenciais do dispositivo inválidas');
    }
    await touchDoor(db, door.id);
    const t = issueToken(deps, { sub: door.code, aud: 'device', role: 'DEVICE', ttlSec: cfg.jwt.deviceTtlSec });
    logger.info('DISPOSITIVO_AUTENTICADO', { category: 'authentication', door: door.code, kid: t.kid, source_ip: ctx.ip });
    return t;
  }, { rateLimit: { name: 'device-token', limit: 60, windowSec: 60 } });

  async function requireDoor(ctx) {
    const door = await findDoor(db, ctx.auth.sub);
    if (!door) throw new HttpError(403, 'DISPOSITIVO_DESCONHECIDO', 'Dispositivo não cadastrado');
    return door;
  }

  router.add('POST', '/api/devices/heartbeat', async (ctx) => {
    const door = await requireDoor(ctx);
    await touchDoor(db, door.id);
    return { ok: true, door: door.code, server_time: new Date().toISOString() };
  }, { auth: 'device', roles: ['DEVICE'] });

  router.add('POST', '/api/access/validate', async (ctx) => {
    const door = await requireDoor(ctx);
    const rl = limiter.take(`door:${door.code}`, 120, 60);
    if (!rl.ok) throw new HttpError(429, 'MUITAS_TENTATIVAS', 'Limite de leituras por minuto excedido', { retry_after: rl.retryAfter });
    const method = v.oneOf(ctx.body, 'method', ['CRACHA', 'BIOMETRIA']);
    const credential = ctx.body.credential;
    if (typeof credential !== 'string' || credential.length === 0 || credential.length > 512) {
      throw new HttpError(422, 'DADOS_INVALIDOS', 'O campo "credential" é obrigatório (até 512 caracteres)', { field: 'credential' });
    }
    const r = await validateAccess(deps, { door, method, credential, source: 'catraca' });
    return {
      decision: r.decision, reason: r.reason, message: r.reasonText, event_id: r.eventId, door: door.code, at: new Date().toISOString(),
    };
  }, { auth: 'device', roles: ['DEVICE'] });

  router.add('POST', '/api/devices/events', async (ctx) => {
    const door = await requireDoor(ctx);
    const type = v.oneOf(ctx.body, 'type', DEVICE_EVENT_TYPES);
    const note = v.str(ctx.body, 'note', { max: 160, optional: true, pattern: TEXT });
    await touchDoor(db, door.id);
    const alert = await createAlert(deps, {
      type, door, dedupSec: 20, details: `${ALERT_TYPES[type].label} em ${door.code}${note ? ` — ${note}` : ''}`,
    });
    return { status: 201, body: { alert_id: alert ? alert.id : null, deduplicated: !alert } };
  }, { auth: 'device', roles: ['DEVICE'] });

  // Painel -------------------------------------------------------------------
  router.add('GET', '/api/dashboard', async () => {
    const now = new Date();
    const dayStart = startOfLocalDay(now, cfg.timezone);

    const byDecision = await db.q('SELECT decision, COUNT(*) AS n FROM access_events WHERE occurred_at >= ? GROUP BY decision', [dayStart]);
    const liberados = Number(byDecision.find((r) => r.decision === 'LIBERADO')?.n || 0);
    const negados = Number(byDecision.find((r) => r.decision === 'NEGADO')?.n || 0);

    const open = await db.q("SELECT severity, COUNT(*) AS n FROM security_alerts WHERE status <> 'RESOLVIDO' GROUP BY severity");
    const sev = (s) => Number(open.find((r) => r.severity === s)?.n || 0);

    const doors = await db.q('SELECT active, last_seen_at FROM doors');
    const onlineCut = now.getTime() - cfg.detection.doorOnlineSec * 1000;
    const online = doors.filter((d) => Number(d.active) && d.last_seen_at && toDate(d.last_seen_at).getTime() >= onlineCut).length;

    const firstMinute = Math.floor(now.getTime() / 60000) * 60000 - 29 * 60000;
    const recent = await db.q('SELECT occurred_at, decision FROM access_events WHERE occurred_at >= ?', [new Date(firstMinute)]);
    const series = Array.from({ length: 30 }, (_, i) => ({
      minute: localTime(new Date(firstMinute + i * 60000), cfg.timezone).slice(0, 5), liberado: 0, negado: 0,
    }));
    for (const r of recent) {
      const idx = Math.floor((toDate(r.occurred_at).getTime() - firstMinute) / 60000);
      if (idx >= 0 && idx < 30) series[idx][r.decision === 'LIBERADO' ? 'liberado' : 'negado'] += 1;
    }

    const reasons = await db.q(
      "SELECT reason, COUNT(*) AS n FROM access_events WHERE decision = 'NEGADO' AND occurred_at >= ? GROUP BY reason ORDER BY n DESC LIMIT 6",
      [dayStart],
    );
    const topDoors = await db.q(
      `SELECT d.code, d.name, COUNT(*) AS n FROM access_events e JOIN doors d ON d.id = e.door_id
        WHERE e.decision = 'NEGADO' AND e.occurred_at >= ? GROUP BY d.code, d.name ORDER BY n DESC LIMIT 5`,
      [dayStart],
    );

    const active = keyring.activeKey();
    return {
      generated_at: now.toISOString(),
      environment: cfg.appEnv,
      simulation_enabled: cfg.allowSimulation,
      today: {
        liberados, negados, total: liberados + negados,
        denial_rate: liberados + negados ? Math.round((negados / (liberados + negados)) * 1000) / 10 : 0,
      },
      alerts_open: { CRITICA: sev('CRITICA'), ALTA: sev('ALTA'), MEDIA: sev('MEDIA'), total: sev('CRITICA') + sev('ALTA') + sev('MEDIA') },
      doors: { online, total: doors.length },
      series,
      denied_reasons: reasons.map((r) => ({ reason: r.reason, label: REASONS[r.reason] || r.reason, count: Number(r.n) })),
      top_denied_doors: topDoors.map((r) => ({ door: r.code, name: r.name, count: Number(r.n) })),
      jwt: active ? {
        active_kid: active.kid,
        active_since: active.createdAt.toISOString(),
        next_rotation: active.retireAfter.toISOString(),
        next_rotation_local: localTime(active.retireAfter, cfg.timezone).slice(0, 5),
      } : null,
    };
  }, { auth: 'operator', roles: ROLES.ALL });

  router.add('GET', '/api/feed', async (ctx) => {
    const ae = v.queryInt(ctx.query, 'ae', { def: null, min: 0, max: Number.MAX_SAFE_INTEGER });
    const al = v.queryInt(ctx.query, 'al', { def: null, min: 0, max: Number.MAX_SAFE_INTEGER });
    const events = ae === null
      ? await db.q(`${EVENT_SELECT} ORDER BY e.id DESC LIMIT 30`)
      : (await db.q(`${EVENT_SELECT} WHERE e.id > ? ORDER BY e.id ASC LIMIT 100`, [ae])).reverse();
    const alerts = al === null
      ? await db.q(`${ALERT_SELECT} ORDER BY a.id DESC LIMIT 10`)
      : (await db.q(`${ALERT_SELECT} WHERE a.id > ? ORDER BY a.id ASC LIMIT 50`, [al])).reverse();
    const maxId = (rows, fallback) => (rows.length ? Math.max(...rows.map((r) => Number(r.id))) : fallback ?? 0);
    return {
      events: events.map((r) => formatEvent(deps, r)),
      alerts: alerts.map((r) => formatAlert(deps, r)),
      cursor: { ae: maxId(events, ae), al: maxId(alerts, al) },
    };
  }, { auth: 'operator', roles: ROLES.ALL });

  // Eventos e alertas ------------------------------------------------------
  router.add('GET', '/api/events', async (ctx) => {
    const where = [];
    const params = [];
    const decision = v.queryStr(ctx.query, 'decision', /^(LIBERADO|NEGADO)$/);
    const building = v.queryStr(ctx.query, 'building', /^[A-Z0-9]{2,16}$/);
    const door = v.queryStr(ctx.query, 'door', CODE);
    const badge = v.queryStr(ctx.query, 'badge', /^[A-Z0-9-]{2,32}$/);
    const before = v.queryInt(ctx.query, 'before', { def: null, min: 1, max: Number.MAX_SAFE_INTEGER });
    const limit = v.queryInt(ctx.query, 'limit', { def: 50, min: 1, max: 200 });
    if (decision) { where.push('e.decision = ?'); params.push(decision); }
    if (building) { where.push('b.code = ?'); params.push(building); }
    if (door) { where.push('d.code = ?'); params.push(door); }
    if (badge) { where.push('e.badge_ref = ?'); params.push(badge); }
    if (before) { where.push('e.id < ?'); params.push(before); }
    const sql = `${EVENT_SELECT}${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY e.id DESC LIMIT ?`;
    const rows = await db.q(sql, [...params, limit]);
    const items = rows.map((r) => formatEvent(deps, r));
    return { items, next_before: items.length === limit ? items[items.length - 1].id : null };
  }, { auth: 'operator', roles: ROLES.ALL });

  router.add('GET', '/api/alerts', async (ctx) => {
    const status = v.queryStr(ctx.query, 'status', /^(ABERTO|RECONHECIDO|RESOLVIDO|ATIVOS)$/);
    const limit = v.queryInt(ctx.query, 'limit', { def: 100, min: 1, max: 300 });
    let where = '';
    const params = [];
    if (status === 'ATIVOS') where = " WHERE a.status <> 'RESOLVIDO'";
    else if (status) { where = ' WHERE a.status = ?'; params.push(status); }
    const rows = await db.q(`${ALERT_SELECT}${where} ORDER BY a.id DESC LIMIT ?`, [...params, limit]);
    return { items: rows.map((r) => formatAlert(deps, r)) };
  }, { auth: 'operator', roles: ROLES.ALL });

  async function changeAlert(ctx, target) {
    const id = idParam(ctx);
    const alert = await db.one('SELECT id, status, alert_type FROM security_alerts WHERE id = ?', [id]);
    if (!alert) throw new HttpError(404, 'NAO_ENCONTRADO', 'Alerta não encontrado');
    if (alert.status === 'RESOLVIDO' || (target === 'RECONHECIDO' && alert.status !== 'ABERTO')) {
      throw new HttpError(409, 'ESTADO_INVALIDO', `O alerta já está ${alert.status.toLowerCase()}`);
    }
    await db.exec('UPDATE security_alerts SET status = ?, handled_by = ?, handled_at = ? WHERE id = ?', [target, ctx.auth.sub, new Date(), id]);
    await audit(deps, {
      actor: ctx.auth.sub, action: target === 'RECONHECIDO' ? 'ALERTA_RECONHECIDO' : 'ALERTA_RESOLVIDO',
      target: `alerta #${id}`, ip: ctx.ip, details: alert.alert_type,
    });
    return { id, status: target };
  }

  router.add('POST', '/api/alerts/:id/ack', (ctx) => changeAlert(ctx, 'RECONHECIDO'), { auth: 'operator', roles: ROLES.MANAGE });
  router.add('POST', '/api/alerts/:id/resolve', (ctx) => changeAlert(ctx, 'RESOLVIDO'), { auth: 'operator', roles: ROLES.MANAGE });

  // Cidadãos e crachás -----------------------------------------------------
  router.add('GET', '/api/citizens', async (ctx) => {
    const status = v.queryStr(ctx.query, 'status', /^(ATIVO|SUSPENSO|REVOGADO)$/);
    const q = v.queryStr(ctx.query, 'q', /^[A-Za-z0-9-]{1,20}$/);
    const where = [];
    const params = [];
    if (status) { where.push('status = ?'); params.push(status); }
    if (q && /^\d{11}$/.test(q)) {
      where.push('document_hash = ?');
      params.push(blindIndex(`doc:${q}`, cfg.keys.blindIndex));
    } else if (q) {
      where.push('badge_number LIKE ?');
      params.push(`${q.toUpperCase()}%`);
    }
    const rows = await db.q(
      `SELECT id, badge_number, name_enc, document_enc, biometric_hash, category, department, access_level, all_hours, status, valid_until
         FROM citizens${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY badge_number LIMIT 200`,
      params,
    );
    const links = await db.q('SELECT cb.citizen_id, b.code FROM citizen_buildings cb JOIN buildings b ON b.id = cb.building_id');
    const byCitizen = new Map();
    for (const l of links) {
      const k = Number(l.citizen_id);
      if (!byCitizen.has(k)) byCitizen.set(k, []);
      byCitizen.get(k).push(l.code);
    }
    const now = new Date();
    return {
      items: rows.map((r) => {
        const validUntil = toDate(r.valid_until);
        let doc = null;
        try { doc = decryptField(r.document_enc, cfg.keys.data, 'citizens.document'); } catch { doc = null; }
        return {
          id: Number(r.id),
          badge: r.badge_number,
          name: decryptName(deps, r.name_enc),
          document_masked: doc ? maskDocument(doc) : '***',
          category: r.category,
          department: r.department,
          access_level: Number(r.access_level),
          all_hours: Boolean(Number(r.all_hours)),
          status: r.status,
          expired: Boolean(validUntil && validUntil < now),
          valid_until: validUntil ? validUntil.toISOString() : null,
          valid_until_local: validUntil ? localDate(validUntil, cfg.timezone) : null,
          biometric: Boolean(r.biometric_hash),
          buildings: (byCitizen.get(Number(r.id)) || []).sort(),
        };
      }),
    };
  }, { auth: 'operator', roles: ROLES.ALL });

  router.add('POST', '/api/citizens', async (ctx) => {
    const body = ctx.body;
    const name = v.str(body, 'name', { min: 3, max: 120, pattern: /^\p{L}[\p{L} .'-]*$/u });
    const documentDigits = String(body.document ?? '').replace(/\D/g, '');
    if (!/^\d{11}$/.test(documentDigits)) throw new HttpError(422, 'DADOS_INVALIDOS', 'O documento precisa ter 11 dígitos', { field: 'document' });
    const category = v.oneOf(body, 'category', CATEGORIES);
    const department = v.str(body, 'department', { min: 2, max: 80, pattern: TEXT });
    const level = v.int(body, 'access_level', { min: 1, max: 3 });
    const buildingCodes = v.strList(body, 'buildings', { min: 1, max: 10, itemPattern: /^[A-Z0-9]{2,16}$/ });
    const allHours = v.bool(body, 'all_hours');
    const validUntilRaw = v.str(body, 'valid_until', { optional: true, pattern: /^\d{4}-\d{2}-\d{2}$/, min: 10, max: 10 });
    const template = v.str(body, 'biometric_template', { optional: true, min: 8, max: 512 });

    let validUntil = null;
    if (validUntilRaw) {
      const [y, m, d] = validUntilRaw.split('-').map(Number);
      const noon = new Date(Date.UTC(y, m - 1, d, 15));
      if (Number.isNaN(noon.getTime())) throw new HttpError(422, 'DADOS_INVALIDOS', 'Data de validade inválida', { field: 'valid_until' });
      validUntil = new Date(startOfLocalDay(new Date(noon.getTime() + 86400000), cfg.timezone).getTime() - 1);
      if (validUntil <= new Date()) throw new HttpError(422, 'DADOS_INVALIDOS', 'A validade precisa ser uma data futura', { field: 'valid_until' });
    }
    if (['VISITANTE', 'TERCEIRIZADO'].includes(category)) {
      if (!validUntil) throw new HttpError(422, 'DADOS_INVALIDOS', 'Visitantes e terceirizados precisam de data de validade', { field: 'valid_until' });
      if (category === 'VISITANTE' && validUntil.getTime() - Date.now() > 31 * 86400000) {
        throw new HttpError(422, 'DADOS_INVALIDOS', 'Crachá de visitante vale no máximo 30 dias', { field: 'valid_until' });
      }
      if (allHours) throw new HttpError(422, 'DADOS_INVALIDOS', 'Visitantes e terceirizados não podem ter acesso 24 horas', { field: 'all_hours' });
    }

    const buildings = await db.q('SELECT id, code FROM buildings');
    const idByCode = new Map(buildings.map((b) => [b.code, Number(b.id)]));
    const unknown = buildingCodes.filter((c) => !idByCode.has(c));
    if (unknown.length) throw new HttpError(422, 'DADOS_INVALIDOS', `Prédio(s) inexistente(s): ${unknown.join(', ')}`, { field: 'buildings' });

    const docHash = blindIndex(`doc:${documentDigits}`, cfg.keys.blindIndex);
    if (await db.one('SELECT id FROM citizens WHERE document_hash = ?', [docHash])) {
      throw new HttpError(409, 'DOCUMENTO_JA_CADASTRADO', 'Já existe um crachá para este documento');
    }
    const bioHash = template ? blindIndex(`bio:${template}`, cfg.keys.blindIndex) : null;
    if (bioHash && (await db.one('SELECT id FROM citizens WHERE biometric_hash = ?', [bioHash]))) {
      throw new HttpError(409, 'BIOMETRIA_JA_CADASTRADA', 'Esta biometria já está vinculada a outro crachá');
    }

    const now = new Date();
    let created = null;
    for (let attempt = 0; attempt < 5 && !created; attempt += 1) {
      const badge = `SA-${crypto.randomInt(20000, 99999)}`;
      try {
        created = await db.tx(async (t) => {
          const r = await t.exec(
            `INSERT INTO citizens (badge_number, name_enc, document_enc, document_hash, biometric_hash, category, department,
                                   access_level, all_hours, status, valid_until, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ATIVO', ?, ?, ?)`,
            [
              badge,
              encryptField(name, cfg.keys.data, 'citizens.name'),
              encryptField(documentDigits, cfg.keys.data, 'citizens.document'),
              docHash, bioHash, category, department, level, allHours ? 1 : 0, validUntil, now, now,
            ],
          );
          const id = Number(r.insertId);
          for (const code of buildingCodes) {
            await t.exec('INSERT INTO citizen_buildings (citizen_id, building_id) VALUES (?, ?)', [id, idByCode.get(code)]);
          }
          return { id, badge };
        });
      } catch (err) {
        if (!isDuplicate(err)) throw err;
      }
    }
    if (!created) throw new HttpError(503, 'CRACHA_INDISPONIVEL', 'Não foi possível gerar um número de crachá; tente novamente');

    await audit(deps, {
      actor: ctx.auth.sub, action: 'CRACHA_EMITIDO', target: created.badge, ip: ctx.ip,
      details: `categoria ${category}, nível ${level}, prédios ${buildingCodes.join('/')}${allHours ? ', 24h' : ''}`,
    });
    return { status: 201, body: created };
  }, { auth: 'operator', roles: ROLES.ADMIN });

  router.add('POST', '/api/citizens/:id/status', async (ctx) => {
    const id = idParam(ctx);
    const status = v.oneOf(ctx.body, 'status', ['ATIVO', 'SUSPENSO', 'REVOGADO']);
    const reason = v.str(ctx.body, 'reason', { optional: true, max: 160, pattern: TEXT });
    if (ctx.auth.role !== 'ADMIN' && status !== 'SUSPENSO') {
      throw new HttpError(403, 'PERMISSAO_NEGADA', 'Operadores só podem suspender crachás');
    }
    const citizen = await db.one('SELECT id, badge_number, status FROM citizens WHERE id = ?', [id]);
    if (!citizen) throw new HttpError(404, 'NAO_ENCONTRADO', 'Crachá não encontrado');
    if (citizen.status === 'REVOGADO') throw new HttpError(409, 'CRACHA_REVOGADO', 'Crachá revogado não pode ser alterado; emita um novo');
    if (citizen.status === status) throw new HttpError(409, 'ESTADO_INVALIDO', `O crachá já está ${status.toLowerCase()}`);
    await db.exec('UPDATE citizens SET status = ?, updated_at = ? WHERE id = ?', [status, new Date(), id]);
    const action = { ATIVO: 'CRACHA_REATIVADO', SUSPENSO: 'CRACHA_SUSPENSO', REVOGADO: 'CRACHA_REVOGADO' }[status];
    await audit(deps, { actor: ctx.auth.sub, action, target: citizen.badge_number, ip: ctx.ip, details: reason });
    return { id, badge: citizen.badge_number, status };
  }, { auth: 'operator', roles: ROLES.MANAGE });

  // Portas e prédios -------------------------------------------------------
  router.add('GET', '/api/doors', async () => {
    const now = new Date();
    const dayStart = startOfLocalDay(now, cfg.timezone);
    const rows = await db.q(
      `SELECT d.id, d.code, d.name, d.kind, d.security_level, d.active, d.last_seen_at,
              b.code AS building_code, b.name AS building_name, b.opens_at, b.closes_at
         FROM doors d JOIN buildings b ON b.id = d.building_id ORDER BY b.code, d.code`,
    );
    const counts = await db.q('SELECT door_id, decision, COUNT(*) AS n FROM access_events WHERE occurred_at >= ? GROUP BY door_id, decision', [dayStart]);
    const count = (id, dec) => Number(counts.find((c) => Number(c.door_id) === Number(id) && c.decision === dec)?.n || 0);
    const onlineCut = now.getTime() - cfg.detection.doorOnlineSec * 1000;
    return {
      items: rows.map((d) => {
        const seen = toDate(d.last_seen_at);
        return {
          code: d.code,
          name: d.name,
          kind: d.kind,
          security_level: Number(d.security_level),
          active: Boolean(Number(d.active)),
          online: Boolean(Number(d.active) && seen && seen.getTime() >= onlineCut),
          last_seen_local: seen ? localTime(seen, cfg.timezone) : null,
          building: d.building_code,
          building_name: d.building_name,
          building_open: isWithinHours(now, cfg.timezone, d.opens_at, d.closes_at),
          hours: `${d.opens_at}–${d.closes_at}`,
          today: { liberados: count(d.id, 'LIBERADO'), negados: count(d.id, 'NEGADO') },
        };
      }),
    };
  }, { auth: 'operator', roles: ROLES.ALL });

  router.add('GET', '/api/buildings', async () => {
    const rows = await db.q('SELECT code, name, district, opens_at, closes_at FROM buildings ORDER BY code');
    return { items: rows.map((b) => ({ code: b.code, name: b.name, district: b.district, hours: `${b.opens_at}–${b.closes_at}` })) };
  }, { auth: 'operator', roles: ROLES.ALL });

  // Segurança: chaves JWT e auditoria ------------------------------------
  router.add('GET', '/api/security/keys', async () => {
    await keyring.load();
    return {
      rotation_interval_sec: cfg.jwt.rotationIntervalSec,
      operator_token_ttl_sec: cfg.jwt.operatorTtlSec,
      device_token_ttl_sec: cfg.jwt.deviceTtlSec,
      keys: keyring.describe().map((k) => ({
        ...k,
        created_local: localTime(new Date(k.created_at), cfg.timezone),
        created_date_local: localDate(new Date(k.created_at), cfg.timezone),
        retire_local: localTime(new Date(k.retire_after), cfg.timezone),
        expires_local: localTime(new Date(k.expires_at), cfg.timezone),
      })),
    };
  }, { auth: 'operator', roles: ROLES.AUDIT });

  router.add('POST', '/api/security/keys/rotate', async (ctx) => {
    const outcome = await db.withLock('secureaccess_jwt_rotation', 5, () => keyring.rotate('MANUAL', ctx.auth.sub));
    if (!outcome.acquired) throw new HttpError(409, 'ROTACAO_EM_ANDAMENTO', 'Outra rotação está em andamento; tente novamente');
    await audit(deps, { actor: ctx.auth.sub, action: 'CHAVE_JWT_ROTACIONADA', target: outcome.result, ip: ctx.ip, details: 'rotação manual' });
    return { kid: outcome.result };
  }, { auth: 'operator', roles: ROLES.ADMIN });

  router.add('GET', '/api/audit', async (ctx) => {
    const limit = v.queryInt(ctx.query, 'limit', { def: 100, min: 1, max: 500 });
    const outcome = v.queryStr(ctx.query, 'outcome', /^(SUCESSO|FALHA)$/);
    const rows = await db.q(
      `SELECT id, occurred_at, actor, action, target, outcome, source_ip, details FROM audit_log
        ${outcome ? 'WHERE outcome = ?' : ''} ORDER BY id DESC LIMIT ?`,
      outcome ? [outcome, limit] : [limit],
    );
    return {
      items: rows.map((r) => ({
        id: Number(r.id), ...fmtTime(deps, r.occurred_at), actor: r.actor, action: r.action, target: r.target,
        outcome: r.outcome, source_ip: r.source_ip, details: r.details,
      })),
    };
  }, { auth: 'operator', roles: ROLES.AUDIT });

  // Simulação (desligada em produção) ------------------------------------
  router.add('POST', '/api/simulate', async (ctx) => {
    if (!cfg.allowSimulation) throw new HttpError(403, 'SIMULACAO_DESABILITADA', 'Simulação desabilitada neste ambiente');
    const scenario = v.oneOf(ctx.body, 'scenario', SCENARIOS);
    const result = await runScenario(deps, scenario);
    await audit(deps, { actor: ctx.auth.sub, action: 'SIMULACAO_EXECUTADA', target: scenario, ip: ctx.ip, details: result.summary });
    return result;
  }, { auth: 'operator', roles: ROLES.ADMIN });
}

// --------------------------------------------------------------- simulação --

const SCENARIOS = [
  'ACESSO_VALIDO', 'BIOMETRIA_VALIDA', 'CRACHA_DESCONHECIDO', 'CRACHA_REVOGADO', 'NIVEL_INSUFICIENTE',
  'FORCA_BRUTA', 'VARREDURA_CRACHA', 'PORTA_FORCADA', 'CARONA', 'SABOTAGEM',
];

function pick(list) {
  return list[crypto.randomInt(0, list.length)];
}

function eligiblePairs(deps, now) {
  const hours = new Map(SEED_BUILDINGS.map((b) => [b.code, b]));
  const pairs = [];
  for (const c of SEED_CITIZENS) {
    if (c.status !== 'ATIVO' || (c.validDays !== null && c.validDays < 0)) continue;
    for (const d of SEED_DOORS) {
      const b = hours.get(d.building);
      if (!c.buildings.includes(d.building) || c.level < d.level) continue;
      if (!c.allHours && !isWithinHours(now, deps.cfg.timezone, b.opens, b.closes)) continue;
      pairs.push({ citizen: c, door: d });
    }
  }
  return pairs;
}

async function attempt(deps, doorCode, method, credential, results, alerts) {
  const door = await findDoor(deps.db, doorCode);
  if (!door) return;
  const r = await validateAccess(deps, { door, method, credential, source: 'simulacao-painel' });
  results.push({ door: door.code, badge: r.badgeRef, decision: r.decision, reason: r.reason });
  alerts.push(...r.alerts.map((a) => ({ id: a.id, type: a.type, severity: a.severity })));
}

async function runScenario(deps, scenario) {
  const results = [];
  const alerts = [];
  const now = new Date();
  const level1 = SEED_DOORS.filter((d) => d.level === 1).map((d) => d.code);

  switch (scenario) {
    case 'ACESSO_VALIDO':
    case 'BIOMETRIA_VALIDA': {
      let pairs = eligiblePairs(deps, now);
      if (scenario === 'BIOMETRIA_VALIDA') pairs = pairs.filter((p) => p.citizen.biometric);
      if (!pairs.length) break;
      const p = pick(pairs);
      const bio = scenario === 'BIOMETRIA_VALIDA';
      await attempt(deps, p.door.code, bio ? 'BIOMETRIA' : 'CRACHA', bio ? biometricTemplate(p.citizen.badge) : p.citizen.badge, results, alerts);
      break;
    }
    case 'CRACHA_DESCONHECIDO':
      await attempt(deps, pick(level1), 'CRACHA', `SA-9${crypto.randomInt(1000, 9999)}`, results, alerts);
      break;
    case 'CRACHA_REVOGADO':
      await attempt(deps, 'COP-CAT01', 'CRACHA', 'SA-10011', results, alerts);
      break;
    case 'NIVEL_INSUFICIENTE':
      await attempt(deps, 'PREF-GAB01', 'CRACHA', 'SA-10003', results, alerts);
      break;
    case 'FORCA_BRUTA': {
      const door = pick(level1);
      for (let i = 0; i < 6; i += 1) await attempt(deps, door, 'CRACHA', `SA-8${crypto.randomInt(1000, 9999)}`, results, alerts);
      break;
    }
    case 'VARREDURA_CRACHA': {
      const badge = `SA-7${crypto.randomInt(1000, 9999)}`;
      for (const door of ['PREF-CAT01', 'SAUDE-CAT01', 'BIBLIO-CAT01']) await attempt(deps, door, 'CRACHA', badge, results, alerts);
      break;
    }
    default: {
      const door = await findDoor(deps.db, pick(SEED_DOORS.filter((d) => d.level >= 2)).code);
      const a = await createAlert(deps, {
        type: scenario, door, details: `${ALERT_TYPES[scenario].label} em ${door.code} (simulação)`,
      });
      if (a) alerts.push({ id: a.id, type: a.type, severity: a.severity });
    }
  }

  const denied = results.filter((r) => r.decision === 'NEGADO').length;
  return {
    scenario,
    results,
    alerts,
    summary: `${results.length} leitura(s), ${denied} negada(s), ${alerts.length} alerta(s)`,
  };
}

module.exports = { registerRoutes, authenticate, issueToken, SCENARIOS };
