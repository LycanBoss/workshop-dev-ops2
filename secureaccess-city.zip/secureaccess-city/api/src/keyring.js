'use strict';

const crypto = require('node:crypto');
const { encryptField, decryptField } = require('./crypto');
const { toDate } = require('./db');

const KEY_CONTEXT = 'jwt_keys.secret';

// Gerencia as chaves de assinatura JWT com rotação obrigatória.
//  - Cada chave assina tokens por "rotationIntervalSec" (retire_after).
//  - Depois disso ela só verifica tokens já emitidos, até expires_at
//    (= retire_after + TTL máximo do token + folga).
//  - O segredo de cada chave fica no banco cifrado com a JWT_KEK.
//  - Com várias réplicas, só a que obtém a trava GET_LOCK rotaciona; as
//    demais recarregam as chaves do banco a cada ciclo.
class KeyRing {
  constructor({ db, kek, logger, metrics, rotationIntervalSec, maxTokenTtlSec, clock = () => new Date() }) {
    this.db = db;
    this.kek = kek;
    this.logger = logger;
    this.metrics = metrics;
    this.rotationIntervalSec = rotationIntervalSec;
    this.maxTokenTtlSec = maxTokenTtlSec;
    this.clock = clock;
    this.keys = [];
    this.lastLoad = 0;
  }

  async load() {
    const now = this.clock();
    const rows = await this.db.q(
      'SELECT kid, secret_enc, created_at, retire_after, expires_at FROM jwt_keys WHERE expires_at > ? ORDER BY created_at DESC',
      [now],
    );
    this.keys = rows.map((r) => ({
      kid: r.kid,
      secret: Buffer.from(decryptField(r.secret_enc, this.kek, KEY_CONTEXT), 'base64'),
      createdAt: toDate(r.created_at),
      retireAfter: toDate(r.retire_after),
      expiresAt: toDate(r.expires_at),
    }));
    this.lastLoad = Date.now();
    this.updateGauges();
  }

  activeKey() {
    const now = this.clock();
    return this.keys.find((k) => k.retireAfter > now) || null;
  }

  signingKey() {
    const key = this.activeKey() || this.keys[0];
    if (!key) throw new Error('Nenhuma chave JWT disponível para assinatura');
    return key;
  }

  async resolveKey(kid) {
    const now = this.clock();
    let key = this.keys.find((k) => k.kid === kid && k.expiresAt > now);
    if (!key && Date.now() - this.lastLoad > 2000) {
      // Outra réplica pode ter rotacionado agora há pouco.
      await this.load();
      key = this.keys.find((k) => k.kid === kid && k.expiresAt > now);
    }
    return key ? key.secret : null;
  }

  async rotate(reason, actor) {
    const now = this.clock();
    const kid = `k${now.getTime().toString(36)}${crypto.randomBytes(3).toString('hex')}`;
    const secret = crypto.randomBytes(32);
    const retireAfter = new Date(now.getTime() + this.rotationIntervalSec * 1000);
    const expiresAt = new Date(retireAfter.getTime() + (this.maxTokenTtlSec + 60) * 1000);
    const graceExpiry = new Date(now.getTime() + (this.maxTokenTtlSec + 60) * 1000);

    // Chaves antigas param de assinar agora, mas continuam verificando os
    // tokens já emitidos até o fim do TTL máximo.
    await this.db.exec('UPDATE jwt_keys SET retire_after = ? WHERE retire_after > ?', [now, now]);
    await this.db.exec('UPDATE jwt_keys SET expires_at = ? WHERE expires_at > ? AND kid <> ?', [graceExpiry, graceExpiry, kid]);
    await this.db.exec(
      'INSERT INTO jwt_keys (kid, secret_enc, created_at, retire_after, expires_at) VALUES (?, ?, ?, ?, ?)',
      [kid, encryptField(secret.toString('base64'), this.kek, KEY_CONTEXT), now, retireAfter, expiresAt],
    );
    await this.db.exec('DELETE FROM jwt_keys WHERE expires_at < ?', [new Date(now.getTime() - 3600 * 1000)]);

    this.metrics.inc('secureaccess_jwt_rotations_total', { reason });
    this.logger.notice('CHAVE_JWT_ROTACIONADA', {
      category: 'key_management', kid, reason, actor, retire_after: retireAfter.toISOString(),
    });
    await this.load();
    return kid;
  }

  // Executado periodicamente por todas as réplicas.
  async tick() {
    const outcome = await this.db.withLock('secureaccess_jwt_rotation', 0, async () => {
      await this.load();
      if (!this.activeKey()) await this.rotate(this.keys.length === 0 ? 'INICIAL' : 'AGENDADA', 'sistema');
    });
    if (!outcome.acquired) await this.load();
  }

  describe() {
    const now = this.clock();
    const active = this.activeKey();
    return this.keys.map((k) => ({
      kid: k.kid,
      created_at: k.createdAt.toISOString(),
      retire_after: k.retireAfter.toISOString(),
      expires_at: k.expiresAt.toISOString(),
      state: active && k.kid === active.kid ? 'ATIVA' : k.expiresAt > now ? 'SOMENTE_VERIFICACAO' : 'EXPIRADA',
    }));
  }

  updateGauges() {
    const active = this.activeKey();
    const age = active ? (this.clock().getTime() - active.createdAt.getTime()) / 1000 : -1;
    this.metrics.set('secureaccess_jwt_active_key_age_seconds', {}, Math.round(age));
    this.metrics.set('secureaccess_jwt_keys_valid', {}, this.keys.length);
  }
}

module.exports = { KeyRing };
