'use strict';

const crypto = require('node:crypto');

const DEV_ENVS = new Set(['development', 'test']);

function env(name, fallback) {
  const v = process.env[name];
  return v === undefined || v === '' ? fallback : v;
}

function int(name, fallback) {
  const v = env(name);
  if (v === undefined) return fallback;
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) throw new Error(`Variável de ambiente ${name} inválida: precisa ser um número`);
  return n;
}

function bool(name, fallback) {
  const v = env(name);
  if (v === undefined) return fallback;
  return ['1', 'true', 'yes', 'sim', 'on'].includes(String(v).toLowerCase());
}

// Chaves de 32 bytes em base64. Em staging e produção são obrigatórias e vêm
// de um Secret do Kubernetes. Em desenvolvimento usamos chaves derivadas fixas.
function key32(name, appEnv) {
  const v = env(name);
  if (!v) {
    if (DEV_ENVS.has(appEnv)) {
      return crypto.createHash('sha256').update(`secureaccess-dev-only:${name}`).digest();
    }
    throw new Error(`Segredo obrigatório ausente: ${name}`);
  }
  const buf = Buffer.from(v, 'base64');
  if (buf.length !== 32) throw new Error(`${name} precisa ter exatamente 32 bytes codificados em base64`);
  return buf;
}

function password(name, appEnv, devDefault) {
  const v = env(name);
  if (!v) return DEV_ENVS.has(appEnv) ? devDefault : undefined;
  if (v.length < 12) throw new Error(`${name} precisa ter pelo menos 12 caracteres`);
  return v;
}

function loadConfig() {
  const appEnv = env('APP_ENV', 'development');
  if (!['development', 'test', 'staging', 'production'].includes(appEnv)) {
    throw new Error('APP_ENV deve ser development, test, staging ou production');
  }

  const cfg = {
    appEnv,
    service: 'secureaccess-api',
    version: env('APP_VERSION', '1.0.0'),
    commit: env('GIT_COMMIT', 'local'),
    port: int('PORT', 3000),
    metricsPort: int('METRICS_PORT', 9464),
    trustProxy: bool('TRUST_PROXY', true),
    hsts: bool('HSTS', appEnv === 'production'),
    timezone: env('CITY_TIMEZONE', 'America/Recife'),
    allowSimulation: bool('ALLOW_SIMULATION', appEnv !== 'production'),
    seedDemoData: bool('SEED_DEMO_DATA', true),
    db: {
      host: env('DB_HOST', '127.0.0.1'),
      port: int('DB_PORT', 3306),
      user: env('DB_USER', 'secureaccess'),
      password: env('DB_PASSWORD', DEV_ENVS.has(appEnv) ? 'secureaccess-dev' : undefined),
      database: env('DB_NAME', 'secureaccess'),
      connectionLimit: int('DB_POOL_SIZE', 10),
    },
    jwt: {
      issuer: 'secureaccess-city',
      operatorTtlSec: int('JWT_OPERATOR_TTL_SECONDS', 900),
      deviceTtlSec: int('JWT_DEVICE_TTL_SECONDS', 300),
      rotationIntervalSec: int('JWT_ROTATION_INTERVAL_SECONDS', 3600),
      maxSessionSec: int('JWT_MAX_SESSION_SECONDS', 8 * 3600),
    },
    keys: {
      data: key32('DATA_ENCRYPTION_KEY', appEnv),
      blindIndex: key32('BLIND_INDEX_KEY', appEnv),
      jwtKek: key32('JWT_KEK', appEnv),
      deviceMaster: key32('DEVICE_MASTER_KEY', appEnv),
    },
    operators: {
      admin: password('ADMIN_PASSWORD', appEnv, 'Admin@SecureAccess1'),
      operador: password('OPERATOR_PASSWORD', appEnv, 'Operador@SecureAccess1'),
      auditor: password('AUDITOR_PASSWORD', appEnv, 'Auditor@SecureAccess1'),
    },
    syslog: {
      host: env('SYSLOG_HOST'),
      port: int('SYSLOG_PORT', 514),
      appName: 'secureaccess',
    },
    detection: {
      bruteForceThreshold: int('BRUTE_FORCE_THRESHOLD', 5),
      bruteForceWindowSec: int('BRUTE_FORCE_WINDOW_SECONDS', 60),
      scanDoorThreshold: int('BADGE_SCAN_DOOR_THRESHOLD', 3),
      scanWindowSec: int('BADGE_SCAN_WINDOW_SECONDS', 300),
      doorOnlineSec: int('DOOR_ONLINE_SECONDS', 120),
    },
  };

  if (!cfg.db.password) throw new Error('Segredo obrigatório ausente: DB_PASSWORD');
  if (!cfg.operators.admin) throw new Error('Segredo obrigatório ausente: ADMIN_PASSWORD');
  if (cfg.jwt.rotationIntervalSec < 60) throw new Error('JWT_ROTATION_INTERVAL_SECONDS precisa ser de pelo menos 60 segundos');
  if (cfg.jwt.operatorTtlSec < 60 || cfg.jwt.deviceTtlSec < 60) throw new Error('Os TTLs de token precisam ser de pelo menos 60 segundos');
  return cfg;
}

module.exports = { loadConfig };
