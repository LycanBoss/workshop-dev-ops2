'use strict';

function cut(v, n) {
  return v === null || v === undefined ? null : String(v).slice(0, n);
}

// Registra uma ação administrativa na trilha de auditoria (banco) e no log
// estruturado (stdout/syslog), que alimenta o SIEM.
async function audit(deps, { actor, action, target = null, outcome = 'SUCESSO', ip = null, details = null }) {
  await deps.db.exec(
    'INSERT INTO audit_log (occurred_at, actor, action, target, outcome, source_ip, details) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [new Date(), cut(actor, 64), action, cut(target, 96), outcome, cut(ip, 45), cut(details, 255)],
  );
  deps.logger.log(outcome === 'FALHA' ? 'warning' : 'notice', action, {
    category: 'audit', actor: cut(actor, 64), target: cut(target, 96), outcome, source_ip: ip, details: cut(details, 255),
  });
}

module.exports = { audit };
