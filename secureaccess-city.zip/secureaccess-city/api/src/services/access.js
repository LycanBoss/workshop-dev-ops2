'use strict';

const { blindIndex } = require('../crypto');
const { isWithinHours } = require('../time');
const { safeBadgeRef } = require('../validate');
const { toDate } = require('../db');
const { createAlert } = require('./alerts');

const REASONS = {
  OK: 'Acesso autorizado',
  CREDENCIAL_INVALIDA: 'Credencial em formato inválido',
  CREDENCIAL_DESCONHECIDA: 'Credencial não cadastrada',
  CRACHA_REVOGADO: 'Crachá revogado',
  CRACHA_SUSPENSO: 'Crachá suspenso',
  CRACHA_EXPIRADO: 'Crachá expirado',
  PREDIO_NAO_AUTORIZADO: 'Sem permissão para este prédio',
  NIVEL_INSUFICIENTE: 'Nível de acesso insuficiente para esta porta',
  FORA_DO_HORARIO: 'Fora do horário de funcionamento',
  PORTA_DESATIVADA: 'Porta desativada',
};

// Motivos que indicam alguém "chutando" credenciais na leitora.
const GUESSING_REASONS = ['CREDENCIAL_DESCONHECIDA', 'CREDENCIAL_INVALIDA'];

const BADGE_PATTERN = /^[A-Z0-9-]{3,20}$/;

async function findDoor(db, code) {
  return db.one(
    `SELECT d.id, d.code, d.name, d.kind, d.security_level, d.secret_hash, d.active, d.building_id,
            b.code AS building_code, b.name AS building_name, b.opens_at, b.closes_at
       FROM doors d JOIN buildings b ON b.id = d.building_id
      WHERE d.code = ?`,
    [code],
  );
}

async function touchDoor(db, doorId) {
  await db.exec('UPDATE doors SET last_seen_at = ? WHERE id = ?', [new Date(), doorId]);
}

async function lookupCitizen(deps, method, credential) {
  if (method === 'BIOMETRIA') {
    if (typeof credential !== 'string' || credential.length < 8 || credential.length > 512) {
      return { badgeRef: 'BIO-INVALIDA', citizen: null, invalid: true };
    }
    const hash = blindIndex(`bio:${credential}`, deps.cfg.keys.blindIndex);
    const citizen = await deps.db.one(
      'SELECT id, badge_number, status, access_level, all_hours, valid_until FROM citizens WHERE biometric_hash = ?',
      [hash],
    );
    return { badgeRef: citizen ? citizen.badge_number : `BIO-${hash.slice(0, 8).toUpperCase()}`, citizen };
  }

  const normalized = typeof credential === 'string' ? credential.trim().toUpperCase() : '';
  if (!BADGE_PATTERN.test(normalized)) return { badgeRef: safeBadgeRef(credential), citizen: null, invalid: true };
  const citizen = await deps.db.one(
    'SELECT id, badge_number, status, access_level, all_hours, valid_until FROM citizens WHERE badge_number = ?',
    [normalized],
  );
  return { badgeRef: normalized, citizen };
}

async function decide(deps, door, citizen, invalid, now) {
  if (!Number(door.active)) return 'PORTA_DESATIVADA';
  if (invalid) return 'CREDENCIAL_INVALIDA';
  if (!citizen) return 'CREDENCIAL_DESCONHECIDA';
  if (citizen.status === 'REVOGADO') return 'CRACHA_REVOGADO';
  if (citizen.status === 'SUSPENSO') return 'CRACHA_SUSPENSO';
  const validUntil = toDate(citizen.valid_until);
  if (validUntil && validUntil < now) return 'CRACHA_EXPIRADO';
  const allowed = await deps.db.one(
    'SELECT 1 AS ok FROM citizen_buildings WHERE citizen_id = ? AND building_id = ?',
    [citizen.id, door.building_id],
  );
  if (!allowed) return 'PREDIO_NAO_AUTORIZADO';
  if (Number(citizen.access_level) < Number(door.security_level)) return 'NIVEL_INSUFICIENTE';
  if (!Number(citizen.all_hours) && !isWithinHours(now, deps.cfg.timezone, door.opens_at, door.closes_at)) {
    return 'FORA_DO_HORARIO';
  }
  return 'OK';
}

// Decide se a catraca libera a passagem, registra o evento e roda os
// detectores de ataque.
async function validateAccess(deps, { door, method, credential, source }) {
  const now = new Date();
  const { badgeRef, citizen, invalid } = await lookupCitizen(deps, method, credential);
  const reason = await decide(deps, door, citizen, invalid, now);
  const decision = reason === 'OK' ? 'LIBERADO' : 'NEGADO';

  const result = await deps.db.exec(
    `INSERT INTO access_events (occurred_at, door_id, building_id, citizen_id, badge_ref, method, decision, reason, source)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [now, door.id, door.building_id, citizen ? citizen.id : null, badgeRef, method, decision, reason, source],
  );
  const eventId = Number(result.insertId);
  await touchDoor(deps.db, door.id);

  deps.metrics.inc('secureaccess_access_attempts_total', { decision, building: door.building_code, reason });
  deps.logger.log(decision === 'LIBERADO' ? 'info' : 'warning', decision === 'LIBERADO' ? 'ACESSO_LIBERADO' : 'ACESSO_NEGADO', {
    category: 'physical_access',
    event_id: eventId,
    door: door.code,
    building: door.building_code,
    security_level: Number(door.security_level),
    badge: badgeRef,
    citizen_id: citizen ? citizen.id : null,
    method,
    decision,
    reason,
    source,
  });

  const alerts = [];
  if (decision === 'NEGADO') alerts.push(...(await runDetectors(deps, { door, badgeRef, reason, now })));
  return { eventId, decision, reason, reasonText: REASONS[reason], badgeRef, alerts };
}

async function runDetectors(deps, { door, badgeRef, reason, now }) {
  const det = deps.cfg.detection;
  const raised = [];

  if (reason === 'CRACHA_REVOGADO') {
    const a = await createAlert(deps, {
      type: 'CRACHA_REVOGADO_USO', door, badgeRef, dedupSec: 600, dedupBy: 'badge',
      details: `Crachá revogado ${badgeRef} apresentado em ${door.code}`,
    });
    if (a) raised.push(a);
  }

  if (GUESSING_REASONS.includes(reason)) {
    const since = new Date(now.getTime() - det.bruteForceWindowSec * 1000);
    const row = await deps.db.one(
      `SELECT COUNT(*) AS n FROM access_events
        WHERE door_id = ? AND decision = 'NEGADO'
          AND reason IN ('CREDENCIAL_DESCONHECIDA', 'CREDENCIAL_INVALIDA')
          AND occurred_at >= ?`,
      [door.id, since],
    );
    const attempts = Number(row.n);
    if (attempts >= det.bruteForceThreshold) {
      const a = await createAlert(deps, {
        type: 'FORCA_BRUTA', door, badgeRef, dedupSec: 300, dedupBy: 'door',
        details: `${attempts} credenciais desconhecidas em ${det.bruteForceWindowSec}s na ${door.code}`,
      });
      if (a) raised.push(a);
    }
  }

  if (!['FORA_DO_HORARIO', 'PORTA_DESATIVADA'].includes(reason) && badgeRef !== 'VAZIO') {
    const since = new Date(now.getTime() - det.scanWindowSec * 1000);
    const row = await deps.db.one(
      `SELECT COUNT(DISTINCT door_id) AS n FROM access_events
        WHERE badge_ref = ? AND decision = 'NEGADO' AND occurred_at >= ?`,
      [badgeRef, since],
    );
    const doors = Number(row.n);
    if (doors >= det.scanDoorThreshold) {
      const a = await createAlert(deps, {
        type: 'VARREDURA_CRACHA', door, badgeRef, dedupSec: 600, dedupBy: 'badge',
        details: `Crachá ${badgeRef} negado em ${doors} portas diferentes; possível clonagem`,
      });
      if (a) raised.push(a);
    }
  }
  return raised;
}

module.exports = { REASONS, findDoor, touchDoor, validateAccess };
