-- SecureAccess City — esquema inicial (MySQL 8.4)
-- Aplicado automaticamente pela API na inicialização (tabela schema_migrations).
-- Dados pessoais de cidadãos ficam cifrados (AES-256-GCM) nas colunas *_enc.
-- Colunas *_hash guardam índices cegos (HMAC-SHA256) para busca sem expor o dado.

CREATE TABLE IF NOT EXISTS buildings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(16) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  district VARCHAR(80) NOT NULL,
  opens_at CHAR(5) NOT NULL,
  closes_at CHAR(5) NOT NULL,
  created_at DATETIME(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS doors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(32) NOT NULL UNIQUE,
  building_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  kind VARCHAR(16) NOT NULL,
  security_level TINYINT NOT NULL,
  secret_hash VARCHAR(255) NOT NULL,
  active TINYINT NOT NULL DEFAULT 1,
  last_seen_at DATETIME(3) NULL,
  created_at DATETIME(3) NOT NULL,
  CONSTRAINT fk_doors_building FOREIGN KEY (building_id) REFERENCES buildings (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS citizens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  badge_number VARCHAR(20) NOT NULL UNIQUE,
  name_enc TEXT NOT NULL,
  document_enc TEXT NOT NULL,
  document_hash CHAR(64) NOT NULL UNIQUE,
  biometric_hash CHAR(64) NULL UNIQUE,
  category VARCHAR(20) NOT NULL,
  department VARCHAR(80) NOT NULL,
  access_level TINYINT NOT NULL,
  all_hours TINYINT NOT NULL DEFAULT 0,
  status VARCHAR(12) NOT NULL,
  valid_until DATETIME(3) NULL,
  created_at DATETIME(3) NOT NULL,
  updated_at DATETIME(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS citizen_buildings (
  citizen_id INT NOT NULL,
  building_id INT NOT NULL,
  PRIMARY KEY (citizen_id, building_id),
  CONSTRAINT fk_cb_citizen FOREIGN KEY (citizen_id) REFERENCES citizens (id),
  CONSTRAINT fk_cb_building FOREIGN KEY (building_id) REFERENCES buildings (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS access_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  occurred_at DATETIME(3) NOT NULL,
  door_id INT NOT NULL,
  building_id INT NOT NULL,
  citizen_id INT NULL,
  badge_ref VARCHAR(32) NOT NULL,
  method VARCHAR(12) NOT NULL,
  decision VARCHAR(10) NOT NULL,
  reason VARCHAR(40) NOT NULL,
  source VARCHAR(32) NOT NULL,
  INDEX idx_events_time (occurred_at),
  INDEX idx_events_door_time (door_id, occurred_at),
  INDEX idx_events_badge_time (badge_ref, occurred_at),
  INDEX idx_events_decision (decision, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS security_alerts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  occurred_at DATETIME(3) NOT NULL,
  alert_type VARCHAR(32) NOT NULL,
  severity VARCHAR(10) NOT NULL,
  door_id INT NULL,
  building_id INT NULL,
  badge_ref VARCHAR(32) NULL,
  details VARCHAR(255) NOT NULL,
  status VARCHAR(12) NOT NULL,
  handled_by VARCHAR(64) NULL,
  handled_at DATETIME(3) NULL,
  INDEX idx_alerts_status_time (status, occurred_at),
  INDEX idx_alerts_type_door (alert_type, door_id, occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS operators (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(16) NOT NULL,
  failed_attempts INT NOT NULL DEFAULT 0,
  locked_until DATETIME(3) NULL,
  last_login_at DATETIME(3) NULL,
  created_at DATETIME(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  occurred_at DATETIME(3) NOT NULL,
  actor VARCHAR(64) NOT NULL,
  action VARCHAR(48) NOT NULL,
  target VARCHAR(96) NULL,
  outcome VARCHAR(10) NOT NULL,
  source_ip VARCHAR(45) NULL,
  details VARCHAR(255) NULL,
  INDEX idx_audit_time (occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Chaves de assinatura JWT. O segredo de cada chave fica cifrado com a
-- chave mestra (JWT_KEK) que vem de um Secret do Kubernetes.
CREATE TABLE IF NOT EXISTS jwt_keys (
  kid VARCHAR(32) PRIMARY KEY,
  secret_enc TEXT NOT NULL,
  created_at DATETIME(3) NOT NULL,
  retire_after DATETIME(3) NOT NULL,
  expires_at DATETIME(3) NOT NULL,
  INDEX idx_jwt_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
