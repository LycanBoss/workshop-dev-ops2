'use strict';

// Testes de integração da API (node --test). Sobem a API de verdade em uma
// porta local, com o dublê de banco em memória.

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const dgram = require('node:dgram');
const { Writable } = require('node:stream');

process.env.APP_ENV = 'test';
process.env.JWT_ROTATION_INTERVAL_SECONDS = '600';
process.env.SYSLOG_HOST = '127.0.0.1';
process.env.SYSLOG_PORT = '55514';

const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { createFakePool } = require('./fake-mysql');
const { deviceSecret } = require('../src/crypto');
const { biometricTemplate } = require('../src/seed-data');

const syslogMessages = [];
const logLines = [];
let app;
let server;
let base;
let pool;

async function req(method, path, { token, body, headers = {} } = {}) {
  const h = { ...headers };
  if (token) h.authorization = `Bearer ${token}`;
  let payload;
  if (body !== undefined) {
    payload = typeof body === 'string' ? body : JSON.stringify(body);
    h['content-type'] = h['content-type'] || 'application/json';
  }
  const res = await fetch(base + path, { method, headers: h, body: payload });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { json = text; }
  return { status: res.status, body: json, headers: res.headers };
}

async function login(username, password) {
  const r = await req('POST', '/api/auth/login', { body: { username, password } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return r.body.token;
}

async function deviceToken(door) {
  const cfg = app.deps.cfg;
  const r = await req('POST', '/api/devices/token', { body: { door_code: door, secret: deviceSecret(door, cfg.keys.deviceMaster) } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  return r.body.token;
}

test.before(async () => {
  const sock = dgram.createSocket('udp4');
  sock.on('message', (m) => syslogMessages.push(m.toString('utf8')));
  await new Promise((r) => sock.bind(55514, '127.0.0.1', r));
  sock.unref();

  const cfg = loadConfig();
  pool = createFakePool();
  const out = new Writable({ write(chunk, _e, cb) { logLines.push(...chunk.toString().trim().split('\n')); cb(); } });
  app = createApp({ cfg, pool, logOut: out });
  await app.init();
  server = http.createServer(app.handle);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});

test.after(async () => {
  server.close();
  await app.stop();
});

test('healthz, readyz e info respondem sem expor segredos', async () => {
  assert.equal((await req('GET', '/healthz')).status, 200);
  assert.equal((await req('GET', '/readyz')).status, 200);
  const info = await req('GET', '/api/info');
  assert.equal(info.status, 200);
  assert.equal(info.body.environment, 'test');
  assert.equal(info.headers.get('x-content-type-options'), 'nosniff');
  assert.match(info.headers.get('content-security-policy'), /default-src 'none'/);
});

test('login: senha errada é rejeitada e auditada; senha certa gera token', async () => {
  const bad = await req('POST', '/api/auth/login', { body: { username: 'admin', password: 'errada-123' } });
  assert.equal(bad.status, 401);
  assert.equal(bad.body.error, 'CREDENCIAIS_INVALIDAS');
  const token = await login('admin', 'Admin@SecureAccess1');
  const me = await req('GET', '/api/auth/me', { token });
  assert.equal(me.body.role, 'ADMIN');
  const audits = pool.raw.prepare("SELECT action, outcome FROM audit_log WHERE action LIKE 'LOGIN%'").all();
  assert.ok(audits.some((a) => a.action === 'LOGIN_FALHA' && a.outcome === 'FALHA'));
  assert.ok(audits.some((a) => a.action === 'LOGIN_SUCESSO'));
});

test('conta bloqueia após 5 senhas incorretas', async () => {
  for (let i = 0; i < 5; i += 1) {
    const r = await req('POST', '/api/auth/login', { body: { username: 'operador', password: `x-${i}-errada` } });
    assert.equal(r.status, 401);
  }
  const locked = await req('POST', '/api/auth/login', { body: { username: 'operador', password: 'Operador@SecureAccess1' } });
  assert.equal(locked.status, 423);
  pool.raw.prepare("UPDATE operators SET locked_until = NULL, failed_attempts = 0 WHERE username = 'operador'").run();
});

test('dados de cidadãos ficam cifrados no banco', () => {
  const row = pool.raw.prepare("SELECT name_enc, document_enc, document_hash FROM citizens WHERE badge_number = 'SA-10001'").get();
  assert.ok(row.name_enc.startsWith('v1.'));
  assert.ok(!row.name_enc.includes('Marina'));
  assert.equal(row.document_hash.length, 64);
});

test('catraca libera crachá válido e nega crachá revogado com alerta', async () => {
  const dev = await deviceToken('COP-CAT01');
  const ok = await req('POST', '/api/access/validate', { token: dev, body: { method: 'CRACHA', credential: 'SA-10004' } });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.decision, 'LIBERADO');

  const bio = await req('POST', '/api/access/validate', { token: dev, body: { method: 'BIOMETRIA', credential: biometricTemplate('SA-10007') } });
  assert.equal(bio.body.decision, 'LIBERADO');

  const revoked = await req('POST', '/api/access/validate', { token: dev, body: { method: 'CRACHA', credential: 'SA-10011' } });
  assert.equal(revoked.body.decision, 'NEGADO');
  assert.equal(revoked.body.reason, 'CRACHA_REVOGADO');
  const alert = pool.raw.prepare("SELECT * FROM security_alerts WHERE alert_type = 'CRACHA_REVOGADO_USO'").get();
  assert.ok(alert, 'alerta de crachá revogado deveria existir');
});

test('regras de negação: nível, prédio, expirado e suspenso', async () => {
  const gab = await deviceToken('PREF-GAB01');
  const lvl = await req('POST', '/api/access/validate', { token: gab, body: { method: 'CRACHA', credential: 'SA-10003' } });
  assert.equal(lvl.body.reason, 'NIVEL_INSUFICIENTE');

  const dc = await deviceToken('DATAC-POR01');
  const bld = await req('POST', '/api/access/validate', { token: dc, body: { method: 'CRACHA', credential: 'SA-10007' } });
  assert.equal(bld.body.reason, 'PREDIO_NAO_AUTORIZADO');

  const saude = await deviceToken('SAUDE-CAT01');
  const exp = await req('POST', '/api/access/validate', { token: saude, body: { method: 'CRACHA', credential: 'SA-10010' } });
  assert.equal(exp.body.reason, 'CRACHA_EXPIRADO');

  const pref = await deviceToken('PREF-CAT02');
  const sus = await req('POST', '/api/access/validate', { token: pref, body: { method: 'CRACHA', credential: 'SA-10009' } });
  assert.equal(sus.body.reason, 'CRACHA_SUSPENSO');

  const inj = await req('POST', '/api/access/validate', { token: pref, body: { method: 'CRACHA', credential: "' OR 1=1 --\n" } });
  assert.equal(inj.body.reason, 'CREDENCIAL_INVALIDA');
});

test('força bruta e varredura de crachá geram alertas', async () => {
  const dev = await deviceToken('BIBLIO-CAT01');
  for (let i = 0; i < 5; i += 1) {
    const r = await req('POST', '/api/access/validate', { token: dev, body: { method: 'CRACHA', credential: `SA-8${1000 + i}` } });
    assert.equal(r.body.decision, 'NEGADO');
  }
  assert.ok(pool.raw.prepare("SELECT 1 FROM security_alerts WHERE alert_type = 'FORCA_BRUTA'").get());

  for (const door of ['PREF-CAT01', 'SAUDE-CAT01', 'BIBLIO-CAT01']) {
    const t = await deviceToken(door);
    await req('POST', '/api/access/validate', { token: t, body: { method: 'CRACHA', credential: 'SA-77777' } });
  }
  assert.ok(pool.raw.prepare("SELECT 1 FROM security_alerts WHERE alert_type = 'VARREDURA_CRACHA' AND badge_ref = 'SA-77777'").get());
});

test('catraca reporta invasão física (porta forçada)', async () => {
  const dev = await deviceToken('DATAC-POR01');
  const r = await req('POST', '/api/devices/events', { token: dev, body: { type: 'PORTA_FORCADA', note: 'sensor magnético aberto' } });
  assert.equal(r.status, 201);
  assert.ok(r.body.alert_id > 0);
  const again = await req('POST', '/api/devices/events', { token: dev, body: { type: 'PORTA_FORCADA' } });
  assert.equal(again.body.deduplicated, true);
});

test('segredo de catraca errado é rejeitado', async () => {
  const r = await req('POST', '/api/devices/token', { body: { door_code: 'PREF-CAT01', secret: 'segredo-incorreto-123' } });
  assert.equal(r.status, 401);
});

test('tokens: audiência, algoritmo e assinatura são verificados', async () => {
  const op = await login('admin', 'Admin@SecureAccess1');
  const asDevice = await req('POST', '/api/access/validate', { token: op, body: { method: 'CRACHA', credential: 'SA-10004' } });
  assert.equal(asDevice.status, 401);

  const [, payload] = op.split('.');
  const none = `${Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT', kid: 'kabcdef' })).toString('base64url')}.${payload}.`;
  assert.equal((await req('GET', '/api/dashboard', { token: none })).status, 401);

  const forged = op.slice(0, -4) + (op.endsWith('AAAA') ? 'BBBB' : 'AAAA');
  assert.equal((await req('GET', '/api/dashboard', { token: forged })).status, 401);
  assert.equal((await req('GET', '/api/dashboard')).status, 401);
});

test('rotação de chave: token antigo continua válido e o novo usa outra chave', async () => {
  const before = await login('admin', 'Admin@SecureAccess1');
  const kidBefore = JSON.parse(Buffer.from(before.split('.')[0], 'base64url')).kid;
  const rot = await req('POST', '/api/security/keys/rotate', { token: before });
  assert.equal(rot.status, 200);
  assert.notEqual(rot.body.kid, kidBefore);

  assert.equal((await req('GET', '/api/dashboard', { token: before })).status, 200);
  const after = await login('admin', 'Admin@SecureAccess1');
  assert.equal(JSON.parse(Buffer.from(after.split('.')[0], 'base64url')).kid, rot.body.kid);

  const keys = await req('GET', '/api/security/keys', { token: after });
  const states = keys.body.keys.map((k) => k.state);
  assert.ok(states.includes('ATIVA'));
  assert.ok(states.includes('SOMENTE_VERIFICACAO'));
  assert.ok(!JSON.stringify(keys.body).includes('secret'));
});

test('perfis: auditor não rotaciona chave nem cadastra; operador só suspende', async () => {
  const auditor = await login('auditor', 'Auditor@SecureAccess1');
  assert.equal((await req('POST', '/api/security/keys/rotate', { token: auditor })).status, 403);
  assert.equal((await req('GET', '/api/audit', { token: auditor })).status, 200);

  const operador = await login('operador', 'Operador@SecureAccess1');
  const list = await req('GET', '/api/citizens', { token: operador });
  const larissa = list.body.items.find((c) => c.badge === 'SA-10003');
  assert.equal((await req('POST', `/api/citizens/${larissa.id}/status`, { token: operador, body: { status: 'REVOGADO' } })).status, 403);
  const sus = await req('POST', `/api/citizens/${larissa.id}/status`, { token: operador, body: { status: 'SUSPENSO', reason: 'teste' } });
  assert.equal(sus.status, 200);
  const admin = await login('admin', 'Admin@SecureAccess1');
  assert.equal((await req('POST', `/api/citizens/${larissa.id}/status`, { token: admin, body: { status: 'ATIVO' } })).status, 200);
});

test('cadastro de cidadão valida dados, mascara documento e impede duplicidade', async () => {
  const admin = await login('admin', 'Admin@SecureAccess1');
  const body = {
    name: 'Teste da Silva', document: '000.123.456-78', category: 'VISITANTE', department: 'Visitante — reunião',
    access_level: 1, buildings: ['PREF'], valid_until: new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10),
  };
  const created = await req('POST', '/api/citizens', { token: admin, body });
  assert.equal(created.status, 201, JSON.stringify(created.body));
  assert.match(created.body.badge, /^SA-\d{5}$/);

  assert.equal((await req('POST', '/api/citizens', { token: admin, body })).status, 409);
  const noDate = await req('POST', '/api/citizens', { token: admin, body: { ...body, document: '00011122233', valid_until: undefined } });
  assert.equal(noDate.status, 422);
  const badName = await req('POST', '/api/citizens', { token: admin, body: { ...body, document: '00011122244', name: '<script>' } });
  assert.equal(badName.status, 422);

  const list = await req('GET', `/api/citizens?q=${created.body.badge}`, { token: admin });
  assert.equal(list.body.items[0].name, 'Teste da Silva');
  assert.equal(list.body.items[0].document_masked, '***.123.456-**');
  const byDoc = await req('GET', '/api/citizens?q=00012345678', { token: admin });
  assert.equal(byDoc.body.items.length, 1);
});

test('painel, feed, eventos, alertas e portas respondem', async () => {
  const admin = await login('admin', 'Admin@SecureAccess1');
  const dash = await req('GET', '/api/dashboard', { token: admin });
  assert.equal(dash.status, 200);
  assert.equal(dash.body.series.length, 30);
  assert.ok(dash.body.today.total > 0);
  assert.ok(dash.body.alerts_open.total > 0);

  const feed = await req('GET', '/api/feed', { token: admin });
  assert.ok(feed.body.events.length > 0);
  const next = await req('GET', `/api/feed?ae=${feed.body.cursor.ae}&al=${feed.body.cursor.al}`, { token: admin });
  assert.equal(next.body.events.length, 0);

  const denied = await req('GET', '/api/events?decision=NEGADO&limit=5', { token: admin });
  assert.ok(denied.body.items.every((e) => e.decision === 'NEGADO'));
  assert.equal((await req('GET', '/api/events?decision=DROP%20TABLE', { token: admin })).status, 400);

  const alerts = await req('GET', '/api/alerts?status=ATIVOS', { token: admin });
  const first = alerts.body.items[0];
  assert.equal((await req('POST', `/api/alerts/${first.id}/ack`, { token: admin })).status, 200);
  assert.equal((await req('POST', `/api/alerts/${first.id}/ack`, { token: admin })).status, 409);
  assert.equal((await req('POST', `/api/alerts/${first.id}/resolve`, { token: admin })).status, 200);

  const doors = await req('GET', '/api/doors', { token: admin });
  assert.equal(doors.body.items.length, 9);
  assert.ok(doors.body.items.some((d) => d.online));
});

test('todos os cenários de simulação executam', async () => {
  const admin = await login('admin', 'Admin@SecureAccess1');
  for (const scenario of ['ACESSO_VALIDO', 'BIOMETRIA_VALIDA', 'CRACHA_DESCONHECIDO', 'CRACHA_REVOGADO', 'NIVEL_INSUFICIENTE',
    'FORCA_BRUTA', 'VARREDURA_CRACHA', 'PORTA_FORCADA', 'CARONA', 'SABOTAGEM']) {
    const r = await req('POST', '/api/simulate', { token: admin, body: { scenario } });
    assert.equal(r.status, 200, `${scenario}: ${JSON.stringify(r.body)}`);
  }
});

test('entradas malformadas são rejeitadas', async () => {
  assert.equal((await req('POST', '/api/auth/login', { body: '{"username":' })).status, 400);
  assert.equal((await req('POST', '/api/auth/login', { body: 'x=1', headers: { 'content-type': 'text/plain' } })).status, 415);
  const polluted = await req('POST', '/api/auth/login', { body: '{"__proto__":{"admin":true},"username":"admin","password":"x"}' });
  assert.equal(polluted.status, 401);
  assert.equal({}.admin, undefined);
  assert.equal((await req('DELETE', '/api/dashboard')).status, 405);
  assert.equal((await req('GET', '/api/nao-existe')).status, 404);
});

test('logs estruturados e syslog registram eventos de segurança', async () => {
  await new Promise((r) => setTimeout(r, 200));
  const parsed = logLines.map((l) => JSON.parse(l));
  const negado = parsed.find((l) => l.event === 'ACESSO_NEGADO');
  assert.equal(negado.category, 'physical_access');
  assert.ok(negado.door && negado.reason);
  assert.equal(negado.citizen_name, undefined);
  assert.ok(parsed.some((l) => l.event === 'ALERTA_SEGURANCA' && l.level === 'critical'));
  assert.ok(!logLines.some((l) => l.includes('Marina Albuquerque')), 'nomes não devem ir para o log');

  const sys = syslogMessages.find((m) => m.includes('ACESSO_NEGADO'));
  assert.ok(sys, 'mensagem syslog esperada');
  assert.match(sys, /^<108>1 /); // facility 13 (log audit) * 8 + severidade 4 (warning)
});

test('métricas Prometheus são expostas', () => {
  const text = app.deps.metrics.render();
  assert.match(text, /secureaccess_access_attempts_total\{building="COP",decision="LIBERADO",reason="OK"\} \d+/);
  assert.match(text, /secureaccess_jwt_rotations_total/);
});
