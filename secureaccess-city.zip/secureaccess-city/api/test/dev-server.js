'use strict';

// Sobe a API com o banco em memória (SQLite) para desenvolver o front sem
// MySQL. Uso: APP_ENV=development node test/dev-server.js
// Nunca use isto em staging/produção.

const http = require('node:http');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { createFakePool } = require('./fake-mysql');

const cfg = loadConfig();
if (!['development', 'test'].includes(cfg.appEnv)) {
  process.stderr.write('dev-server só pode rodar com APP_ENV=development ou test\n');
  process.exit(1);
}
const app = createApp({ cfg, pool: createFakePool() });
const server = http.createServer(app.handle);
const metrics = http.createServer(app.handleMetrics);

app.init().then(() => {
  app.startBackground();
  server.listen(cfg.port, () => process.stderr.write(`API (banco em memória) em http://localhost:${cfg.port}\n`));
  metrics.listen(cfg.metricsPort);
});

process.on('SIGTERM', () => process.exit(0));
process.on('SIGINT', () => process.exit(0));
