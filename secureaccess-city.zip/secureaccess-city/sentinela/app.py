"""Sentinela: monitoramento e SIEM do SecureAccess City.

Painel web (Flask) + motor de coleta no mesmo processo. Em produção roda com
gunicorn, um worker só (o receptor de syslog e o SQLite precisam de um dono
único) e várias threads.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import secrets
import sys
import time
from collections import defaultdict, deque
from datetime import timedelta
from functools import wraps

from flask import Flask, abort, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

from nucleo import config as configuracao
from nucleo import consultas
from nucleo.motor import Motor

VERSAO = os.environ.get("SENTINELA_VERSAO", "1.0.0")
PERFIS = {"ADMIN": "Administrador", "LEITURA": "Somente leitura"}


def _hash_senha(senha: str, sal: bytes) -> bytes:
    return hashlib.scrypt(senha.encode(), salt=sal, n=2 ** 14, r=8, p=1, dklen=32)


class Contas:
    """Usuários do painel. As senhas vêm do Secret e só ficam em memória como hash."""

    BLOQUEIO_FALHAS = 5
    BLOQUEIO_SEGUNDOS = 900

    def __init__(self, cfg):
        self.usuarios = {}
        for nome, senha, perfil in (("admin", cfg.senha_admin, "ADMIN"), ("avaliador", cfg.senha_avaliador, "LEITURA")):
            sal = secrets.token_bytes(16)
            self.usuarios[nome] = (sal, _hash_senha(senha, sal), perfil)
        self._sal_falso = secrets.token_bytes(16)
        self.falhas: dict[str, deque] = defaultdict(lambda: deque(maxlen=50))
        self.falhas_ip: dict[str, deque] = defaultdict(lambda: deque(maxlen=200))
        self.bloqueado_ate: dict[str, float] = {}

    def bloqueado(self, usuario: str, ip: str, agora: float) -> bool:
        if self.bloqueado_ate.get(usuario, 0) > agora:
            return True
        recentes_ip = [t for t in self.falhas_ip[ip] if agora - t < self.BLOQUEIO_SEGUNDOS]
        return len(recentes_ip) >= 20

    def verificar(self, usuario: str, senha: str, ip: str) -> tuple[str | None, str]:
        agora = time.time()
        if self.bloqueado(usuario, ip, agora):
            return None, "bloqueado"
        registro = self.usuarios.get(usuario)
        sal, esperado, perfil = registro if registro else (self._sal_falso, b"\0" * 32, None)
        ok = hmac.compare_digest(_hash_senha(senha, sal), esperado) and registro is not None
        if ok:
            self.falhas.pop(usuario, None)
            return perfil, "ok"
        self.falhas[usuario].append(agora)
        self.falhas_ip[ip].append(agora)
        recentes = [t for t in self.falhas[usuario] if agora - t < self.BLOQUEIO_SEGUNDOS]
        if registro and len(recentes) >= self.BLOQUEIO_FALHAS:
            self.bloqueado_ate[usuario] = agora + self.BLOQUEIO_SEGUNDOS
            self.falhas.pop(usuario, None)
            return None, "bloqueou"
        return None, "senha"


def _logs():
    logging.basicConfig(level=logging.INFO, stream=sys.stdout, format="%(message)s")


def create_app(cfg=None, motor: Motor | None = None, iniciar_motor: bool = True) -> Flask:
    _logs()
    cfg = cfg or configuracao.carregar()
    app = Flask(__name__)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    app.config.update(
        SECRET_KEY=cfg.chave_sessao,
        SESSION_COOKIE_NAME="__Host-sentinela" if cfg.producao else "sentinela",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SECURE=cfg.producao,
        SESSION_COOKIE_SAMESITE="Strict",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        MAX_CONTENT_LENGTH=16 * 1024,
        JSON_SORT_KEYS=False,
    )
    motor = motor or Motor(cfg)
    if iniciar_motor:
        motor.iniciar(coletores=cfg.coletores_ativos)
    contas = Contas(cfg)
    app.extensions["sentinela"] = {"motor": motor, "cfg": cfg, "contas": contas}

    fuso_nome = getattr(cfg.fuso, "key", None) or "America/Recife"

    # ------------------------------------------------------------- base --
    @app.after_request
    def cabecalhos(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; "
            "font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        if cfg.producao:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000"
        if request.path.startswith(("/api/", "/login")) or request.method == "POST":
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def csrf_token() -> str:
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(32)
        return session["csrf"]

    @app.context_processor
    def contexto():
        resumo = None
        if session.get("usuario"):
            try:
                resumo = motor.incidentes.resumo()
            except Exception:
                resumo = None
        return {"csrf_token": csrf_token(), "usuario": session.get("usuario"), "perfil": session.get("perfil"),
                "perfil_nome": PERFIS.get(session.get("perfil"), ""), "versao": VERSAO, "fuso": fuso_nome,
                "resumo_incidentes": resumo}

    @app.before_request
    def verificar_csrf():
        if request.method == "POST":
            enviado = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token") or ""
            if not session.get("csrf") or not hmac.compare_digest(enviado, session["csrf"]):
                abort(400, "Sessão expirada. Recarregue a página e tente de novo.")

    def ip_cliente() -> str:
        return (request.remote_addr or "")[:64]

    def registrar(acao: str, resultado: str, alvo: str = "", usuario: str | None = None) -> None:
        usuario = usuario or session.get("usuario") or "-"
        agora = time.time()
        try:
            with motor.store.transacao() as c:
                c.execute("INSERT INTO auditoria (ts, usuario, acao, alvo, ip, resultado) VALUES (?, ?, ?, ?, ?, ?)",
                          (agora, usuario[:64], acao, alvo[:128], ip_cliente(), resultado))
                if acao.startswith("LOGIN"):
                    tipo = "SENTINELA_LOGIN" if resultado == "ok" else "SENTINELA_LOGIN_FALHA"
                    resumo = (f"{usuario} entrou no Sentinela de {ip_cliente()}" if resultado == "ok" else
                              f"Falha de login no Sentinela para '{usuario}' de {ip_cliente()} ({resultado})")
                    c.execute("INSERT INTO eventos (ts, ambiente, fonte, categoria, tipo, severidade, resumo, ip, usuario) "
                              "VALUES (?, 'sentinela', 'sentinela', 'authentication', ?, ?, ?, ?, ?)",
                              (agora, tipo, 5 if resultado == "ok" else 4, resumo, ip_cliente(), usuario[:64]))
        except Exception:
            pass
        logging.getLogger("sentinela").info(json.dumps({"evento": f"SENTINELA_{acao}", "usuario": usuario,
                                                        "resultado": resultado, "ip": ip_cliente(), "alvo": alvo}))

    def login_obrigatorio(perfil: str | None = None):
        def decorador(f):
            @wraps(f)
            def envolvida(*args, **kwargs):
                if not session.get("usuario"):
                    if request.path.startswith("/api/"):
                        return jsonify({"erro": "SESSAO_EXPIRADA"}), 401
                    return redirect(url_for("login", proximo=request.path))
                if perfil and session.get("perfil") != perfil:
                    abort(403)
                g.usuario = session["usuario"]
                return f(*args, **kwargs)
            return envolvida
        return decorador

    # ------------------------------------------------------------ saúde --
    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}

    @app.get("/readyz")
    def readyz():
        try:
            motor.store.valor("SELECT 1")
        except Exception:
            return {"status": "banco indisponível"}, 503
        return {"status": "pronto", "versao": VERSAO}

    # ------------------------------------------------------------ login --
    @app.route("/login", methods=["GET", "POST"])
    def login():
        erro = None
        if request.method == "POST":
            usuario = (request.form.get("usuario") or "").strip().lower()[:32]
            senha = request.form.get("senha") or ""
            perfil, situacao = contas.verificar(usuario, senha[:256], ip_cliente())
            if perfil:
                session.clear()
                session.permanent = True
                session["usuario"] = usuario
                session["perfil"] = perfil
                session["csrf"] = secrets.token_urlsafe(32)
                registrar("LOGIN", "ok", usuario=usuario)
                destino = request.args.get("proximo") or "/"
                if not destino.startswith("/") or destino.startswith("//"):
                    destino = "/"
                return redirect(destino)
            registrar("LOGIN", situacao, usuario=usuario or "(vazio)")
            erro = ("Muitas tentativas. Aguarde 15 minutos." if situacao in ("bloqueado", "bloqueou")
                    else "Usuário ou senha inválidos.")
        return render_template("login.html", erro=erro), (401 if erro else 200)

    @app.post("/sair")
    def sair():
        if session.get("usuario"):
            registrar("SAIR", "ok")
        session.clear()
        return redirect(url_for("login"))

    # ------------------------------------------------------------ páginas --
    PAGINAS = {
        "visao": ("/", "Visão geral", consultas.visao, 10000),
        "disponibilidade": ("/disponibilidade", "Disponibilidade", consultas.disponibilidade, 15000),
        "infraestrutura": ("/infraestrutura", "Infraestrutura", consultas.infraestrutura, 15000),
        "seguranca": ("/seguranca", "Segurança", None, 8000),
        "syslog": ("/syslog", "Syslog", None, 8000),
        "incidentes": ("/incidentes", "Incidentes", None, 10000),
    }

    def pagina(nome: str, dados: dict):
        caminho, titulo, _, intervalo = PAGINAS[nome]
        return render_template(f"{nome}.html", pagina=nome, titulo=titulo, dados=dados, intervalo=intervalo,
                               api=f"/api/{nome}")

    def filtros_seguranca():
        a = request.args
        return dict(ambiente=a.get("ambiente", "")[:32], tipo=a.get("tipo", "")[:48], nivel=a.get("nivel", "")[:16],
                    busca=a.get("busca", "")[:60], antes=_inteiro(a.get("antes")))

    def filtros_syslog():
        a = request.args
        return dict(app=a.get("app", "")[:48], busca=a.get("busca", "")[:80], severidade=a.get("severidade", "")[:16],
                    antes=_inteiro(a.get("antes")))

    @app.get("/")
    @login_obrigatorio()
    def visao():
        return pagina("visao", consultas.visao(motor))

    @app.get("/disponibilidade")
    @login_obrigatorio()
    def disponibilidade():
        return pagina("disponibilidade", consultas.disponibilidade(motor))

    @app.get("/infraestrutura")
    @login_obrigatorio()
    def infraestrutura():
        return pagina("infraestrutura", consultas.infraestrutura(motor))

    @app.get("/seguranca")
    @login_obrigatorio()
    def seguranca():
        return pagina("seguranca", consultas.seguranca(motor, **filtros_seguranca()))

    @app.get("/syslog")
    @login_obrigatorio()
    def syslog():
        return pagina("syslog", consultas.syslog(motor, **filtros_syslog()))

    @app.get("/incidentes")
    @login_obrigatorio()
    def incidentes():
        status = "resolvidos" if request.args.get("status") == "resolvidos" else "ativos"
        return pagina("incidentes", consultas.incidentes(motor, status))

    # ------------------------------------------------------------- APIs --
    @app.get("/api/visao")
    @login_obrigatorio()
    def api_visao():
        return jsonify(consultas.visao(motor))

    @app.get("/api/disponibilidade")
    @login_obrigatorio()
    def api_disponibilidade():
        return jsonify(consultas.disponibilidade(motor))

    @app.get("/api/infraestrutura")
    @login_obrigatorio()
    def api_infraestrutura():
        return jsonify(consultas.infraestrutura(motor))

    @app.get("/api/seguranca")
    @login_obrigatorio()
    def api_seguranca():
        return jsonify(consultas.seguranca(motor, **filtros_seguranca()))

    @app.get("/api/syslog")
    @login_obrigatorio()
    def api_syslog():
        return jsonify(consultas.syslog(motor, **filtros_syslog()))

    @app.get("/api/incidentes")
    @login_obrigatorio()
    def api_incidentes():
        status = "resolvidos" if request.args.get("status") == "resolvidos" else "ativos"
        return jsonify(consultas.incidentes(motor, status))

    @app.post("/incidentes/<int:incidente_id>/<acao>")
    @login_obrigatorio("ADMIN")
    def tratar_incidente(incidente_id: int, acao: str):
        if acao == "reconhecer":
            ok = motor.incidentes.reconhecer(incidente_id, session["usuario"])
        elif acao == "resolver":
            ok = motor.incidentes.resolver_manual(incidente_id, session["usuario"])
        else:
            abort(404)
        registrar(f"INCIDENTE_{acao.upper()}", "ok" if ok else "ignorado", alvo=str(incidente_id))
        if request.headers.get("Accept", "").startswith("application/json"):
            return jsonify({"ok": ok})
        return redirect(url_for("incidentes"))

    @app.errorhandler(400)
    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(413)
    def erro_http(exc):
        codigo = getattr(exc, "code", 500)
        mensagens = {400: getattr(exc, "description", "Requisição inválida"),
                     403: "Seu perfil não tem permissão para esta ação.", 404: "Página não encontrada.",
                     413: "Requisição grande demais."}
        if request.path.startswith("/api/"):
            return jsonify({"erro": mensagens.get(codigo, "Erro")}), codigo
        return render_template("erro.html", codigo=codigo, mensagem=mensagens.get(codigo, "Erro")), codigo

    return app


def _inteiro(valor) -> int:
    try:
        return max(0, int(valor or 0))
    except (TypeError, ValueError):
        return 0


if __name__ == "__main__":
    aplicacao = create_app()
    aplicacao.run(host="127.0.0.1", port=int(os.environ.get("PORT", "8080")), threaded=True, use_reloader=False)
