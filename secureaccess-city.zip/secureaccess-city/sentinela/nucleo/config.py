"""Configuração do Sentinela, lida de variáveis de ambiente.

No Kubernetes, as variáveis vêm do ConfigMap (o que não é segredo) e do
Secret (senhas e tokens). Em desenvolvimento, tudo tem valor padrão.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import timedelta, timezone, tzinfo


class ConfigError(ValueError):
    pass


def _env(nome: str, padrao: str | None = None) -> str | None:
    valor = os.environ.get(nome)
    if valor is None or valor.strip() == "":
        return padrao
    return valor.strip()


def _int(nome: str, padrao: int, minimo: int | None = None, maximo: int | None = None) -> int:
    bruto = _env(nome)
    if bruto is None:
        return padrao
    try:
        valor = int(bruto)
    except ValueError as exc:
        raise ConfigError(f"{nome} precisa ser um número inteiro") from exc
    if minimo is not None and valor < minimo:
        raise ConfigError(f"{nome} precisa ser no mínimo {minimo}")
    if maximo is not None and valor > maximo:
        raise ConfigError(f"{nome} precisa ser no máximo {maximo}")
    return valor


def _bool(nome: str, padrao: bool) -> bool:
    bruto = _env(nome)
    if bruto is None:
        return padrao
    return bruto.lower() in ("1", "true", "sim", "yes", "on")


def fuso(nome: str) -> tzinfo:
    """Fuso para exibir horários. Recife não tem horário de verão desde 2019."""
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(nome)
    except Exception:  # imagem sem tzdata
        return timezone(timedelta(hours=-3), "BRT")


@dataclass
class Ambiente:
    id: str
    nome: str
    url: str
    namespace: str
    app_env: str
    rotacao_jwt_segundos: int
    ordem: int = 9


@dataclass
class Limiares:
    latencia_ms: int = 2000
    cpu_pct: int = 90
    memoria_pct: int = 85
    disco_pct: int = 80
    certificado_dias: int = 14
    ssh_falhas: int = 10
    login_falhas: int = 5
    silencio_min: int = 15
    erros_5xx_pct: int = 5
    pico_alertas: int = 20


@dataclass
class Config:
    ambiente_execucao: str
    banco: str
    chave_sessao: str
    senha_admin: str
    senha_avaliador: str
    syslog_porta: int
    syslog_origens: list[str]
    ambientes: list[Ambiente]
    limiares: Limiares
    intervalo_checagens: int
    intervalo_kube: int
    kube_ativo: bool
    kube_url: str
    kube_token_arquivo: str
    kube_ca_arquivo: str | None
    retencao_syslog_horas: int
    retencao_eventos_dias: int
    telegram_token: str | None
    telegram_chat: str | None
    url_publica: str | None
    fuso: tzinfo
    no_nome: str | None = None
    coletores_ativos: bool = True
    extras: dict = field(default_factory=dict)

    @property
    def producao(self) -> bool:
        return self.ambiente_execucao == "production"


def _ambientes(bruto: str | None) -> list[Ambiente]:
    if not bruto:
        return []
    try:
        dados = json.loads(bruto)
    except json.JSONDecodeError as exc:
        raise ConfigError("SENTINELA_AMBIENTES precisa ser um JSON válido") from exc
    itens = dados.items() if isinstance(dados, dict) else enumerate(dados)
    ambientes = []
    for chave, a in itens:
        if not isinstance(a, dict) or a.get("ativo") is False:
            continue
        ident = str(a.get("id") or chave)
        ambientes.append(Ambiente(
            id=ident,
            nome=str(a.get("nome") or ident),
            url=str(a.get("url") or "").rstrip("/"),
            namespace=str(a.get("namespace") or ""),
            app_env=str(a.get("appEnv") or a.get("app_env") or ident),
            rotacao_jwt_segundos=int(a.get("rotacaoJwtSegundos") or a.get("rotacao_jwt_segundos") or 3600),
            ordem=int(a.get("ordem") or 9),
        ))
    ambientes.sort(key=lambda a: (a.ordem, a.id))
    for a in ambientes:
        if a.url and not a.url.startswith(("http://", "https://")):
            raise ConfigError(f"URL do ambiente {a.id} precisa começar com http:// ou https://")
    return ambientes


AMBIENTES_PADRAO = json.dumps({
    "producao": {"nome": "Produção", "url": "", "namespace": "secureaccess-prod", "appEnv": "production",
                 "rotacaoJwtSegundos": 3600, "ordem": 1},
    "homologacao": {"nome": "Homologação", "url": "", "namespace": "secureaccess-staging", "appEnv": "staging",
                    "rotacaoJwtSegundos": 900, "ordem": 2},
})


def carregar() -> Config:
    execucao = (_env("SENTINELA_ENV", "development") or "development").lower()
    if execucao not in ("development", "test", "production"):
        raise ConfigError("SENTINELA_ENV precisa ser development, test ou production")
    dev = execucao != "production"

    chave = _env("SENTINELA_SECRET_KEY")
    senha_admin = _env("SENTINELA_ADMIN_PASSWORD")
    senha_avaliador = _env("SENTINELA_AVALIADOR_PASSWORD")
    if not dev:
        faltando = [n for n, v in (("SENTINELA_SECRET_KEY", chave), ("SENTINELA_ADMIN_PASSWORD", senha_admin),
                                   ("SENTINELA_AVALIADOR_PASSWORD", senha_avaliador)) if not v]
        if faltando:
            raise ConfigError("Faltam segredos obrigatórios: " + ", ".join(faltando))
        if len(chave) < 32:
            raise ConfigError("SENTINELA_SECRET_KEY precisa ter pelo menos 32 caracteres")
        for nome, senha in (("SENTINELA_ADMIN_PASSWORD", senha_admin), ("SENTINELA_AVALIADOR_PASSWORD", senha_avaliador)):
            if len(senha) < 12:
                raise ConfigError(f"{nome} precisa ter pelo menos 12 caracteres")

    origens = [o.strip() for o in (_env("SENTINELA_SYSLOG_ORIGENS", "") or "").split(",") if o.strip()]

    return Config(
        ambiente_execucao=execucao,
        banco=_env("SENTINELA_DB", "sentinela-dev.db"),
        chave_sessao=chave or "chave-de-desenvolvimento-nao-use-em-producao-0000",
        senha_admin=senha_admin or "Admin@Sentinela1",
        senha_avaliador=senha_avaliador or "Avaliador@Sentinela1",
        syslog_porta=_int("SENTINELA_SYSLOG_PORTA", 5514, 1, 65535),
        syslog_origens=origens,
        ambientes=_ambientes(_env("SENTINELA_AMBIENTES", AMBIENTES_PADRAO)),
        limiares=Limiares(
            latencia_ms=_int("SENTINELA_LIMIAR_LATENCIA_MS", 2000, 100),
            cpu_pct=_int("SENTINELA_LIMIAR_CPU_PCT", 90, 10, 100),
            memoria_pct=_int("SENTINELA_LIMIAR_MEMORIA_PCT", 85, 10, 100),
            disco_pct=_int("SENTINELA_LIMIAR_DISCO_PCT", 80, 10, 100),
            certificado_dias=_int("SENTINELA_LIMIAR_CERTIFICADO_DIAS", 14, 1),
            ssh_falhas=_int("SENTINELA_LIMIAR_SSH_FALHAS", 10, 2),
            login_falhas=_int("SENTINELA_LIMIAR_LOGIN_FALHAS", 5, 2),
            silencio_min=_int("SENTINELA_LIMIAR_SILENCIO_MIN", 15, 2),
            erros_5xx_pct=_int("SENTINELA_LIMIAR_ERROS_5XX_PCT", 5, 1, 100),
            pico_alertas=_int("SENTINELA_LIMIAR_PICO_ALERTAS", 20, 2),
        ),
        intervalo_checagens=_int("SENTINELA_INTERVALO_CHECAGENS", 30, 5),
        intervalo_kube=_int("SENTINELA_INTERVALO_KUBE", 20, 5),
        kube_ativo=_bool("SENTINELA_KUBE", not dev),
        kube_url=_env("SENTINELA_KUBE_URL", "https://kubernetes.default.svc"),
        kube_token_arquivo=_env("SENTINELA_KUBE_TOKEN_ARQUIVO", "/var/run/secrets/kubernetes.io/serviceaccount/token"),
        kube_ca_arquivo=_env("SENTINELA_KUBE_CA_ARQUIVO", "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"),
        retencao_syslog_horas=_int("SENTINELA_RETENCAO_SYSLOG_HORAS", 24, 1),
        retencao_eventos_dias=_int("SENTINELA_RETENCAO_EVENTOS_DIAS", 7, 1),
        telegram_token=_env("SENTINELA_TELEGRAM_TOKEN"),
        telegram_chat=_env("SENTINELA_TELEGRAM_CHAT"),
        url_publica=_env("SENTINELA_URL_PUBLICA"),
        fuso=fuso(_env("SENTINELA_FUSO", "America/Recife")),
        no_nome=_env("SENTINELA_NO"),
        coletores_ativos=_bool("SENTINELA_COLETORES", True),
    )
