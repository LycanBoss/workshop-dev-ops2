"""Consultas que alimentam as páginas do painel (sempre devolvem JSON simples)."""
from __future__ import annotations

import time

from .eventos import ALERTAS, MOTIVOS, TIPOS
from .incidentes import SEVERIDADE_PT, para_json
from .regras import CATALOGO

HORA = 3600
DIA = 86400


def _uptime(store, alvo: str, desde: float) -> float | None:
    r = store.um("SELECT COUNT(*) AS n, SUM(ok) AS ok FROM checagens WHERE alvo = ? AND ts >= ?", (alvo, desde))
    if not r or not r["n"]:
        return None
    return round(100.0 * (r["ok"] or 0) / r["n"], 2)


def _latencia_media(store, alvo: str, desde: float) -> float | None:
    v = store.valor("SELECT AVG(latencia_ms) FROM checagens WHERE alvo = ? AND ts >= ? AND ok = 1", (alvo, desde))
    return round(v, 1) if v is not None else None


def _serie_latencia(store, alvo: str, desde: float, passo: int) -> list:
    return [[r["t"], round(r["v"], 1) if r["v"] is not None else None] for r in store.q(
        "SELECT CAST(ts / ? AS INTEGER) * ? AS t, AVG(CASE WHEN ok = 1 THEN latencia_ms END) AS v "
        "FROM checagens WHERE alvo = ? AND ts >= ? GROUP BY t ORDER BY t", (passo, passo, alvo, desde))]


def _contagem_minutos(store, serie: str, desde: float, passo_min: int = 1) -> list:
    if passo_min == 1:
        return store.contagem_por_minuto(serie, desde)
    return [[r["t"] * 60, r["v"]] for r in store.q(
        "SELECT (minuto / ?) * ? AS t, SUM(valor) AS v FROM contadores WHERE serie = ? AND minuto >= ? GROUP BY t ORDER BY t",
        (passo_min, passo_min, serie, int(desde // 60)))]


def incidentes_abertos(store, limite: int = 50) -> list[dict]:
    return [para_json(i) for i in store.q(
        "SELECT * FROM incidentes WHERE status != 'RESOLVIDO' ORDER BY "
        "CASE severidade WHEN 'CRITICA' THEN 0 WHEN 'ALTA' THEN 1 WHEN 'MEDIA' THEN 2 ELSE 3 END, "
        "CASE status WHEN 'ABERTO' THEN 0 ELSE 1 END, atualizado_em DESC LIMIT ?", (limite,))]


def _agente_mais_recente(store) -> tuple[str | None, float | None, dict | None]:
    r = store.um("SELECT chave, ts, valor FROM estado WHERE chave LIKE 'agente:%' ORDER BY ts DESC LIMIT 1")
    if not r:
        return None, None, None
    import json
    return r["chave"].split(":", 1)[1], r["ts"], json.loads(r["valor"])


def servidor(store) -> dict:
    host, ts, metricas = _agente_mais_recente(store)
    ficha = store.estado(f"ficha:{host}") if host else None
    kube = store.estado("kube") or {}
    no = (kube.get("nos") or [None])[0]
    return {"host": host or (no or {}).get("nome"), "metricas": metricas, "metricas_ts": ts, "ficha": ficha, "no": no,
            "agente": bool(host)}


def visao(motor) -> dict:
    store, cfg = motor.store, motor.cfg
    agora = time.time()
    kube = store.estado("kube") or {}
    pods = kube.get("pods") or []
    ambientes = []
    lat_series = {}
    for a in cfg.ambientes:
        checks = {}
        for parte in ("api", "front"):
            checks[parte] = store.estado(f"check:{a.id}:{parte}")
        tls = None
        if a.url.startswith("https://"):
            host = a.url.split("/")[2].split(":")[0]
            tls = store.estado(f"tls:{host}")
        meus_pods = [p for p in pods if p["namespace"] == a.namespace and p["fase"] != "Succeeded"]
        app = store.estado(f"app:{a.id}") or {}
        ambientes.append({
            "id": a.id, "nome": a.nome, "url": a.url, "namespace": a.namespace,
            "checks": checks,
            "uptime_24h": _uptime(store, f"{a.id}:api", agora - DIA),
            "latencia_1h": _latencia_media(store, f"{a.id}:api", agora - HORA),
            "tls": tls,
            "pods": {"prontos": sum(1 for p in meus_pods if p["pronto"]), "total": len(meus_pods),
                     "reinicios": sum(p["reinicios"] for p in meus_pods)},
            "negados_1h": store.contagem(f"acesso_negado:{a.id}", agora - HORA),
            "liberados_1h": store.contagem(f"acesso_liberado:{a.id}", agora - HORA),
            "alertas_1h": store.contagem(f"alerta:{a.id}", agora - HORA),
            "login_falhas_1h": store.contagem(f"login_falha:{a.id}", agora - HORA),
            "requisicoes_1h": store.contagem(f"http:{a.id}", agora - HORA),
            "erros5xx_1h": store.contagem(f"http5xx:{a.id}", agora - HORA),
            "jwt": {"idade": app.get("jwt_idade"), "intervalo": a.rotacao_jwt_segundos, "chaves": app.get("jwt_chaves"),
                    "ultima_rotacao": store.estado_ts(f"rotacao:{a.id}")},
            "db_up": app.get("db_up"),
            "ultimo_syslog": store.estado_ts(f"syslog_visto:{a.id}"),
        })
        lat_series[a.id] = _serie_latencia(store, f"{a.id}:api", agora - HORA, 60)

    eventos_series = {}
    for nome, prefixo in (("negados", "acesso_negado"), ("liberados", "acesso_liberado"), ("alertas", "alerta")):
        soma: dict[float, float] = {}
        for a in cfg.ambientes:
            for t, v in store.contagem_por_minuto(f"{prefixo}:{a.id}", agora - HORA):
                soma[t] = soma.get(t, 0) + v
        eventos_series[nome] = sorted([[t, v] for t, v in soma.items()])

    feed = store.q("SELECT id, ts, ambiente, fonte, tipo, severidade, resumo FROM eventos "
                   "WHERE severidade <= 4 ORDER BY id DESC LIMIT 12")
    total_5min = store.contagem("syslog", agora - 300)
    por_app = store.q("SELECT substr(serie, 8) AS app, SUM(valor) AS n FROM contadores WHERE serie LIKE 'syslog:%' "
                      "AND serie NOT IN ('syslog:aviso_ou_pior', 'syslog:json_invalido', 'syslog:erro_processamento') "
                      "AND minuto >= ? GROUP BY serie ORDER BY n DESC LIMIT 6", (int((agora - HORA) // 60),))
    abertos = incidentes_abertos(store, 8)
    resumo = motor.incidentes.resumo()
    sev = resumo["por_severidade"]
    if sev.get("CRITICA"):
        geral = {"nivel": "critico", "texto": f"{sev['CRITICA']} incidente(s) crítico(s)"}
    elif resumo["abertos"] or resumo["reconhecidos"]:
        n = resumo["abertos"] + resumo["reconhecidos"]
        geral = {"nivel": "atencao", "texto": f"{n} incidente(s) em aberto"}
    else:
        geral = {"nivel": "ok", "texto": "Tudo operando normalmente"}
    return {
        "agora": agora,
        "geral": geral,
        "incidentes": {"resumo": resumo, "abertos": abertos},
        "ambientes": ambientes,
        "servidor": servidor(store),
        "cluster": {"pods_prontos": sum(1 for p in pods if p["pronto"]),
                    "pods_total": sum(1 for p in pods if p["fase"] != "Succeeded"),
                    "avisos": len(kube.get("eventos") or []), "ts": kube.get("ts")},
        "syslog": {"por_min": round(total_5min / 5, 1), "total_24h": store.contagem("syslog", agora - DIA),
                   "por_app": por_app, "saude": motor.saude()["syslog"]},
        "graficos": {"latencia": lat_series, "eventos": eventos_series},
        "feed": feed,
        "nomes_ambientes": {**{a.id: a.nome for a in cfg.ambientes}, "servidor": "Servidor", "sentinela": "Sentinela"},
        "nomes_tipos": TIPOS,
    }


def disponibilidade(motor) -> dict:
    store, cfg = motor.store, motor.cfg
    agora = time.time()
    alvos = []
    series = {}
    for a, alvo, nome, url, _ in motor.alvos():
        estado = store.estado(f"check:{alvo}") or {}
        ultimas_falhas = store.q("SELECT ts, status, erro FROM checagens WHERE alvo = ? AND ok = 0 ORDER BY ts DESC LIMIT 5",
                                 (alvo,))
        alvos.append({
            "alvo": alvo, "nome": nome, "ambiente": a.nome, "url": url, "estado": estado,
            "uptime_1h": _uptime(store, alvo, agora - HORA), "uptime_24h": _uptime(store, alvo, agora - DIA),
            "uptime_7d": _uptime(store, alvo, agora - 7 * DIA),
            "latencia_1h": _latencia_media(store, alvo, agora - HORA),
            "latencia_24h": _latencia_media(store, alvo, agora - DIA),
            "checagens_24h": store.valor("SELECT COUNT(*) FROM checagens WHERE alvo = ? AND ts >= ?", (alvo, agora - DIA), 0),
            "falhas": ultimas_falhas,
        })
        series[alvo] = _serie_latencia(store, alvo, agora - 6 * HORA, 300)
    tls = [v for _, (_, v) in store.estados("tls:").items()]
    kube = store.estado("kube") or {}
    return {"agora": agora, "alvos": alvos, "series": series, "tls": tls, "certificados": kube.get("certificados") or [],
            "intervalo": cfg.intervalo_checagens, "limite_latencia": cfg.limiares.latencia_ms}


def infraestrutura(motor) -> dict:
    store = motor.store
    agora = time.time()
    srv = servidor(store)
    host = srv["host"]
    series = {}
    if srv["agente"]:
        for chave in ("cpu_pct", "mem_pct", "disco_pct", "load1"):
            series[chave] = store.serie(f"servidor:{host}:{chave}", agora - 6 * HORA, 300)
    elif srv["no"]:
        series["cpu_pct"] = store.serie(f"no:{host}:cpu_pct", agora - 6 * HORA, 300)
        series["mem_pct"] = store.serie(f"no:{host}:mem_pct", agora - 6 * HORA, 300)
    kube = store.estado("kube") or {}
    erro = store.estado("kube:erro")
    pods = sorted(kube.get("pods") or [], key=lambda p: (p["namespace"] or "", p["nome"] or ""))
    return {"agora": agora, "servidor": srv, "series": series, "pods": pods, "eventos": kube.get("eventos") or [],
            "certificados": kube.get("certificados") or [], "nos": kube.get("nos") or [], "kube_ts": kube.get("ts"),
            "kube_avisos": kube.get("avisos") or [], "kube_erro": erro if erro and (kube.get("ts") or 0) < store.estado_ts("kube:erro") else None,
            "kube_ativo": bool(motor.kube),
            "apps": {a.id: store.estado(f"app:{a.id}") for a in motor.cfg.ambientes},
            "nomes_ambientes": {a.id: a.nome for a in motor.cfg.ambientes},
            "namespaces_ambientes": {a.namespace: a.nome for a in motor.cfg.ambientes}}


def seguranca(motor, ambiente: str = "", tipo: str = "", nivel: str = "", busca: str = "", antes: int = 0,
              limite: int = 50) -> dict:
    store = motor.store
    agora = time.time()
    filtros, params = ["1 = 1"], []
    if ambiente:
        filtros.append("ambiente = ?")
        params.append(ambiente)
    if tipo:
        filtros.append("tipo = ?")
        params.append(tipo)
    if nivel == "aviso":
        filtros.append("severidade <= 4")
    elif nivel == "critico":
        filtros.append("severidade <= 3")
    if busca:
        filtros.append("(resumo LIKE ? OR porta LIKE ? OR cracha LIKE ? OR ip LIKE ? OR usuario LIKE ?)")
        termo = f"%{busca[:60]}%"
        params += [termo] * 5
    if antes:
        filtros.append("id < ?")
        params.append(antes)
    where = " AND ".join(filtros)
    feed = store.q(f"SELECT id, ts, ambiente, fonte, categoria, tipo, severidade, resumo, porta, predio, cracha, motivo, ip, "
                   f"usuario, host FROM eventos WHERE {where} ORDER BY id DESC LIMIT ?", (*params, limite))
    desde = agora - DIA
    contagens = {r["tipo"]: r["n"] for r in store.q(
        "SELECT tipo, COUNT(*) AS n FROM eventos WHERE ts >= ? GROUP BY tipo", (desde,))}
    por_motivo = store.q("SELECT motivo, COUNT(*) AS n FROM eventos WHERE tipo = 'ACESSO_NEGADO' AND ts >= ? "
                         "GROUP BY motivo ORDER BY n DESC LIMIT 10", (desde,))
    for r in por_motivo:
        r["nome"] = MOTIVOS.get(r["motivo"], r["motivo"])
    por_alerta = store.q("SELECT motivo, COUNT(*) AS n FROM eventos WHERE tipo = 'ALERTA_SEGURANCA' AND ts >= ? "
                         "GROUP BY motivo ORDER BY n DESC LIMIT 10", (desde,))
    for r in por_alerta:
        r["nome"] = ALERTAS.get(r["motivo"], r["motivo"])
    top_portas = store.q("SELECT porta, COUNT(*) AS n FROM eventos WHERE tipo IN ('ACESSO_NEGADO', 'ALERTA_SEGURANCA') "
                         "AND ts >= ? AND porta IS NOT NULL GROUP BY porta ORDER BY n DESC LIMIT 8", (desde,))
    top_ips = store.q("SELECT ip, COUNT(*) AS n, MAX(ts) AS ultimo FROM eventos WHERE tipo IN ('SSH_FALHA', "
                      "'SSH_USUARIO_INVALIDO', 'LOGIN_FALHA', 'SENTINELA_LOGIN_FALHA') AND ts >= ? AND ip IS NOT NULL "
                      "GROUP BY ip ORDER BY n DESC LIMIT 8", (desde,))
    tipos_presentes = [r["tipo"] for r in store.q("SELECT DISTINCT tipo FROM eventos WHERE ts >= ? ORDER BY tipo",
                                                   (agora - 7 * DIA,))]
    ambientes = [r["ambiente"] for r in store.q("SELECT DISTINCT ambiente FROM eventos ORDER BY ambiente")]
    serie = {}
    for nome, tipos in (("negados", ("ACESSO_NEGADO",)), ("alertas", ("ALERTA_SEGURANCA",)),
                        ("autenticacao", ("LOGIN_FALHA", "SSH_FALHA", "SSH_USUARIO_INVALIDO", "SENTINELA_LOGIN_FALHA",
                                          "TOKEN_REJEITADO", "SUDO_FALHA"))):
        marcadores = ",".join("?" * len(tipos))
        serie[nome] = [[r["t"], r["n"]] for r in store.q(
            f"SELECT CAST(ts / 900 AS INTEGER) * 900 AS t, COUNT(*) AS n FROM eventos WHERE tipo IN ({marcadores}) "
            f"AND ts >= ? GROUP BY t ORDER BY t", (*tipos, desde))]
    return {
        "agora": agora, "feed": feed, "contagens": contagens, "por_motivo": por_motivo, "por_alerta": por_alerta,
        "top_portas": top_portas, "top_ips": top_ips, "tipos": [{"id": t, "nome": TIPOS.get(t, t)} for t in tipos_presentes],
        "ambientes": ambientes, "serie": serie, "nomes_tipos": TIPOS,
        "nomes_ambientes": {**{a.id: a.nome for a in motor.cfg.ambientes}, "servidor": "Servidor", "sentinela": "Sentinela"},
        "filtros": {"ambiente": ambiente, "tipo": tipo, "nivel": nivel, "busca": busca},
    }


def syslog(motor, app: str = "", busca: str = "", severidade: str = "", antes: int = 0, limite: int = 50) -> dict:
    store = motor.store
    agora = time.time()
    filtros, params = ["1 = 1"], []
    if app:
        filtros.append("app = ?")
        params.append(app)
    if severidade == "aviso":
        filtros.append("severidade <= 4")
    if busca:
        filtros.append("(mensagem LIKE ? OR host LIKE ? OR msgid LIKE ?)")
        termo = f"%{busca[:80]}%"
        params += [termo] * 3
    if antes:
        filtros.append("id < ?")
        params.append(antes)
    linhas = store.q(f"SELECT id, recebido, origem, protocolo, facility, severidade, host, app, msgid, "
                     f"substr(mensagem, 1, 1200) AS mensagem FROM syslog_bruto WHERE {' AND '.join(filtros)} "
                     f"ORDER BY id DESC LIMIT ?", (*params, limite))
    por_app = store.q("SELECT app, COUNT(*) AS n, MAX(recebido) AS ultimo, COUNT(DISTINCT host) AS hosts "
                      "FROM syslog_bruto WHERE recebido >= ? GROUP BY app ORDER BY n DESC", (agora - DIA,))
    principais = [r["app"] or "(sem app)" for r in por_app[:4]]
    series = {nome: _contagem_minutos(store, f"syslog:{nome}", agora - HORA) for nome in principais}
    return {"agora": agora, "linhas": linhas, "por_app": por_app, "series": series,
            "total_24h": store.contagem("syslog", agora - DIA), "por_min": round(store.contagem("syslog", agora - 300) / 5, 1),
            "avisos_24h": store.contagem("syslog:aviso_ou_pior", agora - DIA),
            "saude": motor.saude()["syslog"], "porta": motor.cfg.syslog_porta,
            "filtros": {"app": app, "busca": busca, "severidade": severidade},
            "apps": [r["app"] for r in por_app if r["app"]]}


def incidentes(motor, status: str = "ativos") -> dict:
    store = motor.store
    if status == "resolvidos":
        lista = [para_json(i) for i in store.q(
            "SELECT * FROM incidentes WHERE status = 'RESOLVIDO' ORDER BY resolvido_em DESC LIMIT 100")]
    else:
        lista = incidentes_abertos(store, 200)
    resolvidos_24h = store.valor("SELECT COUNT(*) FROM incidentes WHERE status = 'RESOLVIDO' AND resolvido_em >= ?",
                                 (time.time() - DIA,), 0)
    return {"agora": time.time(), "status": status, "lista": lista, "resumo": motor.incidentes.resumo(),
            "resolvidos_24h": resolvidos_24h,
            "catalogo": [{"regra": r, "severidade": SEVERIDADE_PT[s], "descricao": d} for r, s, d in CATALOGO],
            "limiares": vars(motor.cfg.limiares), "telegram": motor.notificador.ativo}
