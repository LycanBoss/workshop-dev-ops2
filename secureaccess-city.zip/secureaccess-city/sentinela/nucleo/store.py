"""Armazenamento do Sentinela em SQLite (um arquivo no volume persistente).

Uma conexão por thread, modo WAL (leitura e escrita ao mesmo tempo) e
retenção automática: o syslog bruto fica 24 h, os eventos ficam 7 dias.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import contextmanager

ESQUEMA = """
CREATE TABLE IF NOT EXISTS syslog_bruto (
  id INTEGER PRIMARY KEY,
  recebido REAL NOT NULL,
  origem TEXT, protocolo TEXT,
  facility INTEGER, severidade INTEGER,
  host TEXT, app TEXT, msgid TEXT,
  mensagem TEXT
);
CREATE INDEX IF NOT EXISTS syslog_recebido ON syslog_bruto(recebido);
CREATE INDEX IF NOT EXISTS syslog_app ON syslog_bruto(app, recebido);

CREATE TABLE IF NOT EXISTS eventos (
  id INTEGER PRIMARY KEY,
  ts REAL NOT NULL,
  ambiente TEXT, fonte TEXT, categoria TEXT, tipo TEXT,
  severidade INTEGER,
  resumo TEXT,
  porta TEXT, predio TEXT, cracha TEXT, motivo TEXT, ip TEXT, usuario TEXT, host TEXT,
  dados TEXT
);
CREATE INDEX IF NOT EXISTS eventos_ts ON eventos(ts);
CREATE INDEX IF NOT EXISTS eventos_tipo ON eventos(tipo, ts);
CREATE INDEX IF NOT EXISTS eventos_amb ON eventos(ambiente, ts);

CREATE TABLE IF NOT EXISTS checagens (
  id INTEGER PRIMARY KEY,
  ts REAL NOT NULL,
  alvo TEXT NOT NULL,
  ok INTEGER NOT NULL,
  status INTEGER,
  latencia_ms REAL,
  erro TEXT
);
CREATE INDEX IF NOT EXISTS checagens_alvo ON checagens(alvo, ts);

CREATE TABLE IF NOT EXISTS amostras (
  ts REAL NOT NULL,
  serie TEXT NOT NULL,
  valor REAL
);
CREATE INDEX IF NOT EXISTS amostras_serie ON amostras(serie, ts);

CREATE TABLE IF NOT EXISTS contadores (
  minuto INTEGER NOT NULL,
  serie TEXT NOT NULL,
  valor INTEGER NOT NULL,
  PRIMARY KEY (minuto, serie)
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS estado (
  chave TEXT PRIMARY KEY,
  ts REAL NOT NULL,
  valor TEXT
);

CREATE TABLE IF NOT EXISTS incidentes (
  id INTEGER PRIMARY KEY,
  regra TEXT NOT NULL,
  chave TEXT NOT NULL,
  severidade TEXT NOT NULL,
  titulo TEXT NOT NULL,
  detalhe TEXT,
  alvo TEXT,
  status TEXT NOT NULL,
  por_condicao INTEGER NOT NULL DEFAULT 1,
  aberto_em REAL NOT NULL,
  atualizado_em REAL NOT NULL,
  resolvido_em REAL,
  reconhecido_por TEXT,
  resolucao TEXT,
  ocorrencias INTEGER NOT NULL DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS incidentes_ativos ON incidentes(chave) WHERE status != 'RESOLVIDO';
CREATE INDEX IF NOT EXISTS incidentes_status ON incidentes(status, atualizado_em);

CREATE TABLE IF NOT EXISTS auditoria (
  id INTEGER PRIMARY KEY,
  ts REAL NOT NULL,
  usuario TEXT, acao TEXT, alvo TEXT, ip TEXT, resultado TEXT
);
"""


class Store:
    def __init__(self, caminho: str):
        self.caminho = caminho
        self._local = threading.local()
        self._trava_escrita = threading.Lock()
        with self.conexao() as c:
            c.executescript(ESQUEMA)

    def conexao(self) -> sqlite3.Connection:
        con = getattr(self._local, "con", None)
        if con is None:
            con = sqlite3.connect(self.caminho, timeout=10, isolation_level=None, check_same_thread=False)
            con.row_factory = sqlite3.Row
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA synchronous=NORMAL")
            con.execute("PRAGMA busy_timeout=10000")
            con.execute("PRAGMA foreign_keys=ON")
            self._local.con = con
        return con

    # ------------------------------------------------------------ básicos --
    def q(self, sql: str, params=()) -> list[dict]:
        return [dict(r) for r in self.conexao().execute(sql, params).fetchall()]

    def um(self, sql: str, params=()) -> dict | None:
        r = self.conexao().execute(sql, params).fetchone()
        return dict(r) if r else None

    def valor(self, sql: str, params=(), padrao=None):
        r = self.conexao().execute(sql, params).fetchone()
        return padrao if r is None or r[0] is None else r[0]

    @contextmanager
    def transacao(self):
        # Uma escrita por vez neste processo; o SQLite cuida do resto.
        with self._trava_escrita:
            con = self.conexao()
            con.execute("BEGIN IMMEDIATE")
            try:
                yield con
            except BaseException:
                con.execute("ROLLBACK")
                raise
            else:
                con.execute("COMMIT")

    def executar(self, sql: str, params=()) -> int:
        with self.transacao() as c:
            cur = c.execute(sql, params)
            return cur.lastrowid

    # -------------------------------------------------------------- estado --
    def gravar_estado(self, chave: str, valor, ts: float | None = None) -> None:
        self.executar(
            "INSERT INTO estado (chave, ts, valor) VALUES (?, ?, ?) "
            "ON CONFLICT(chave) DO UPDATE SET ts = excluded.ts, valor = excluded.valor",
            (chave, ts or time.time(), json.dumps(valor, ensure_ascii=False, default=str)),
        )

    def estado(self, chave: str, padrao=None):
        r = self.um("SELECT ts, valor FROM estado WHERE chave = ?", (chave,))
        if not r:
            return padrao
        try:
            return json.loads(r["valor"])
        except (TypeError, ValueError):
            return padrao

    def estado_ts(self, chave: str) -> float | None:
        return self.valor("SELECT ts FROM estado WHERE chave = ?", (chave,))

    def estados(self, prefixo: str) -> dict[str, tuple[float, object]]:
        saida = {}
        for r in self.q("SELECT chave, ts, valor FROM estado WHERE chave LIKE ?", (prefixo + "%",)):
            try:
                saida[r["chave"]] = (r["ts"], json.loads(r["valor"]))
            except (TypeError, ValueError):
                continue
        return saida

    # ------------------------------------------------------------ séries --
    def amostra(self, serie: str, valor: float, ts: float | None = None) -> None:
        self.executar("INSERT INTO amostras (ts, serie, valor) VALUES (?, ?, ?)", (ts or time.time(), serie, valor))

    def amostras(self, series: list[tuple[str, float]], ts: float | None = None) -> None:
        if not series:
            return
        agora = ts or time.time()
        with self.transacao() as c:
            c.executemany("INSERT INTO amostras (ts, serie, valor) VALUES (?, ?, ?)", [(agora, s, v) for s, v in series])

    def serie(self, serie: str, desde: float, passo: int = 60) -> list[list[float]]:
        """Média por intervalo de `passo` segundos (para gráficos)."""
        linhas = self.q(
            "SELECT CAST(ts / ? AS INTEGER) * ? AS t, AVG(valor) AS v FROM amostras "
            "WHERE serie = ? AND ts >= ? GROUP BY t ORDER BY t",
            (passo, passo, serie, desde),
        )
        return [[r["t"], round(r["v"], 3)] for r in linhas]

    def ultimo(self, serie: str) -> tuple[float, float] | None:
        r = self.um("SELECT ts, valor FROM amostras WHERE serie = ? ORDER BY ts DESC LIMIT 1", (serie,))
        return (r["ts"], r["valor"]) if r else None

    def contar(self, c: sqlite3.Connection, minuto: int, serie: str, n: int = 1) -> None:
        c.execute(
            "INSERT INTO contadores (minuto, serie, valor) VALUES (?, ?, ?) "
            "ON CONFLICT(minuto, serie) DO UPDATE SET valor = valor + excluded.valor",
            (minuto, serie, n),
        )

    def contagem(self, serie: str, desde: float) -> int:
        return int(self.valor("SELECT SUM(valor) FROM contadores WHERE serie = ? AND minuto >= ?",
                              (serie, int(desde // 60)), 0))

    def contagem_por_minuto(self, serie: str, desde: float) -> list[list[float]]:
        return [[r["minuto"] * 60, r["valor"]] for r in self.q(
            "SELECT minuto, valor FROM contadores WHERE serie = ? AND minuto >= ? ORDER BY minuto",
            (serie, int(desde // 60)))]

    # ----------------------------------------------------------- retenção --
    def limpar(self, syslog_horas: int, eventos_dias: int, limite_syslog: int = 150_000) -> dict:
        agora = time.time()
        removidos = {}
        with self.transacao() as c:
            removidos["syslog"] = c.execute("DELETE FROM syslog_bruto WHERE recebido < ?",
                                            (agora - syslog_horas * 3600,)).rowcount
            # Teto de linhas, para o volume nunca crescer sem controle.
            corte = c.execute("SELECT id FROM syslog_bruto ORDER BY id DESC LIMIT 1 OFFSET ?",
                              (limite_syslog,)).fetchone()
            if corte:
                removidos["syslog"] += c.execute("DELETE FROM syslog_bruto WHERE id <= ?", (corte[0],)).rowcount
            removidos["eventos"] = c.execute(
                "DELETE FROM eventos WHERE ts < ? OR (ts < ? AND severidade >= 6)",
                (agora - eventos_dias * 86400, agora - 2 * 86400)).rowcount
            removidos["checagens"] = c.execute("DELETE FROM checagens WHERE ts < ?", (agora - 8 * 86400,)).rowcount
            removidos["amostras"] = c.execute("DELETE FROM amostras WHERE ts < ?", (agora - 3 * 86400,)).rowcount
            removidos["contadores"] = c.execute("DELETE FROM contadores WHERE minuto < ?",
                                                (int((agora - 8 * 86400) // 60),)).rowcount
            removidos["incidentes"] = c.execute(
                "DELETE FROM incidentes WHERE status = 'RESOLVIDO' AND resolvido_em < ?",
                (agora - 30 * 86400,)).rowcount
            removidos["auditoria"] = c.execute("DELETE FROM auditoria WHERE ts < ?", (agora - 90 * 86400,)).rowcount
        return removidos

    def tamanho_bytes(self) -> int:
        pagina = self.valor("PRAGMA page_size", padrao=4096)
        paginas = self.valor("PRAGMA page_count", padrao=0)
        return int(pagina) * int(paginas)
