"""Receptor de syslog do Sentinela.

Escuta em UDP e TCP (mesma porta), entende RFC 5424 e RFC 3164 e, no TCP,
os dois enquadramentos usados na prática: contagem de octetos (rsyslog,
syslog-ng) e uma mensagem por linha (logger, aplicações simples).

As mensagens vão para uma fila; uma única thread grava no banco em lotes.
Se a fila encher (rajada muito grande), o excedente é descartado e contado,
para o receptor nunca travar nem consumir memória sem limite.
"""
from __future__ import annotations

import ipaddress
import queue
import re
import socket
import socketserver
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime

TAMANHO_MAXIMO = 16 * 1024          # bytes por mensagem aceitos
TAMANHO_MAXIMO_TCP = 64 * 1024      # quadro TCP (acima disso, a conexão cai)
CONEXOES_TCP_MAXIMAS = 64
OCIOSIDADE_TCP = 600                # segundos sem dados antes de fechar a conexão

FACILITIES = ["kern", "user", "mail", "daemon", "auth", "syslog", "lpr", "news", "uucp", "cron",
              "authpriv", "ftp", "ntp", "audit", "alert", "clock", "local0", "local1", "local2",
              "local3", "local4", "local5", "local6", "local7"]
SEVERIDADES = ["emerg", "alert", "crit", "err", "warning", "notice", "info", "debug"]
SEVERIDADES_PT = ["emergência", "alerta", "crítico", "erro", "aviso", "nota", "info", "depuração"]

_MESES = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}
_RE_3164 = re.compile(
    r"^(?P<ts>(?P<mes>[A-Z][a-z]{2}) +(?P<dia>\d{1,2}) (?P<hora>\d{2}:\d{2}:\d{2}))\s+"
    r"(?:(?P<host>[^\s:\[]+)\s+)?(?P<resto>.*)$", re.S)
_RE_TAG = re.compile(r"^(?P<tag>[^\s:\[]{1,64})(?:\[(?P<pid>[^\]]{1,32})\])?:\s?(?P<msg>.*)$", re.S)


@dataclass
class Mensagem:
    recebido: float
    origem: str
    protocolo: str
    facility: int
    severidade: int
    timestamp: float | None
    host: str
    app: str
    procid: str
    msgid: str
    dados_estruturados: dict = field(default_factory=dict)
    texto: str = ""
    formato: str = "5424"

    @property
    def facility_nome(self) -> str:
        return FACILITIES[self.facility] if 0 <= self.facility < len(FACILITIES) else str(self.facility)


def _nil(valor: str) -> str:
    return "" if valor == "-" else valor


def _ts_5424(valor: str) -> float | None:
    if valor == "-":
        return None
    try:
        return datetime.fromisoformat(valor.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _ts_3164(mes: str, dia: str, hora: str) -> float | None:
    agora = datetime.now().astimezone()
    try:
        h, m, s = (int(x) for x in hora.split(":"))
        dt = agora.replace(month=_MESES[mes], day=int(dia), hour=h, minute=m, second=s, microsecond=0)
    except (KeyError, ValueError):
        return None
    if dt.timestamp() - agora.timestamp() > 86400:  # virada de ano
        dt = dt.replace(year=dt.year - 1)
    return dt.timestamp()


def _dados_estruturados(texto: str) -> tuple[dict, str]:
    """Lê os elementos [id chave="valor" ...] do RFC 5424. Devolve (dados, resto)."""
    if texto.startswith("-"):
        return {}, texto[1:].lstrip(" ")
    dados: dict = {}
    i = 0
    n = len(texto)
    while i < n and texto[i] == "[":
        i += 1
        inicio = i
        while i < n and texto[i] not in " ]":
            i += 1
        sd_id = texto[inicio:i]
        params: dict = {}
        while i < n and texto[i] == " ":
            i += 1
            inicio = i
            while i < n and texto[i] != "=":
                i += 1
            nome = texto[inicio:i]
            i += 1  # '='
            if i >= n or texto[i] != '"':
                raise ValueError("SD mal formado")
            i += 1
            valor = []
            while i < n and texto[i] != '"':
                if texto[i] == "\\" and i + 1 < n and texto[i + 1] in '"\\]':
                    i += 1
                valor.append(texto[i])
                i += 1
            i += 1  # aspas de fechamento
            params[nome] = "".join(valor)
        if i >= n or texto[i] != "]":
            raise ValueError("SD sem fechamento")
        i += 1
        dados[sd_id] = params
    return dados, texto[i:].lstrip(" ")


def interpretar(bruto: bytes | str, origem: str = "", protocolo: str = "udp", agora: float | None = None) -> Mensagem:
    """Transforma uma linha de syslog em Mensagem. Nunca levanta exceção."""
    recebido = agora or time.time()
    if isinstance(bruto, bytes):
        texto = bruto[:TAMANHO_MAXIMO].decode("utf-8", errors="replace")
    else:
        texto = bruto[:TAMANHO_MAXIMO]
    texto = texto.rstrip("\r\n\x00")

    pri = 13  # user.notice, padrão do RFC 3164 quando não há PRI
    resto = texto
    m = re.match(r"^<(\d{1,3})>", texto)
    if m and int(m.group(1)) <= 191:
        pri = int(m.group(1))
        resto = texto[m.end():]
    facility, severidade = divmod(pri, 8)

    # RFC 5424: versão "1" seguida de espaço.
    if resto.startswith("1 "):
        partes = resto[2:].split(" ", 5)
        if len(partes) == 6:
            ts, host, app, procid, msgid, cauda = partes
            try:
                sd, msg = _dados_estruturados(cauda)
            except ValueError:
                sd, msg = {}, cauda
            if msg.startswith("\ufeff"):
                msg = msg[1:]
            return Mensagem(recebido, origem, protocolo, facility, severidade, _ts_5424(ts),
                            _nil(host)[:255], _nil(app)[:48], _nil(procid)[:128], _nil(msgid)[:32], sd, msg, "5424")

    # RFC 3164 (BSD): "Mmm dd hh:mm:ss host tag[pid]: mensagem"
    host = ""
    ts = None
    m3 = _RE_3164.match(resto)
    if m3:
        ts = _ts_3164(m3.group("mes"), m3.group("dia"), m3.group("hora"))
        host = m3.group("host") or ""
        resto = m3.group("resto")
    app = procid = ""
    mt = _RE_TAG.match(resto)
    if mt:
        app, procid, resto = mt.group("tag"), mt.group("pid") or "", mt.group("msg")
    return Mensagem(recebido, origem, protocolo, facility, severidade, ts, host[:255], app[:48], procid[:128], "",
                    {}, resto, "3164")


# ------------------------------------------------------------------ rede --

class Receptor:
    """Servidores UDP e TCP do syslog. As mensagens vão para `fila`."""

    def __init__(self, porta: int, fila: "queue.Queue[Mensagem]", origens: list[str] | None = None,
                 endereco: str = "0.0.0.0"):
        self.porta = porta
        self.endereco = endereco
        self.fila = fila
        self.redes = [ipaddress.ip_network(o, strict=False) for o in (origens or [])]
        self.recebidas = 0
        self.descartadas = 0
        self.recusadas = 0
        self.conexoes_tcp = 0
        self._vagas_tcp = threading.BoundedSemaphore(CONEXOES_TCP_MAXIMAS)
        self._udp: socket.socket | None = None
        self._tcp: socketserver.ThreadingTCPServer | None = None
        self._threads: list[threading.Thread] = []
        self._parar = threading.Event()

    def permitido(self, ip: str) -> bool:
        if not self.redes:
            return True
        try:
            endereco = ipaddress.ip_address(ip)
        except ValueError:
            return False
        return any(endereco in r for r in self.redes)

    def entregar(self, bruto: bytes, origem: str, protocolo: str) -> None:
        if not bruto.strip():
            return
        if not self.permitido(origem):
            self.recusadas += 1
            return
        msg = interpretar(bruto, origem, protocolo)
        try:
            self.fila.put_nowait(msg)
            self.recebidas += 1
        except queue.Full:
            self.descartadas += 1

    # ---------------------------------------------------------------- UDP --
    def _laco_udp(self) -> None:
        assert self._udp is not None
        while not self._parar.is_set():
            try:
                dados, (ip, _porta) = self._udp.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                if self._parar.is_set():
                    return
                time.sleep(0.2)
                continue
            # Um datagrama pode trazer várias linhas (alguns clientes agrupam).
            for linha in dados.split(b"\n") if dados.count(b"\n") > 1 else [dados]:
                self.entregar(linha, ip, "udp")

    # ---------------------------------------------------------------- TCP --
    def _criar_tcp(self):
        receptor = self

        class Manipulador(socketserver.BaseRequestHandler):
            def handle(self):  # noqa: D401 - API do socketserver
                ip = self.client_address[0]
                if not receptor.permitido(ip):
                    receptor.recusadas += 1
                    return
                if not receptor._vagas_tcp.acquire(blocking=False):
                    receptor.recusadas += 1
                    return
                receptor.conexoes_tcp += 1
                try:
                    receptor._ler_fluxo(self.request, ip)
                finally:
                    receptor.conexoes_tcp -= 1
                    receptor._vagas_tcp.release()

        class Servidor(socketserver.ThreadingTCPServer):
            allow_reuse_address = True
            daemon_threads = True
            request_queue_size = 64

        return Servidor((self.endereco, self.porta), Manipulador)

    def _ler_fluxo(self, sock: socket.socket, ip: str) -> None:
        sock.settimeout(OCIOSIDADE_TCP)
        buffer = b""
        while not self._parar.is_set():
            try:
                bloco = sock.recv(65536)
            except (socket.timeout, OSError):
                return
            if not bloco:
                if buffer.strip():
                    self.entregar(buffer, ip, "tcp")
                return
            buffer += bloco
            while buffer:
                # Contagem de octetos: "123 <PRI>1 ..."
                m = re.match(rb"^(\d{1,6}) ", buffer)
                if m and buffer[m.end():m.end() + 1] == b"<":
                    tamanho = int(m.group(1))
                    if tamanho > TAMANHO_MAXIMO_TCP:
                        return
                    fim = m.end() + tamanho
                    if len(buffer) < fim:
                        break
                    self.entregar(buffer[m.end():fim], ip, "tcp")
                    buffer = buffer[fim:].lstrip(b"\n")
                    continue
                pos = buffer.find(b"\n")
                if pos < 0:
                    if len(buffer) > TAMANHO_MAXIMO_TCP:
                        return
                    break
                self.entregar(buffer[:pos], ip, "tcp")
                buffer = buffer[pos + 1:]

    # ----------------------------------------------------------- ciclo --
    def iniciar(self) -> None:
        self._udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._udp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self._udp.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
        except OSError:
            pass
        self._udp.bind((self.endereco, self.porta))
        self._udp.settimeout(1.0)
        self._tcp = self._criar_tcp()
        for alvo, nome in ((self._laco_udp, "syslog-udp"), (self._tcp.serve_forever, "syslog-tcp")):
            t = threading.Thread(target=alvo, name=nome, daemon=True)
            t.start()
            self._threads.append(t)

    def parar(self) -> None:
        self._parar.set()
        if self._tcp:
            self._tcp.shutdown()
            self._tcp.server_close()
        if self._udp:
            self._udp.close()
