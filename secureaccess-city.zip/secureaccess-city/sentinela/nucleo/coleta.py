"""Coletores do Sentinela: checagens HTTP e TLS, API do Kubernetes e métricas.

Só biblioteca padrão do Python: nada de dependência extra para escanear.
"""
from __future__ import annotations

import json
import re
import socket
import ssl
import time
import urllib.error
import urllib.request
from datetime import datetime
from urllib.parse import urlsplit

AGENTE_HTTP = "Sentinela/1.0 (monitoramento do SecureAccess City)"
_sem_proxy = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _explicar(exc: BaseException) -> str:
    """Mensagem curta e em português para a causa de uma falha de rede."""
    causa = getattr(exc, "reason", exc)
    if isinstance(causa, ssl.SSLCertVerificationError):
        return f"certificado inválido: {causa.verify_message or causa}"
    if isinstance(causa, ssl.SSLError):
        return f"erro de TLS: {causa.reason or causa}"
    if isinstance(causa, socket.gaierror):
        return "o nome não resolve (DNS)"
    if isinstance(causa, ConnectionRefusedError):
        return "conexão recusada"
    if isinstance(causa, (socket.timeout, TimeoutError)):
        return "tempo esgotado"
    if isinstance(causa, ConnectionResetError):
        return "conexão interrompida"
    if isinstance(causa, OSError) and causa.strerror:
        return causa.strerror
    return str(causa)[:200] or type(causa).__name__


def checar_http(url: str, contem: str | None = None, timeout: float = 10, contexto: ssl.SSLContext | None = None) -> dict:
    inicio = time.perf_counter()
    resultado = {"url": url, "ok": False, "status": None, "latencia_ms": None, "erro": None}
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE_HTTP, "Accept": "*/*"})
    try:
        handlers = [urllib.request.ProxyHandler({})]
        if contexto is not None:
            handlers.append(urllib.request.HTTPSHandler(context=contexto))
        opener = urllib.request.build_opener(*handlers)
        with opener.open(req, timeout=timeout) as r:
            corpo = r.read(65536)
            resultado["status"] = r.status
    except urllib.error.HTTPError as exc:
        resultado["status"] = exc.code
        resultado["erro"] = f"HTTP {exc.code}"
        resultado["latencia_ms"] = round((time.perf_counter() - inicio) * 1000, 1)
        return resultado
    except Exception as exc:  # DNS, TLS, recusa, tempo esgotado
        resultado["erro"] = _explicar(exc)
        return resultado
    resultado["latencia_ms"] = round((time.perf_counter() - inicio) * 1000, 1)
    if resultado["status"] != 200:
        resultado["erro"] = f"HTTP {resultado['status']}"
    elif contem and contem.encode() not in corpo:
        resultado["erro"] = f"resposta sem o texto esperado ('{contem}')"
    else:
        resultado["ok"] = True
    return resultado


def checar_tls(host: str, porta: int = 443, timeout: float = 10, contexto: ssl.SSLContext | None = None) -> dict:
    resultado = {"host": host, "ok": False, "dias": None, "expira_em": None, "emissor": None, "erro": None}
    ctx = contexto or ssl.create_default_context()
    try:
        with socket.create_connection((host, porta), timeout=timeout) as s:
            with ctx.wrap_socket(s, server_hostname=host) as tls:
                cert = tls.getpeercert()
                resultado["versao_tls"] = tls.version()
    except Exception as exc:
        resultado["erro"] = _explicar(exc)
        return resultado
    expira = ssl.cert_time_to_seconds(cert["notAfter"])
    emissor = dict(x[0] for x in cert.get("issuer", ()))
    resultado.update(
        ok=True,
        expira_em=expira,
        dias=round((expira - time.time()) / 86400, 1),
        emissor=emissor.get("organizationName") or emissor.get("commonName"),
        emissor_cn=emissor.get("commonName"),
        dominios=[v for k, v in cert.get("subjectAltName", ()) if k == "DNS"],
    )
    return resultado


def host_de(url: str) -> tuple[str, int, str]:
    partes = urlsplit(url)
    porta = partes.port or (443 if partes.scheme == "https" else 80)
    return partes.hostname or "", porta, partes.scheme


# ---------------------------------------------------------- Kubernetes --

class KubeErro(Exception):
    def __init__(self, mensagem: str, status: int | None = None):
        super().__init__(mensagem)
        self.status = status


class Kube:
    """Cliente mínimo e somente leitura da API do Kubernetes (token da service account)."""

    def __init__(self, url: str, token_arquivo: str | None, ca_arquivo: str | None, timeout: float = 10):
        self.url = url.rstrip("/")
        self.token_arquivo = token_arquivo
        self.timeout = timeout
        self.contexto = None
        if self.url.startswith("https://"):
            try:
                self.contexto = ssl.create_default_context(cafile=ca_arquivo) if ca_arquivo else ssl.create_default_context()
            except (FileNotFoundError, ssl.SSLError):
                self.contexto = ssl.create_default_context()

    def _token(self) -> str | None:
        if not self.token_arquivo:
            return None
        try:
            with open(self.token_arquivo, encoding="utf-8") as f:  # relido sempre: o token é rotacionado
                return f.read().strip()
        except OSError:
            return None

    def get(self, caminho: str) -> dict:
        req = urllib.request.Request(self.url + caminho, headers={"Accept": "application/json"})
        token = self._token()
        if token:
            req.add_header("Authorization", f"Bearer {token}")
        handlers = [urllib.request.ProxyHandler({})]
        if self.contexto is not None:
            handlers.append(urllib.request.HTTPSHandler(context=self.contexto))
        try:
            with urllib.request.build_opener(*handlers).open(req, timeout=self.timeout) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as exc:
            raise KubeErro(f"HTTP {exc.code} em {caminho}", exc.code) from exc
        except Exception as exc:
            raise KubeErro(f"{_explicar(exc)} em {caminho}") from exc


_UNIDADES = {"Ki": 1024, "Mi": 1024 ** 2, "Gi": 1024 ** 3, "Ti": 1024 ** 4, "K": 1e3, "k": 1e3, "M": 1e6, "G": 1e9,
             "T": 1e12, "m": 1e-3}


def cpu_nucleos(valor: str | None) -> float:
    if not valor:
        return 0.0
    valor = str(valor)
    for sufixo, fator in (("n", 1e-9), ("u", 1e-6), ("m", 1e-3)):
        if valor.endswith(sufixo):
            return float(valor[:-1]) * fator
    return float(valor)


def bytes_de(valor: str | None) -> float:
    if not valor:
        return 0.0
    valor = str(valor)
    for sufixo in ("Ki", "Mi", "Gi", "Ti", "K", "k", "M", "G", "T", "m"):
        if valor.endswith(sufixo):
            return float(valor[: -len(sufixo)]) * _UNIDADES[sufixo]
    return float(valor)


def _ts(valor: str | None) -> float | None:
    if not valor:
        return None
    try:
        return datetime.fromisoformat(valor.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


MOTIVOS_FALHA = {"CrashLoopBackOff", "ImagePullBackOff", "ErrImagePull", "CreateContainerConfigError",
                 "CreateContainerError", "InvalidImageName", "RunContainerError", "ErrImageNeverPull"}


def resumir_pod(p: dict) -> dict:
    meta, spec, status = p.get("metadata", {}), p.get("spec", {}), p.get("status", {})
    labels = meta.get("labels") or {}
    containers = status.get("containerStatuses") or []
    motivo = None
    ultimo_termino = None
    for cs in containers:
        espera = (cs.get("state") or {}).get("waiting")
        if espera and espera.get("reason") and not motivo:
            motivo = espera["reason"]
        termino = (cs.get("lastState") or {}).get("terminated")
        if termino and termino.get("reason"):
            ultimo_termino = termino["reason"]
    if not motivo and status.get("reason"):
        motivo = status["reason"]
    dono = ""
    for o in meta.get("ownerReferences") or []:
        nome = o.get("name", "")
        dono = nome.rsplit("-", 1)[0] if o.get("kind") == "ReplicaSet" else nome
        break
    porta_metricas = None
    for c in spec.get("containers") or []:
        for porta in c.get("ports") or []:
            if porta.get("name") == "metrics":
                porta_metricas = porta.get("containerPort")
    pronto = False
    for cond in status.get("conditions") or []:
        if cond.get("type") == "Ready":
            pronto = cond.get("status") == "True"
    return {
        "namespace": meta.get("namespace"),
        "nome": meta.get("name"),
        "uid": meta.get("uid"),
        "fase": status.get("phase"),
        "pronto": pronto,
        "prontos": sum(1 for cs in containers if cs.get("ready")),
        "total": len(spec.get("containers") or []),
        "reinicios": sum(int(cs.get("restartCount") or 0) for cs in containers),
        "motivo": motivo,
        "ultimo_termino": ultimo_termino,
        "no": spec.get("nodeName"),
        "criado": _ts(meta.get("creationTimestamp")),
        "inicio": _ts(status.get("startTime")),
        "ip": status.get("podIP"),
        "dono": dono or meta.get("name"),
        "componente": labels.get("app.kubernetes.io/component"),
        "instancia": labels.get("app.kubernetes.io/instance"),
        "porta_metricas": porta_metricas,
        "cpu_m": None,
        "mem_mib": None,
    }


def resumir_no(n: dict) -> dict:
    meta, status = n.get("metadata", {}), n.get("status", {})
    info = status.get("nodeInfo") or {}
    condicoes = {c.get("type"): c.get("status") for c in status.get("conditions") or []}
    return {
        "nome": meta.get("name"),
        "pronto": condicoes.get("Ready") == "True",
        "pressoes": [t for t in ("MemoryPressure", "DiskPressure", "PIDPressure") if condicoes.get(t) == "True"],
        "cpu_nucleos": cpu_nucleos((status.get("capacity") or {}).get("cpu")),
        "memoria_bytes": bytes_de((status.get("capacity") or {}).get("memory")),
        "memoria_alocavel": bytes_de((status.get("allocatable") or {}).get("memory")),
        "disco_bytes": bytes_de((status.get("capacity") or {}).get("ephemeral-storage")),
        "pods_max": int((status.get("capacity") or {}).get("pods") or 0),
        "kubelet": info.get("kubeletVersion"),
        "sistema": info.get("osImage"),
        "kernel": info.get("kernelVersion"),
        "runtime": info.get("containerRuntimeVersion"),
        "criado": _ts(meta.get("creationTimestamp")),
        "cpu_uso": None,
        "memoria_uso": None,
    }


def coletar_kube(kube: Kube, janela_eventos: int = 3600) -> dict:
    """Retrato do cluster. Partes opcionais (métricas, cert-manager) não derrubam o resto."""
    agora = time.time()
    pods = [resumir_pod(p) for p in kube.get("/api/v1/pods?limit=1000").get("items", [])]
    nos = [resumir_no(n) for n in kube.get("/api/v1/nodes").get("items", [])]
    avisos = []

    try:
        uso_nos = {i["metadata"]["name"]: i.get("usage", {})
                   for i in kube.get("/apis/metrics.k8s.io/v1beta1/nodes").get("items", [])}
        for n in nos:
            u = uso_nos.get(n["nome"])
            if u:
                n["cpu_uso"] = cpu_nucleos(u.get("cpu"))
                n["memoria_uso"] = bytes_de(u.get("memory"))
        uso_pods = {}
        for i in kube.get("/apis/metrics.k8s.io/v1beta1/pods").get("items", []):
            cpu = sum(cpu_nucleos(c.get("usage", {}).get("cpu")) for c in i.get("containers", []))
            mem = sum(bytes_de(c.get("usage", {}).get("memory")) for c in i.get("containers", []))
            uso_pods[(i["metadata"]["namespace"], i["metadata"]["name"])] = (cpu, mem)
        for p in pods:
            u = uso_pods.get((p["namespace"], p["nome"]))
            if u:
                p["cpu_m"] = round(u[0] * 1000, 1)
                p["mem_mib"] = round(u[1] / 1024 ** 2, 1)
        metricas_ok = True
    except KubeErro as exc:
        metricas_ok = False
        avisos.append(f"métricas do cluster indisponíveis ({exc})")

    eventos = []
    try:
        for e in kube.get("/api/v1/events?fieldSelector=type%3DWarning&limit=500").get("items", []):
            ultimo = _ts(e.get("lastTimestamp")) or _ts(e.get("eventTime")) or _ts((e.get("metadata") or {}).get("creationTimestamp"))
            if ultimo and agora - ultimo > janela_eventos:
                continue
            obj = e.get("involvedObject") or {}
            eventos.append({
                "namespace": obj.get("namespace") or (e.get("metadata") or {}).get("namespace"),
                "objeto": f"{obj.get('kind', '')}/{obj.get('name', '')}",
                "motivo": e.get("reason"),
                "mensagem": (e.get("message") or "")[:300],
                "quantidade": e.get("count") or ((e.get("series") or {}).get("count")) or 1,
                "ultimo": ultimo,
            })
        eventos.sort(key=lambda e: e["ultimo"] or 0, reverse=True)
    except KubeErro as exc:
        avisos.append(f"eventos indisponíveis ({exc})")

    certificados = []
    try:
        for c in kube.get("/apis/cert-manager.io/v1/certificates").get("items", []):
            st = c.get("status") or {}
            pronto = None
            mensagem = ""
            desde = None
            for cond in st.get("conditions") or []:
                if cond.get("type") == "Ready":
                    pronto = cond.get("status") == "True"
                    mensagem = cond.get("message") or ""
                    desde = _ts(cond.get("lastTransitionTime"))
            certificados.append({
                "namespace": c["metadata"].get("namespace"),
                "nome": c["metadata"].get("name"),
                "pronto": pronto,
                "mensagem": mensagem[:300],
                "desde": desde,
                "expira": _ts(st.get("notAfter")),
                "renovacao": _ts(st.get("renewalTime")),
                "dominios": (c.get("spec") or {}).get("dnsNames") or [],
            })
    except KubeErro as exc:
        if exc.status != 404:
            avisos.append(f"certificados indisponíveis ({exc})")

    return {"ts": agora, "pods": pods, "nos": nos, "eventos": eventos[:100], "certificados": certificados,
            "metricas_ok": metricas_ok, "avisos": avisos}


# ---------------------------------------------------------- Prometheus --

_RE_LINHA = re.compile(r'^(?P<nome>[a-zA-Z_:][a-zA-Z0-9_:]*)(?:\{(?P<rotulos>[^}]*)\})?\s+(?P<valor>\S+)')
_RE_ROTULO = re.compile(r'(\w+)="((?:[^"\\]|\\.)*)"')


def ler_prometheus(texto: str) -> list[tuple[str, dict, float]]:
    saida = []
    for linha in texto.splitlines():
        if not linha or linha.startswith("#"):
            continue
        m = _RE_LINHA.match(linha)
        if not m:
            continue
        try:
            valor = float(m.group("valor"))
        except ValueError:
            continue
        rotulos = dict(_RE_ROTULO.findall(m.group("rotulos") or ""))
        saida.append((m.group("nome"), rotulos, valor))
    return saida


def raspar(url: str, timeout: float = 4) -> list[tuple[str, dict, float]]:
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE_HTTP})
    with _sem_proxy.open(req, timeout=timeout) as r:
        return ler_prometheus(r.read(2 * 1024 * 1024).decode("utf-8", errors="replace"))


def resumir_metricas_app(amostras_por_pod: list[list[tuple[str, dict, float]]]) -> dict:
    """Junta as métricas das réplicas da API de um ambiente."""
    r = {"pods": len(amostras_por_pod), "db_up": None, "jwt_idade": None, "jwt_chaves": None, "requisicoes": 0.0,
         "erros_5xx": 0.0, "acessos_liberados": 0.0, "acessos_negados": 0.0, "alertas": 0.0, "rotacoes": 0.0,
         "falhas_auth": 0.0}
    for amostras in amostras_por_pod:
        for nome, rot, v in amostras:
            if nome == "secureaccess_db_up":
                r["db_up"] = v if r["db_up"] is None else min(r["db_up"], v)
            elif nome == "secureaccess_jwt_active_key_age_seconds":
                r["jwt_idade"] = v if r["jwt_idade"] is None else max(r["jwt_idade"], v)
            elif nome == "secureaccess_jwt_keys_valid":
                r["jwt_chaves"] = v if r["jwt_chaves"] is None else max(r["jwt_chaves"], v)
            elif nome == "secureaccess_http_requests_total":
                r["requisicoes"] += v
                if str(rot.get("status", "")).startswith("5"):
                    r["erros_5xx"] += v
            elif nome == "secureaccess_access_attempts_total":
                r["acessos_liberados" if rot.get("decision") == "LIBERADO" else "acessos_negados"] += v
            elif nome == "secureaccess_security_alerts_total":
                r["alertas"] += v
            elif nome == "secureaccess_jwt_rotations_total":
                r["rotacoes"] += v
            elif nome == "secureaccess_auth_failures_total":
                r["falhas_auth"] += v
    return r
