"""Transforma mensagens de syslog em eventos que o Sentinela entende.

Fontes reconhecidas:
- secureaccess: a API do SecureAccess City (JSON no corpo do syslog);
- sentinela-agente: métricas, ficha da máquina e linhas do journal do servidor;
- sshd / sshd-session / sudo / kernel: quando chegam direto pelo rsyslog.

Tudo é gravado em lote, numa transação só. Sinais que exigem incidente
imediato (alerta crítico, conta bloqueada, falta de memória) são devolvidos
para o motor de incidentes.
"""
from __future__ import annotations

import json
import re
import sqlite3
from dataclasses import dataclass

from .syslog import Mensagem

MOTIVOS = {
    "OK": "acesso autorizado",
    "CREDENCIAL_INVALIDA": "credencial em formato inválido",
    "CREDENCIAL_DESCONHECIDA": "credencial não cadastrada",
    "CRACHA_REVOGADO": "crachá revogado",
    "CRACHA_SUSPENSO": "crachá suspenso",
    "CRACHA_EXPIRADO": "crachá expirado",
    "PREDIO_NAO_AUTORIZADO": "sem permissão para o prédio",
    "NIVEL_INSUFICIENTE": "nível de acesso insuficiente",
    "FORA_DO_HORARIO": "fora do horário",
    "PORTA_DESATIVADA": "porta desativada",
}

ALERTAS = {
    "FORCA_BRUTA": "Força bruta na leitora",
    "VARREDURA_CRACHA": "Crachá testado em várias portas",
    "CRACHA_REVOGADO_USO": "Uso de crachá revogado",
    "PORTA_FORCADA": "Porta forçada",
    "CARONA": "Entrada de carona",
    "PORTA_ABERTA_EXCEDIDO": "Porta aberta além do tempo",
    "SABOTAGEM": "Violação do leitor",
    "DISPOSITIVO_NAO_AUTENTICADO": "Catraca falhando na autenticação",
}

# Nome amigável de cada tipo de evento (usado nos filtros e no feed).
TIPOS = {
    "ACESSO_LIBERADO": "Acesso liberado",
    "ACESSO_NEGADO": "Acesso negado",
    "ALERTA_SEGURANCA": "Alerta de segurança",
    "LOGIN_SUCESSO": "Login no painel",
    "LOGIN_FALHA": "Falha de login no painel",
    "LOGIN_BLOQUEADO": "Login em conta bloqueada",
    "CONTA_BLOQUEADA": "Conta bloqueada",
    "TOKEN_REJEITADO": "Token rejeitado",
    "ACESSO_API_NEGADO": "Permissão negada na API",
    "DISPOSITIVO_AUTENTICACAO_FALHA": "Catraca com segredo errado",
    "LIMITE_REQUISICOES_EXCEDIDO": "Limite de requisições",
    "CHAVE_JWT_ROTACIONADA": "Rotação de chave JWT",
    "CRACHA_EMITIDO": "Crachá emitido",
    "API_PRONTA": "API iniciada",
    "API_ENCERRANDO": "API encerrando",
    "MIGRACAO_APLICADA": "Migração do banco",
    "ERRO_INTERNO": "Erro interno da API",
    "SSH_LOGIN": "Login SSH",
    "SSH_FALHA": "Falha de login SSH",
    "SSH_USUARIO_INVALIDO": "SSH com usuário inexistente",
    "SUDO_EXECUTADO": "Comando com sudo",
    "SUDO_FALHA": "Falha de sudo",
    "OOM_KILL": "Processo morto por falta de memória",
    "SENTINELA_LOGIN": "Login no Sentinela",
    "SENTINELA_LOGIN_FALHA": "Falha de login no Sentinela",
    "MENSAGEM_SYSLOG": "Mensagem de erro no syslog",
}

# Eventos que só viram contagem (volume alto e pouco valor individual).
SO_CONTAGEM = {"HTTP_REQUISICAO", "DISPOSITIVO_AUTENTICADO"}

ERROS_APLICACAO = {"ERRO_INTERNO", "PROMESSA_NAO_TRATADA", "TAREFA_FALHOU", "INICIALIZACAO_FALHOU",
                   "INICIALIZACAO_ABORTADA"}

_RE_SSH = [
    ("SSH_FALHA", re.compile(r"Failed (?:password|publickey|keyboard-interactive(?:/pam)?|none) for "
                             r"(?:invalid user )?(?P<usuario>\S*) from (?P<ip>[0-9a-fA-F.:]+)")),
    ("SSH_FALHA", re.compile(r"maximum authentication attempts exceeded for (?:invalid user )?"
                             r"(?P<usuario>\S*) from (?P<ip>[0-9a-fA-F.:]+)")),
    ("SSH_USUARIO_INVALIDO", re.compile(r"Invalid user (?P<usuario>\S*) from (?P<ip>[0-9a-fA-F.:]+)")),
    ("SSH_LOGIN", re.compile(r"Accepted (?P<metodo>\S+) for (?P<usuario>\S+) from (?P<ip>[0-9a-fA-F.:]+)")),
]
_RE_SUDO = re.compile(r"^\s*(?P<usuario>\S+) : .*?USER=(?P<alvo>\S+) ; COMMAND=(?P<comando>.*)$")
_RE_OOM = re.compile(r"(?:Out of memory|Memory cgroup out of memory): Killed process (?P<pid>\d+) \((?P<processo>[^)]+)\)")


@dataclass
class Sinal:
    """Pedido de incidente gerado por um evento (não por uma condição contínua)."""
    regra: str
    chave: str
    severidade: str
    titulo: str
    detalhe: str
    alvo: str


def _corte(valor, tamanho: int):
    if valor is None:
        return None
    texto = str(valor)
    return texto[:tamanho]


class Processador:
    def __init__(self, cfg):
        self.cfg = cfg
        self.ambiente_por_env = {a.app_env: a.id for a in cfg.ambientes}
        self.json_invalido = 0

    # ----------------------------------------------------------- entrada --
    def processar(self, store, mensagens: list[Mensagem]) -> list[Sinal]:
        sinais: list[Sinal] = []
        if not mensagens:
            return sinais
        with store.transacao() as c:
            for m in mensagens:
                minuto = int(m.recebido // 60)
                c.execute(
                    "INSERT INTO syslog_bruto (recebido, origem, protocolo, facility, severidade, host, app, msgid, mensagem) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (m.recebido, m.origem, m.protocolo, m.facility, m.severidade, m.host, m.app, m.msgid, m.texto[:4000]),
                )
                store.contar(c, minuto, "syslog")
                store.contar(c, minuto, f"syslog:{m.app or '(sem app)'}")
                if m.severidade <= 4:
                    store.contar(c, minuto, "syslog:aviso_ou_pior")
                try:
                    if m.app == "secureaccess":
                        self._secureaccess(store, c, m, minuto, sinais)
                    elif m.app == "sentinela-agente":
                        self._agente(store, c, m, minuto, sinais)
                    elif m.app in ("sshd", "sshd-session"):
                        self._ssh(store, c, m.texto, m.host, m.recebido, minuto)
                    elif m.app == "sudo":
                        self._sudo(store, c, m.texto, m.host, m.recebido, minuto)
                    elif m.app == "kernel" or m.facility == 0:
                        self._kernel(store, c, m.texto, m.host, m.recebido, sinais)
                    elif m.severidade <= 3:
                        self._evento(c, m.recebido, "servidor", m.app or "syslog", "sistema", "MENSAGEM_SYSLOG",
                                     m.severidade, f"{m.app or 'syslog'}: {m.texto[:200]}", host=m.host)
                except Exception:  # uma mensagem estranha não pode derrubar o lote
                    store.contar(c, minuto, "syslog:erro_processamento")
        return sinais

    # ----------------------------------------------------------- gravação --
    @staticmethod
    def _evento(c: sqlite3.Connection, ts: float, ambiente: str, fonte: str, categoria: str, tipo: str,
                severidade: int, resumo: str, *, porta=None, predio=None, cracha=None, motivo=None, ip=None,
                usuario=None, host=None, dados=None) -> None:
        c.execute(
            "INSERT INTO eventos (ts, ambiente, fonte, categoria, tipo, severidade, resumo, porta, predio, cracha, motivo, "
            "ip, usuario, host, dados) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (ts, ambiente, fonte, categoria, tipo, severidade, _corte(resumo, 300), _corte(porta, 32), _corte(predio, 32),
             _corte(cracha, 32), _corte(motivo, 64), _corte(ip, 64), _corte(usuario, 64), _corte(host, 128),
             json.dumps(dados, ensure_ascii=False)[:2000] if dados else None),
        )

    @staticmethod
    def _estado(c: sqlite3.Connection, chave: str, valor, ts: float) -> None:
        c.execute(
            "INSERT INTO estado (chave, ts, valor) VALUES (?, ?, ?) "
            "ON CONFLICT(chave) DO UPDATE SET ts = excluded.ts, valor = excluded.valor",
            (chave, ts, json.dumps(valor, ensure_ascii=False, default=str)),
        )

    # ------------------------------------------------------- SecureAccess --
    def _secureaccess(self, store, c, m: Mensagem, minuto: int, sinais: list[Sinal]) -> None:
        try:
            d = json.loads(m.texto)
            if not isinstance(d, dict):
                raise ValueError
        except ValueError:
            self.json_invalido += 1
            store.contar(c, minuto, "syslog:json_invalido")
            return
        env = str(d.get("env") or "")
        amb = self.ambiente_por_env.get(env, env or "desconhecido")
        evento = str(d.get("event") or m.msgid or "EVENTO")
        cat = str(d.get("category") or "")
        sev = m.severidade
        ts = m.recebido
        self._estado(c, f"syslog_visto:{amb}", {"host": m.host, "evento": evento}, ts)

        if evento == "HTTP_REQUISICAO":
            store.contar(c, minuto, f"http:{amb}")
            try:
                if int(d.get("status") or 0) >= 500:
                    store.contar(c, minuto, f"http5xx:{amb}")
            except (TypeError, ValueError):
                pass
            return
        if evento in SO_CONTAGEM:
            store.contar(c, minuto, f"{evento.lower()}:{amb}")
            return

        ip = d.get("source_ip")
        if evento in ("ACESSO_LIBERADO", "ACESSO_NEGADO"):
            motivo = str(d.get("reason") or "")
            porta = d.get("door")
            cracha = d.get("badge")
            liberado = evento == "ACESSO_LIBERADO"
            store.contar(c, minuto, f"{'acesso_liberado' if liberado else 'acesso_negado'}:{amb}")
            if liberado:
                resumo = f"Acesso liberado em {porta}" + (f" ({cracha})" if cracha else "")
            else:
                resumo = f"Acesso negado em {porta}: {MOTIVOS.get(motivo, motivo.lower())}" + (f" ({cracha})" if cracha else "")
            self._evento(c, ts, amb, "secureaccess", cat or "physical_access", evento, sev, resumo, porta=porta,
                         predio=d.get("building"), cracha=cracha, motivo=motivo, host=m.host,
                         dados={"metodo": d.get("method"), "origem": d.get("source"),
                                "nivel_porta": d.get("security_level")})
            return

        if evento == "ALERTA_SEGURANCA":
            tipo_alerta = str(d.get("alert_type") or "")
            severidade_app = str(d.get("severity") or "")
            porta = d.get("door")
            store.contar(c, minuto, f"alerta:{amb}")
            nome = ALERTAS.get(tipo_alerta, tipo_alerta)
            grav = {"CRITICA": "crítico", "ALTA": "alto", "MEDIA": "médio"}.get(severidade_app, severidade_app.lower())
            resumo = f"{nome}" + (f" em {porta}" if porta else "") + (f" (risco {grav})" if severidade_app else "")
            self._evento(c, ts, amb, "secureaccess", "security_alert", evento, sev, resumo, porta=porta,
                         predio=d.get("building"), cracha=d.get("badge"), motivo=tipo_alerta, host=m.host,
                         dados={"alerta_id": d.get("alert_id"), "severidade": severidade_app, "detalhes": d.get("details")})
            if severidade_app == "CRITICA":
                sinais.append(Sinal("ALERTA_CRITICO_APLICACAO", f"alerta-app:{amb}:{tipo_alerta}", "CRITICA",
                                    f"{nome} ({self._nome_amb(amb)})",
                                    f"A aplicação registrou {nome.lower()}" + (f" na porta {porta}" if porta else "")
                                    + ". Confira as câmeras e a equipe de segurança do prédio.",
                                    porta or amb))
            return

        if cat == "audit" or evento in ("TOKEN_REJEITADO", "ACESSO_API_NEGADO", "DISPOSITIVO_AUTENTICACAO_FALHA",
                                        "LIMITE_REQUISICOES_EXCEDIDO", "CHAVE_JWT_ROTACIONADA"):
            usuario = d.get("target") if evento == "CONTA_BLOQUEADA" else (d.get("actor") or d.get("target"))
            resumo = self._resumo_auditoria(evento, d, usuario, ip)
            self._evento(c, ts, amb, "secureaccess", cat or "authentication", evento, sev, resumo, porta=d.get("door"),
                         ip=ip, usuario=usuario, motivo=d.get("reason") or d.get("outcome"), host=m.host,
                         dados={k: d.get(k) for k in ("details", "route", "role", "kid", "audience") if d.get(k)})
            if evento == "LOGIN_FALHA":
                store.contar(c, minuto, f"login_falha:{amb}")
            if evento == "CHAVE_JWT_ROTACIONADA" and cat == "key_management":
                self._estado(c, f"rotacao:{amb}", {"kid": d.get("kid"), "motivo": d.get("reason")}, ts)
            if evento == "CONTA_BLOQUEADA":
                sinais.append(Sinal("CONTA_BLOQUEADA", f"conta-bloqueada:{amb}:{usuario}", "ALTA",
                                    f"Conta {usuario} bloqueada ({self._nome_amb(amb)})",
                                    "Cinco senhas erradas seguidas no painel do SecureAccess. "
                                    f"Origem: {ip or 'desconhecida'}.", str(usuario)))
            return

        if evento in ERROS_APLICACAO:
            store.contar(c, minuto, f"erro_app:{amb}")
            self._evento(c, ts, amb, "secureaccess", "application", evento, sev,
                         f"{TIPOS.get(evento, evento)}: {str(d.get('error') or '')[:160]}", host=m.host,
                         dados={"rota": d.get("route")})
            if evento == "INICIALIZACAO_ABORTADA":
                sinais.append(Sinal("API_NAO_INICIA", f"api-nao-inicia:{amb}", "ALTA",
                                    f"API não consegue iniciar ({self._nome_amb(amb)})",
                                    str(d.get("error") or "")[:300], m.host))
            return

        if sev <= 5:
            resumo = {
                "API_PRONTA": f"API pronta (versão {d.get('commit') or d.get('version') or '?'})",
                "API_ENCERRANDO": f"API encerrando ({d.get('signal') or 'sinal'})",
                "MIGRACAO_APLICADA": f"Migração aplicada: {d.get('migration')}",
            }.get(evento, TIPOS.get(evento, evento.replace("_", " ").capitalize()))
            self._evento(c, ts, amb, "secureaccess", cat or "application", evento, sev, resumo, host=m.host)

    @staticmethod
    def _resumo_auditoria(evento: str, d: dict, usuario, ip) -> str:
        de = f" de {ip}" if ip else ""
        if evento == "LOGIN_FALHA":
            return f"Falha de login de {usuario}{de} ({d.get('details') or 'senha incorreta'})"
        if evento == "LOGIN_SUCESSO":
            return f"{usuario} entrou no painel{de}"
        if evento == "LOGIN_BLOQUEADO":
            return f"Tentativa em conta bloqueada: {usuario}{de}"
        if evento == "CONTA_BLOQUEADA":
            return f"Conta {usuario} bloqueada após 5 erros{de}"
        if evento == "TOKEN_REJEITADO":
            return f"Token rejeitado ({d.get('reason') or '?'}) em {d.get('route') or '?'}{de}"
        if evento == "ACESSO_API_NEGADO":
            return f"{d.get('actor')} ({d.get('role')}) sem permissão em {d.get('route')}"
        if evento == "DISPOSITIVO_AUTENTICACAO_FALHA":
            return f"Catraca {d.get('door')} falhou na autenticação: {d.get('reason') or '?'}"
        if evento == "LIMITE_REQUISICOES_EXCEDIDO":
            return f"Limite de requisições excedido em {d.get('route')}{de}"
        if evento == "CHAVE_JWT_ROTACIONADA":
            return f"Nova chave JWT {d.get('kid') or d.get('target') or ''} ({d.get('reason') or d.get('details') or 'rotação'})".strip()
        alvo = d.get("target")
        return f"{TIPOS.get(evento, evento.replace('_', ' ').capitalize())}" + (f": {alvo}" if alvo else "") + \
            (f" por {d.get('actor')}" if d.get("actor") and d.get("actor") != alvo else "")

    def _nome_amb(self, amb: str) -> str:
        for a in self.cfg.ambientes:
            if a.id == amb:
                return a.nome
        return amb

    # --------------------------------------------------------------- agente --
    def _agente(self, store, c, m: Mensagem, minuto: int, sinais: list[Sinal]) -> None:
        try:
            d = json.loads(m.texto)
        except ValueError:
            store.contar(c, minuto, "syslog:json_invalido")
            return
        host = m.host or "servidor"
        ts = m.recebido
        if m.msgid == "METRICAS" and isinstance(d, dict):
            self._estado(c, f"agente:{host}", d, ts)
            series = []
            for chave in ("cpu_pct", "mem_usada", "mem_total", "disco_usado", "disco_total", "load1", "rede_rx_bps",
                          "rede_tx_bps", "swap_usada"):
                v = d.get(chave)
                if isinstance(v, (int, float)):
                    series.append((ts, f"servidor:{host}:{chave}", float(v)))
            if d.get("mem_total"):
                series.append((ts, f"servidor:{host}:mem_pct", 100.0 * d.get("mem_usada", 0) / d["mem_total"]))
            if d.get("disco_total"):
                series.append((ts, f"servidor:{host}:disco_pct", 100.0 * d.get("disco_usado", 0) / d["disco_total"]))
            c.executemany("INSERT INTO amostras (ts, serie, valor) VALUES (?, ?, ?)", series)
        elif m.msgid == "FICHA" and isinstance(d, dict):
            self._estado(c, f"ficha:{host}", d, ts)
        elif m.msgid == "JOURNAL" and isinstance(d, dict):
            ident = str(d.get("ident") or "")
            texto = str(d.get("texto") or "")
            if ident in ("sshd", "sshd-session"):
                self._ssh(store, c, texto, host, ts, minuto)
            elif ident == "sudo":
                self._sudo(store, c, texto, host, ts, minuto)
            elif ident == "kernel":
                self._kernel(store, c, texto, host, ts, sinais)

    # -------------------------------------------------------------- servidor --
    def _ssh(self, store, c, texto: str, host: str, ts: float, minuto: int) -> None:
        for tipo, regex in _RE_SSH:
            m = regex.search(texto)
            if not m:
                continue
            usuario = m.group("usuario") or "(vazio)"
            ip = m.group("ip")
            if tipo == "SSH_LOGIN":
                resumo, sev = f"{usuario} entrou por SSH de {ip} ({m.group('metodo')})", 5
            elif tipo == "SSH_USUARIO_INVALIDO":
                resumo, sev = f"SSH com usuário inexistente '{usuario}' de {ip}", 4
            else:
                resumo, sev = f"Falha de login SSH para '{usuario}' de {ip}", 4
            store.contar(c, minuto, f"{tipo.lower()}:servidor")
            self._evento(c, ts, "servidor", "ssh", "host_auth", tipo, sev, resumo, ip=ip, usuario=usuario, host=host,
                         dados={"linha": texto[:300]})
            return

    def _sudo(self, store, c, texto: str, host: str, ts: float, minuto: int) -> None:
        if "incorrect password" in texto or "authentication failure" in texto:
            usuario = texto.split(":", 1)[0].strip() if " : " in texto else None
            self._evento(c, ts, "servidor", "sudo", "host_auth", "SUDO_FALHA", 4,
                         f"Falha de senha no sudo{f' ({usuario})' if usuario else ''}", usuario=usuario, host=host,
                         dados={"linha": texto[:300]})
            store.contar(c, minuto, "sudo_falha:servidor")
            return
        m = _RE_SUDO.match(texto)
        if m:
            comando = m.group("comando").strip()
            self._evento(c, ts, "servidor", "sudo", "host_auth", "SUDO_EXECUTADO", 5,
                         f"{m.group('usuario')} usou sudo: {comando[:160]}", usuario=m.group("usuario"), host=host,
                         dados={"como": m.group("alvo"), "comando": comando[:300]})

    def _kernel(self, store, c, texto: str, host: str, ts: float, sinais: list[Sinal]) -> None:
        m = _RE_OOM.search(texto)
        if not m:
            return
        processo = m.group("processo")
        self._evento(c, ts, "servidor", "kernel", "host", "OOM_KILL", 2,
                     f"Falta de memória: o kernel matou {processo} (PID {m.group('pid')})", host=host,
                     dados={"linha": texto[:300]})
        sinais.append(Sinal("FALTA_DE_MEMORIA", f"oom:{host}:{processo}", "ALTA",
                            f"Processo {processo} morto por falta de memória",
                            f"O kernel do servidor {host} encerrou o processo {processo} (PID {m.group('pid')}) "
                            "porque a memória acabou. Confira os limites dos pods e o consumo do nó.", host))
