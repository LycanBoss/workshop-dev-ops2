# Um worker só: o receptor de syslog e o SQLite precisam de um dono único.
# As threads atendem o painel; o motor de coleta roda em threads próprias.
import json
import os

bind = f"0.0.0.0:{os.environ.get('PORT', '8080')}"
workers = 1
worker_class = "gthread"
threads = int(os.environ.get("GUNICORN_THREADS", "8"))
timeout = 60
worker_tmp_dir = "/tmp"  # sistema de arquivos do container é somente leitura
graceful_timeout = 20
keepalive = 5
accesslog = None  # o painel já registra o que importa; evita ruído no log
errorlog = "-"
loglevel = "warning"
forwarded_allow_ips = "*"


def worker_exit(server, worker):
    # Grava o que ainda estiver na fila antes de sair.
    try:
        app = worker.wsgi
        motor = app.extensions["sentinela"]["motor"]
        motor.parar()
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"evento": "SENTINELA_PARADA_COM_ERRO", "erro": str(exc)}), flush=True)
