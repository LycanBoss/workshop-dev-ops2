"""Testes do Sentinela. Rodar: cd sentinela && python3 -m unittest discover -s tests -v"""
from __future__ import annotations

import json
import os
import queue
import re
import socket
import sys
import tempfile
import threading
import time
import unittest
import warnings
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
warnings.simplefilter("ignore", ResourceWarning)

from nucleo import coleta, config  # noqa: E402
from nucleo.eventos import Processador  # noqa: E402
from nucleo.incidentes import Incidentes  # noqa: E402
from nucleo.motor import Motor  # noqa: E402
from nucleo.regras import Regras  # noqa: E402
from nucleo.store import Store  # noqa: E402
from nucleo.syslog import Receptor, interpretar  # noqa: E402

AMBIENTES = json.dumps({
    "producao": {"nome": "Produção", "url": "", "namespace": "secureaccess-prod", "appEnv": "production",
                 "rotacaoJwtSegundos": 3600, "ordem": 1},
    "homologacao": {"nome": "Homologação", "url": "", "namespace": "secureaccess-staging", "appEnv": "staging",
                    "rotacaoJwtSegundos": 900, "ordem": 2},
})


def porta_livre() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def cfg_teste(**extra):
    pasta = tempfile.mkdtemp(prefix="sentinela-teste-")
    env = {"SENTINELA_ENV": "test", "SENTINELA_DB": os.path.join(pasta, "t.db"), "SENTINELA_KUBE": "0",
           "SENTINELA_AMBIENTES": AMBIENTES, "SENTINELA_SYSLOG_PORTA": str(porta_livre())}
    env.update(extra)
    antigos = {k: os.environ.get(k) for k in env}
    os.environ.update(env)
    try:
        return config.carregar()
    finally:
        for k, v in antigos.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def msg_sa(evento: str, nivel: str = "warning", env: str = "production", **campos) -> bytes:
    sev = {"info": 6, "notice": 5, "warning": 4, "error": 3, "critical": 2}[nivel]
    corpo = json.dumps({"ts": "2026-10-22T00:00:00Z", "level": nivel, "service": "secureaccess-api", "env": env,
                        "version": "1.0.0", "event": evento, **campos})
    return f"<{13 * 8 + sev}>1 2026-10-22T00:00:00.000Z sa-prod-api-1 secureaccess 7 {evento} - {corpo}".encode()


# ------------------------------------------------------------------ syslog --

class TestParser(unittest.TestCase):
    def test_rfc5424_com_dados_estruturados(self):
        m = interpretar(b'<165>1 2003-10-11T22:14:15.003Z mymachine.example.com evntslog - ID47 '
                        b'[exampleSDID@32473 iut="3" eventSource="Appli\\"cation"][x a="1"] \xef\xbb\xbfAn application event')
        self.assertEqual((m.facility, m.severidade), (20, 5))
        self.assertEqual(m.host, "mymachine.example.com")
        self.assertEqual(m.app, "evntslog")
        self.assertEqual(m.procid, "")
        self.assertEqual(m.msgid, "ID47")
        self.assertEqual(m.dados_estruturados["exampleSDID@32473"]["eventSource"], 'Appli"cation')
        self.assertEqual(m.texto, "An application event")
        self.assertAlmostEqual(m.timestamp, 1065910455.003, places=2)

    def test_rfc5424_da_api(self):
        m = interpretar(msg_sa("ACESSO_NEGADO", door="PREF-CAT01"))
        self.assertEqual(m.app, "secureaccess")
        self.assertEqual(m.facility, 13)
        self.assertEqual(json.loads(m.texto)["door"], "PREF-CAT01")

    def test_rfc3164(self):
        m = interpretar(b"<38>Oct 22 03:10:01 ip-172-31-24-98 sshd[1234]: Failed password for root from 1.2.3.4 port 22 ssh2")
        self.assertEqual((m.facility, m.severidade), (4, 6))
        self.assertEqual(m.host, "ip-172-31-24-98")
        self.assertEqual((m.app, m.procid), ("sshd", "1234"))
        self.assertTrue(m.texto.startswith("Failed password"))
        self.assertEqual(m.formato, "3164")

    def test_rfc3164_sem_host_e_sem_pri(self):
        m = interpretar(b"Oct 22 03:10:01 sudo: ubuntu : COMMAND=/bin/ls")
        self.assertEqual((m.facility, m.severidade), (1, 5))
        self.assertEqual(m.app, "sudo")
        self.assertEqual(m.host, "")
        m2 = interpretar("texto solto sem cabeçalho")
        self.assertEqual(m2.app, "")
        self.assertEqual(m2.texto, "texto solto sem cabeçalho")

    def test_nunca_quebra_com_lixo(self):
        for bruto in (b"", b"<999>xx", b"<13>1 ", b"<13>1 a b c d e [sem fim", b"\xff\xfe\x00" * 50, b"<13>" + b"A" * 50000):
            m = interpretar(bruto)
            self.assertIsNotNone(m)
            self.assertLessEqual(len(m.texto), 16 * 1024)


class TestReceptor(unittest.TestCase):
    def setUp(self):
        self.porta = porta_livre()
        self.fila = queue.Queue(maxsize=100)
        self.r = Receptor(self.porta, self.fila, endereco="127.0.0.1")
        self.r.iniciar()

    def tearDown(self):
        self.r.parar()

    def receber(self, n: int, espera: float = 3.0):
        itens = []
        fim = time.time() + espera
        while len(itens) < n and time.time() < fim:
            try:
                itens.append(self.fila.get(timeout=0.1))
            except queue.Empty:
                pass
        return itens

    def test_udp_e_tcp_com_os_dois_enquadramentos(self):
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as u:
            u.sendto(b"<14>1 - h app - UDP1 - via udp", ("127.0.0.1", self.porta))
        m1 = b"<14>1 - h app - OCT1 - primeira"
        m2 = b"<14>1 - h app - OCT2 - segunda\ncom quebra"
        with socket.create_connection(("127.0.0.1", self.porta)) as t:
            t.sendall(f"{len(m1)} ".encode() + m1 + f"{len(m2)} ".encode())
            time.sleep(0.05)
            t.sendall(m2 + b"<13>linha um\n<13>linha dois\n")
        itens = self.receber(5)
        self.assertEqual(len(itens), 5, [i.texto for i in itens])
        textos = sorted(i.texto for i in itens)
        self.assertIn("segunda\ncom quebra", textos)
        self.assertIn("linha um", textos)
        self.assertEqual({i.protocolo for i in itens}, {"udp", "tcp"})

    def test_fila_cheia_descarta_e_conta(self):
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as u:
            for i in range(130):
                u.sendto(f"<14>m{i}".encode(), ("127.0.0.1", self.porta))
        time.sleep(0.5)
        self.assertEqual(self.fila.qsize(), 100)
        self.assertGreater(self.r.descartadas, 0)

    def test_origem_nao_permitida(self):
        r = Receptor(porta_livre(), queue.Queue(), origens=["10.0.0.0/8"], endereco="127.0.0.1")
        r.entregar(b"<14>x", "127.0.0.1", "udp")
        r.entregar(b"<14>y", "10.1.2.3", "udp")
        self.assertEqual((r.recusadas, r.recebidas), (1, 1))


# --------------------------------------------------------------- eventos --

class TestProcessador(unittest.TestCase):
    def setUp(self):
        self.cfg = cfg_teste()
        self.store = Store(self.cfg.banco)
        self.p = Processador(self.cfg)

    def processar(self, *brutos):
        return self.p.processar(self.store, [interpretar(b, "10.0.0.5", "tcp") for b in brutos])

    def test_eventos_do_secureaccess(self):
        sinais = self.processar(
            msg_sa("ACESSO_NEGADO", door="PREF-GAB01", building="PREF", badge="SA-10003", reason="NIVEL_INSUFICIENTE"),
            msg_sa("ACESSO_LIBERADO", "info", door="PREF-CAT01", badge="SA-10001", reason="OK"),
            msg_sa("ALERTA_SEGURANCA", "critical", alert_type="PORTA_FORCADA", severity="CRITICA", door="DATAC-POR01"),
            msg_sa("ALERTA_SEGURANCA", "error", alert_type="FORCA_BRUTA", severity="ALTA", door="PREF-CAT01"),
            msg_sa("LOGIN_FALHA", category="audit", actor="admin", source_ip="198.51.100.7", outcome="FALHA"),
            msg_sa("CONTA_BLOQUEADA", category="audit", actor="sistema", target="operador", source_ip="198.51.100.7"),
            msg_sa("HTTP_REQUISICAO", "info", status=503, route="/api/x"),
            msg_sa("HTTP_REQUISICAO", "info", env="staging", status=200),
            msg_sa("CHAVE_JWT_ROTACIONADA", "notice", category="key_management", kid="abc123", reason="AGENDADA"),
            b"<108>1 - h secureaccess - X - {json quebrado",
        )
        tipos = {r["tipo"]: r for r in self.store.q("SELECT * FROM eventos")}
        self.assertEqual(tipos["ACESSO_NEGADO"]["motivo"], "NIVEL_INSUFICIENTE")
        self.assertIn("nível de acesso insuficiente", tipos["ACESSO_NEGADO"]["resumo"])
        self.assertEqual(tipos["ACESSO_NEGADO"]["ambiente"], "producao")
        self.assertEqual(tipos["LOGIN_FALHA"]["ip"], "198.51.100.7")
        self.assertEqual(tipos["CONTA_BLOQUEADA"]["usuario"], "operador")
        self.assertNotIn("HTTP_REQUISICAO", tipos)
        agora = time.time()
        self.assertEqual(self.store.contagem("http:producao", agora - 60), 1)
        self.assertEqual(self.store.contagem("http5xx:producao", agora - 60), 1)
        self.assertEqual(self.store.contagem("http:homologacao", agora - 60), 1)
        self.assertEqual(self.store.contagem("acesso_negado:producao", agora - 60), 1)
        self.assertEqual(self.store.contagem("syslog:json_invalido", agora - 60), 1)
        self.assertIsNotNone(self.store.estado("rotacao:producao"))
        regras = sorted(s.regra for s in sinais)
        self.assertEqual(regras, ["ALERTA_CRITICO_APLICACAO", "CONTA_BLOQUEADA"])
        self.assertEqual(self.store.valor("SELECT COUNT(*) FROM syslog_bruto"), 10)

    def test_servidor_ssh_sudo_oom_e_agente(self):
        metricas = json.dumps({"cpu_pct": 12.5, "mem_total": 8e9, "mem_usada": 2e9, "disco_total": 30e9,
                               "disco_usado": 12e9, "load1": 0.4})
        journal = json.dumps({"ident": "sshd-session", "texto": "Invalid user oracle from 203.0.113.50 port 5555"})
        sinais = self.processar(
            b"<38>Oct 22 03:10:01 vm sshd[1]: Failed password for invalid user admin from 203.0.113.9 port 4 ssh2",
            b"<38>Oct 22 03:10:01 vm sshd[1]: Accepted publickey for ubuntu from 18.206.107.29 port 5 ssh2",
            b"<85>Oct 22 03:10:01 vm sudo:   ubuntu : TTY=pts/0 ; PWD=/home/ubuntu ; USER=root ; COMMAND=/usr/bin/id",
            b"<3>1 - vm kernel - - - Out of memory: Killed process 4242 (mysqld) total-vm:1kB",
            f"<134>1 - vm sentinela-agente 9 METRICAS - {metricas}".encode(),
            f"<134>1 - vm sentinela-agente 9 JOURNAL - {journal}".encode(),
        )
        tipos = [r["tipo"] for r in self.store.q("SELECT tipo FROM eventos ORDER BY id")]
        self.assertEqual(tipos, ["SSH_FALHA", "SSH_LOGIN", "SUDO_EXECUTADO", "OOM_KILL", "SSH_USUARIO_INVALIDO"])
        self.assertEqual([s.regra for s in sinais], ["FALTA_DE_MEMORIA"])
        self.assertEqual(self.store.estado("agente:vm")["cpu_pct"], 12.5)
        self.assertAlmostEqual(self.store.ultimo("servidor:vm:disco_pct")[1], 40.0)


# ------------------------------------------------------------- incidentes --

class TestIncidentes(unittest.TestCase):
    def setUp(self):
        self.store = Store(cfg_teste().banco)
        self.inc = Incidentes(self.store)

    def test_deduplica_escala_e_resolve(self):
        _, novo = self.inc.abrir("R", "k1", "MEDIA", "t", "d")
        self.assertTrue(novo)
        _, novo = self.inc.abrir("R", "k1", "CRITICA", "t2", "d2")
        self.assertFalse(novo)
        atual = self.inc.ativo("k1")
        self.assertEqual((atual["severidade"], atual["titulo"]), ("CRITICA", "t2"))
        self.assertTrue(self.inc.resolver("k1"))
        self.assertIsNone(self.inc.ativo("k1"))
        _, novo = self.inc.abrir("R", "k1", "MEDIA", "t", "d")
        self.assertTrue(novo, "depois de resolvido, a mesma chave abre um incidente novo")

    def test_condicao_com_duracao(self):
        t0 = 1_000_000.0
        self.inc.condicao("CPU", "cpu", True, "MEDIA", "cpu alta", duracao=300, agora=t0)
        self.assertIsNone(self.inc.ativo("cpu"))
        self.inc.condicao("CPU", "cpu", True, "MEDIA", "cpu alta", duracao=300, agora=t0 + 301)
        self.assertIsNotNone(self.inc.ativo("cpu"))
        self.inc.condicao("CPU", "cpu", False, "MEDIA", "", agora=t0 + 400)
        self.assertIsNone(self.inc.ativo("cpu"))

    def test_por_evento_soma_e_encerra_parado(self):
        t0 = time.time() - 4000
        self.inc.ocorrencia("A", "a1", "CRITICA", "porta forçada", agora=t0)
        self.inc.ocorrencia("A", "a1", "CRITICA", "porta forçada", agora=t0 + 10)
        self.assertEqual(self.inc.ativo("a1")["ocorrencias"], 2)
        self.assertEqual(self.inc.encerrar_parados(), 1)
        self.assertIsNone(self.inc.ativo("a1"))

    def test_reconhecer(self):
        ident, _ = self.inc.abrir("R", "k2", "ALTA", "t")
        self.assertTrue(self.inc.reconhecer(ident, "admin"))
        self.assertFalse(self.inc.reconhecer(ident, "admin"))
        self.assertEqual(self.inc.ativo("k2")["status"], "RECONHECIDO")
        self.assertEqual(self.inc.resumo()["reconhecidos"], 1)


class TestRegras(unittest.TestCase):
    def setUp(self):
        self.cfg = cfg_teste()
        self.store = Store(self.cfg.banco)
        self.inc = Incidentes(self.store)
        self.regras = Regras(self.cfg, self.store, self.inc)

    def test_forca_bruta_ssh_abre_e_fecha(self):
        agora = time.time()
        with self.store.transacao() as c:
            for i in range(10):
                c.execute("INSERT INTO eventos (ts, ambiente, tipo, severidade, ip, usuario) VALUES (?, 'servidor', "
                          "'SSH_FALHA', 4, '203.0.113.9', 'root')", (agora - i,))
        self.regras.janelas(agora)
        self.assertIsNotNone(self.inc.ativo("ssh:203.0.113.9"))
        self.regras.janelas(agora + 700)
        self.assertIsNone(self.inc.ativo("ssh:203.0.113.9"))

    def retrato(self, espera=None, reinicios=0, pronto=True, fase="Running"):
        pod = {"namespace": "secureaccess-prod", "nome": "sa-prod-api-1-x", "uid": "u1", "fase": fase, "pronto": pronto,
               "prontos": 1 if pronto else 0, "total": 1, "reinicios": reinicios, "motivo": espera,
               "ultimo_termino": "OOMKilled" if reinicios else None, "dono": "sa-prod-api", "componente": "api"}
        no = {"nome": "n1", "pronto": True, "pressoes": [], "cpu_nucleos": 2, "memoria_bytes": 8e9, "cpu_uso": None,
              "memoria_uso": None}
        return {"pods": [pod], "nos": [no], "certificados": [], "eventos": []}

    def test_pod_em_crashloop_e_reinicios(self):
        t = time.time()
        self.regras.kube(self.retrato(), t)
        self.assertIsNone(self.inc.ativo("pod:secureaccess-prod/sa-prod-api"))
        self.regras.kube(self.retrato("CrashLoopBackOff", 3, False), t + 20)
        falha = self.inc.ativo("pod:secureaccess-prod/sa-prod-api")
        self.assertEqual(falha["severidade"], "CRITICA")
        self.assertIn("OOMKilled", falha["detalhe"])
        self.assertIsNotNone(self.inc.ativo("reinicio:secureaccess-prod/sa-prod-api"))
        vazio = {"pods": [], "nos": [], "certificados": [], "eventos": []}
        self.regras.kube(vazio, t + 40)
        self.assertIsNone(self.inc.ativo("pod:secureaccess-prod/sa-prod-api"))

    def test_rotacao_jwt_atrasada_e_banco(self):
        amb = self.cfg.ambientes[0]
        t = time.time()
        self.regras.app(amb, {"pods": 1, "db_up": 1, "jwt_idade": 600, "jwt_chaves": 2}, 1, t)
        self.assertIsNone(self.inc.ativo("jwt:producao"))
        self.regras.app(amb, {"pods": 1, "db_up": 0, "jwt_idade": 3600 * 2, "jwt_chaves": 2}, 1, t + 1)
        self.assertIsNotNone(self.inc.ativo("jwt:producao"))
        self.regras.app(amb, {"pods": 1, "db_up": 0, "jwt_idade": 3600 * 2, "jwt_chaves": 2}, 1, t + 70)
        self.assertIsNotNone(self.inc.ativo("banco:producao"))


# ----------------------------------------------------------------- coleta --

class Http(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path == "/ok":
            corpo, st = b'{"service":"secureaccess-api"}', 200
        elif self.path == "/metrics":
            corpo, st = (b'# HELP x\nsecureaccess_db_up 1\nsecureaccess_http_requests_total{route="/a",status="500"} 3\n'
                         b'secureaccess_http_requests_total{route="/a",status="200"} 7\n'
                         b'secureaccess_access_attempts_total{decision="NEGADO",reason="X"} 4\n'
                         b'secureaccess_jwt_active_key_age_seconds 120\n'), 200
        else:
            corpo, st = b"erro", 500
        self.send_response(st)
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)


class TestColeta(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), Http)
        cls.url = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_checagem_http(self):
        ok = coleta.checar_http(self.url + "/ok", "secureaccess-api")
        self.assertTrue(ok["ok"])
        self.assertIsNotNone(ok["latencia_ms"])
        sem_texto = coleta.checar_http(self.url + "/ok", "outra-coisa")
        self.assertFalse(sem_texto["ok"])
        self.assertIn("texto esperado", sem_texto["erro"])
        erro = coleta.checar_http(self.url + "/x")
        self.assertEqual((erro["ok"], erro["status"], erro["erro"]), (False, 500, "HTTP 500"))
        recusado = coleta.checar_http(f"http://127.0.0.1:{porta_livre()}/", timeout=2)
        self.assertEqual(recusado["erro"], "conexão recusada")

    def test_metricas_prometheus(self):
        r = coleta.resumir_metricas_app([coleta.raspar(self.url + "/metrics")])
        self.assertEqual((r["db_up"], r["requisicoes"], r["erros_5xx"], r["acessos_negados"], r["jwt_idade"]),
                         (1.0, 10.0, 3.0, 4.0, 120.0))

    def test_quantidades_do_kubernetes(self):
        self.assertAlmostEqual(coleta.cpu_nucleos("250m"), 0.25)
        self.assertAlmostEqual(coleta.cpu_nucleos("612345678n"), 0.612345678)
        self.assertEqual(coleta.cpu_nucleos("2"), 2.0)
        self.assertEqual(coleta.bytes_de("1Ki"), 1024)
        self.assertEqual(coleta.bytes_de("512Mi"), 512 * 1024 ** 2)
        self.assertEqual(coleta.bytes_de("123"), 123)

    def test_resumo_de_pod(self):
        p = coleta.resumir_pod({
            "metadata": {"namespace": "n", "name": "web-7d9f8c-abcde", "uid": "u", "labels": {"app.kubernetes.io/component": "web"},
                         "ownerReferences": [{"kind": "ReplicaSet", "name": "web-7d9f8c"}]},
            "spec": {"containers": [{"ports": [{"name": "metrics", "containerPort": 9464}]}]},
            "status": {"phase": "Running", "podIP": "10.0.0.1", "conditions": [{"type": "Ready", "status": "False"}],
                       "containerStatuses": [{"ready": False, "restartCount": 4, "state": {"waiting": {"reason": "CrashLoopBackOff"}},
                                              "lastState": {"terminated": {"reason": "OOMKilled"}}}]}})
        self.assertEqual((p["dono"], p["motivo"], p["ultimo_termino"], p["reinicios"], p["porta_metricas"], p["pronto"]),
                         ("web", "CrashLoopBackOff", "OOMKilled", 4, 9464, False))


# --------------------------------------------------------------- config --

class TestConfig(unittest.TestCase):
    def test_producao_exige_segredos(self):
        with self.assertRaises(config.ConfigError):
            cfg_teste(SENTINELA_ENV="production")
        cfg = cfg_teste(SENTINELA_ENV="production", SENTINELA_SECRET_KEY="x" * 40,
                        SENTINELA_ADMIN_PASSWORD="SenhaForte12345", SENTINELA_AVALIADOR_PASSWORD="OutraSenha12345")
        self.assertTrue(cfg.producao)

    def test_ambientes(self):
        cfg = cfg_teste(SENTINELA_AMBIENTES=json.dumps({"b": {"nome": "B", "url": "https://b.example/", "ordem": 2},
                                                        "a": {"nome": "A", "ordem": 1}, "c": {"ativo": False}}))
        self.assertEqual([a.id for a in cfg.ambientes], ["a", "b"])
        self.assertEqual(cfg.ambientes[1].url, "https://b.example")
        with self.assertRaises(config.ConfigError):
            cfg_teste(SENTINELA_AMBIENTES="{nao é json")
        with self.assertRaises(config.ConfigError):
            cfg_teste(SENTINELA_AMBIENTES=json.dumps({"a": {"url": "ftp://x"}}))


# ------------------------------------------------------------------ painel --

class TestPainel(unittest.TestCase):
    def setUp(self):
        from app import create_app

        self.cfg = cfg_teste()
        self.motor = Motor(self.cfg)
        self.app = create_app(self.cfg, self.motor, iniciar_motor=False)
        self.c = self.app.test_client()

    def csrf(self, caminho="/login"):
        html = self.c.get(caminho).get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)

    def entrar(self, usuario="admin", senha="Admin@Sentinela1"):
        return self.c.post("/login", data={"csrf_token": self.csrf(), "usuario": usuario, "senha": senha})

    def test_exige_login(self):
        self.assertEqual(self.c.get("/").status_code, 302)
        r = self.c.get("/api/visao")
        self.assertEqual((r.status_code, r.get_json()["erro"]), (401, "SESSAO_EXPIRADA"))
        self.assertEqual(self.c.get("/healthz").status_code, 200)
        self.assertEqual(self.c.get("/readyz").status_code, 200)

    def test_login_paginas_e_cabecalhos(self):
        r = self.entrar()
        self.assertEqual(r.status_code, 302)
        for p in ("/", "/disponibilidade", "/infraestrutura", "/seguranca", "/syslog", "/incidentes",
                  "/incidentes?status=resolvidos"):
            r = self.c.get(p)
            self.assertEqual(r.status_code, 200, p)
            self.assertIn("default-src 'self'", r.headers["Content-Security-Policy"])
            self.assertNotIn("unsafe-inline", r.headers["Content-Security-Policy"])
        for p in ("/api/visao", "/api/disponibilidade", "/api/infraestrutura", "/api/seguranca?tipo=X&busca=a",
                  "/api/syslog?app=sshd&antes=10", "/api/incidentes"):
            r = self.c.get(p)
            self.assertEqual(r.status_code, 200, p)
            self.assertEqual(r.headers["Cache-Control"], "no-store")

    def test_senha_errada_bloqueia_e_vira_evento(self):
        for _ in range(5):
            self.assertEqual(self.entrar(senha="errada").status_code, 401)
        r = self.entrar()  # senha certa, mas a conta está bloqueada
        self.assertEqual(r.status_code, 401)
        self.assertIn("Aguarde", r.get_data(as_text=True))
        n = self.motor.store.valor("SELECT COUNT(*) FROM eventos WHERE tipo = 'SENTINELA_LOGIN_FALHA'")
        self.assertEqual(n, 6)

    def test_csrf_e_redirecionamento_seguro(self):
        r = self.c.post("/login", data={"usuario": "admin", "senha": "Admin@Sentinela1"})
        self.assertEqual(r.status_code, 400)
        csrf = self.csrf()
        r = self.c.post("/login?proximo=//malicioso.example", data={"csrf_token": csrf, "usuario": "admin",
                                                                     "senha": "Admin@Sentinela1"})
        self.assertEqual(r.headers["Location"], "/")

    def test_perfis_ao_tratar_incidente(self):
        ident, _ = self.motor.incidentes.abrir("R", "k", "ALTA", "titulo")
        self.entrar("avaliador", "Avaliador@Sentinela1")
        csrf = self.csrf("/incidentes")
        r = self.c.post(f"/incidentes/{ident}/reconhecer", headers={"X-CSRF-Token": csrf, "Accept": "application/json"})
        self.assertEqual(r.status_code, 403)
        self.c.post("/sair", data={"csrf_token": csrf})
        self.entrar()
        csrf = self.csrf("/incidentes")
        r = self.c.post(f"/incidentes/{ident}/reconhecer", headers={"X-CSRF-Token": csrf, "Accept": "application/json"})
        self.assertEqual(r.get_json(), {"ok": True})
        r = self.c.post(f"/incidentes/{ident}/resolver", headers={"X-CSRF-Token": csrf, "Accept": "application/json"})
        self.assertEqual(r.get_json(), {"ok": True})
        self.assertIsNone(self.motor.incidentes.ativo("k"))


class TestAgente(unittest.TestCase):
    def test_quadro_e_medicao(self):
        import importlib.util

        caminho = os.path.join(os.path.dirname(__file__), "..", "..", "agente", "sentinela-agente.py")
        spec = importlib.util.spec_from_file_location("sentinela_agente", caminho)
        agente = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(agente)
        quadro = agente.Envio.quadro("METRICAS", {"cpu_pct": 1.5})
        tamanho, _, msg = quadro.partition(b" ")
        self.assertEqual(int(tamanho), len(msg))
        m = interpretar(msg)
        self.assertEqual((m.app, m.msgid, json.loads(m.texto)["cpu_pct"]), ("sentinela-agente", "METRICAS", 1.5))
        medidas = agente.Medidor().medir()
        for chave in ("cpu_pct", "mem_total", "mem_usada", "disco_total", "disco_usado", "load1", "uptime"):
            self.assertIn(chave, medidas)
        self.assertGreater(agente.ficha()["mem_total"], 0)


if __name__ == "__main__":
    unittest.main()
