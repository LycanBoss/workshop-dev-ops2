/* Sentinela: atualização ao vivo e desenho das páginas.
   Só textContent e createElement (nada de innerHTML com dados), gráficos em SVG
   feitos aqui mesmo, sem bibliotecas externas. */
(function () {
  'use strict';

  const raiz = document.querySelector('main.conteudo');
  const blocoDados = document.getElementById('dados');
  if (!raiz || !blocoDados) return;

  const TZ = document.documentElement.dataset.fuso || 'America/Recife';
  const CSRF = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
  const pagina = raiz.dataset.pagina;
  const api = raiz.dataset.api;
  const intervalo = Number(raiz.dataset.intervalo) || 10000;
  const admin = raiz.dataset.perfil === 'ADMIN';

  // ------------------------------------------------------------ formatos --
  const fmt = (op) => new Intl.DateTimeFormat('pt-BR', Object.assign({ timeZone: TZ }, op));
  const fHora = fmt({ hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fHoraCurta = fmt({ hour: '2-digit', minute: '2-digit' });
  const fDiaHora = fmt({ day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const fData = fmt({ day: '2-digit', month: '2-digit', year: 'numeric' });
  const fNum = new Intl.NumberFormat('pt-BR');
  const fDec = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 });
  const fDec2 = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 2 });

  const vazio = (v) => v === null || v === undefined;
  const hora = (ts) => (ts ? fHora.format(new Date(ts * 1000)) : '—');
  const horaCurta = (ts) => (ts ? fHoraCurta.format(new Date(ts * 1000)) : '—');
  const diaHora = (ts) => (ts ? fDiaHora.format(new Date(ts * 1000)) : '—');
  const data = (ts) => (ts ? fData.format(new Date(ts * 1000)) : '—');
  const num = (v) => (vazio(v) ? '—' : fNum.format(v));
  const dec = (v) => (vazio(v) ? '—' : fDec.format(v));
  const pct = (v) => (vazio(v) ? '—' : `${fDec2.format(v)}%`);
  const gb = (b) => (vazio(b) ? '—' : `${fDec.format(b / 1024 ** 3)} GB`);

  function duracao(seg) {
    if (vazio(seg)) return '—';
    seg = Math.max(0, Math.round(seg));
    if (seg < 60) return `${seg} s`;
    const min = Math.floor(seg / 60);
    if (min < 60) return `${min} min`;
    const h = Math.floor(min / 60);
    if (h < 48) return `${h} h ${min % 60} min`;
    return `${Math.floor(h / 24)} d ${h % 24} h`;
  }
  function relativo(ts) {
    if (!ts) return '—';
    const s = Date.now() / 1000 - ts;
    if (s < 45) return 'agora';
    return `há ${duracao(s)}`;
  }

  // ----------------------------------------------------------------- DOM --
  function el(tag, props, ...filhos) {
    const e = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (vazio(v) || v === false) continue;
        if (k === 'class') e.className = v;
        else if (k === 'text') e.textContent = v;
        else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v);
        else if (k === 'style') estilo(e, v);
        else e.setAttribute(k, v === true ? '' : String(v));
      }
    }
    for (const f of filhos.flat()) {
      if (vazio(f) || f === false) continue;
      e.append(f instanceof Node ? f : document.createTextNode(String(f)));
    }
    return e;
  }
  // A CSP proíbe o atributo style; propriedades via CSSOM são permitidas.
  function estilo(e, texto) {
    for (const parte of String(texto).split(';')) {
      const i = parte.indexOf(':');
      if (i > 0) e.style.setProperty(parte.slice(0, i).trim(), parte.slice(i + 1).trim());
    }
  }
  const $ = (s) => raiz.querySelector(s);
  function trocar(alvo, ...filhos) {
    if (alvo) alvo.replaceChildren(...filhos.flat().filter((f) => !vazio(f) && f !== false));
  }
  const selo = (texto, classe) => el('span', { class: `selo ${classe || ''}` }, texto);
  const nada = (texto) => el('p', { class: 'vazio' }, texto);

  const NOMES_SEV = ['emergência', 'alerta', 'crítico', 'erro', 'aviso', 'nota', 'info', 'depuração'];
  const classeSev = (s) => (s <= 2 ? 'critico' : s === 3 ? 'alto' : s === 4 ? 'atencao' : s === 5 ? 'info' : 'neutro');
  const CLASSE_INC = { CRITICA: 'critica', ALTA: 'alta', MEDIA: 'media', INFO: 'info' };

  function metrica(rotulo, valor, detalhe, classe, unidade) {
    return el('div', { class: `metrica ${classe || ''}` },
      el('span', { class: 'rotulo' }, rotulo),
      el('span', { class: 'valor', title: String(valor) }, valor, unidade ? el('small', null, unidade) : null),
      detalhe ? el('span', { class: 'detalhe', title: detalhe }, detalhe) : null);
  }
  function classePct(v, atencao, alto, critico) {
    if (vazio(v)) return '';
    if (v >= critico) return 'critico';
    if (v >= alto) return 'alto';
    if (v >= atencao) return 'atencao';
    return '';
  }
  function medidor(rotulo, valorPct, texto, limites) {
    const [a, b, c] = limites || [70, 85, 95];
    const classe = classePct(valorPct, a, b, c);
    return el('div', { class: 'medidor' },
      el('div', { class: 'linha' }, el('span', null, rotulo), el('strong', null, texto)),
      el('div', { class: `barra ${classe}`, role: 'meter', 'aria-valuemin': 0, 'aria-valuemax': 100,
        'aria-valuenow': vazio(valorPct) ? 0 : Math.round(valorPct), 'aria-label': rotulo },
      el('span', { style: `width:${Math.min(100, Math.max(0, valorPct || 0)).toFixed(1)}%` })));
  }
  function barrasH(itens, classe, rotular) {
    if (!itens || !itens.length) return nada('Nada registrado no período.');
    const max = Math.max(...itens.map((i) => i.n), 1);
    return el('ul', { class: `barras-h ${classe || ''}` }, itens.map((i) => el('li', null,
      el('span', { class: 'nome', title: rotular(i) }, rotular(i)), el('span', { class: 'n' }, num(i.n)),
      el('div', { class: 'barra' }, el('span', { style: `width:${(100 * i.n / max).toFixed(1)}%` })))));
  }
  function lista(dl) {
    return el('dl', { class: 'lista-chave' }, dl.filter(Boolean).flatMap(([k, v]) => [el('dt', null, k), el('dd', null, v)]));
  }

  // ------------------------------------------------------------ gráficos --
  const NS = 'http://www.w3.org/2000/svg';
  function s(tag, attrs, ...filhos) {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (vazio(v)) continue;
      if ((k === 'fill' || k === 'stroke') && String(v).startsWith('var(')) e.style.setProperty(k, String(v));
      else e.setAttribute(k, String(v));
    }
    for (const f of filhos.flat()) if (!vazio(f)) e.append(f instanceof Node ? f : document.createTextNode(String(f)));
    return e;
  }
  const corVar = (nome) => `var(--${nome})`;

  /** series: [{nome, cor, pontos: [[t, v]]}]; op: {inicio, fim, altura, unidade, max, limite, barras, passo, titulo} */
  function grafico(alvo, series, op) {
    if (!alvo) return;
    op = op || {};
    const todos = series.flatMap((x) => x.pontos || []).filter((p) => !vazio(p[1]));
    if (!todos.length) {
      trocar(alvo, el('div', { class: 'sem-dados' }, op.semDados || 'Sem dados ainda. As medições aparecem aqui em instantes.'));
      return;
    }
    const W = Math.max(280, Math.round(alvo.clientWidth || 600));
    const H = op.altura || (alvo.classList.contains('alto') ? 240 : 190);
    const m = { e: 46, d: 10, t: 10, b: 24 };
    const larg = W - m.e - m.d;
    const alt = H - m.t - m.b;
    const fim = op.fim || Math.max(...todos.map((p) => p[0]));
    const inicio = op.inicio || Math.min(...todos.map((p) => p[0]));
    const passo = op.passo || 60;
    let maxY;
    if (op.barras) {
      const somas = {};
      for (const x of series) for (const [t, v] of x.pontos || []) somas[t] = (somas[t] || 0) + (v || 0);
      maxY = Math.max(...Object.values(somas), 1);
    } else {
      maxY = Math.max(...todos.map((p) => p[1]), op.limite || 0, op.minMax || 0);
    }
    if (op.max) maxY = op.max;
    else maxY = maxY <= 0 ? 1 : maxY * 1.15;
    const x = (t) => m.e + ((t - inicio) / Math.max(1, fim - inicio)) * larg;
    const y = (v) => m.t + alt - (v / maxY) * alt;
    const g = s('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': op.titulo || 'gráfico' });
    // grade horizontal
    for (let i = 0; i <= 4; i++) {
      const v = (maxY / 4) * i;
      const yy = y(v);
      g.append(s('line', { x1: m.e, x2: W - m.d, y1: yy, y2: yy, class: 'linha-grade' }));
      const rot = op.formatoY ? op.formatoY(v) : (maxY >= 10 ? fNum.format(Math.round(v)) : fDec.format(v));
      g.append(s('text', { x: m.e - 6, y: yy + 4, 'text-anchor': 'end', class: 'eixo' }, rot));
    }
    // marcas de tempo
    const marcas = W < 420 ? 3 : 5;
    for (let i = 0; i <= marcas; i++) {
      const t = inicio + ((fim - inicio) / marcas) * i;
      const ancora = i === 0 ? 'start' : i === marcas ? 'end' : 'middle';
      const rotulo = fim - inicio > 36 * 3600 ? diaHora(t) : horaCurta(t);
      g.append(s('text', { x: x(t), y: H - 6, 'text-anchor': ancora, class: 'eixo' }, rotulo));
    }
    if (op.limite) {
      g.append(s('line', { x1: m.e, x2: W - m.d, y1: y(op.limite), y2: y(op.limite), class: 'limite' }));
    }
    if (op.barras) {
      const baldes = Math.max(1, Math.round((fim - inicio) / passo));
      const lb = Math.max(1, larg / baldes - 1);
      const base = {};
      for (const serie of series) {
        for (const [t, v] of serie.pontos || []) {
          if (!v || t < inicio - passo) continue;
          const b0 = base[t] || 0;
          const topo = y(b0 + v);
          g.append(s('rect', { x: x(t), y: topo, width: Math.max(0.5, Math.min(lb, W - m.d - x(t))), height: Math.max(0.5, y(b0) - topo), fill: serie.cor, rx: 1 },
            s('title', null, `${horaCurta(t)} · ${serie.nome}: ${num(v)}`)));
          base[t] = b0 + v;
        }
      }
    } else {
      for (const serie of series) {
        const pts = (serie.pontos || []).filter((p) => p[0] >= inicio - passo);
        let d = '';
        let anterior = null;
        for (const [t, v] of pts) {
          if (vazio(v)) { anterior = null; continue; }
          const quebra = anterior === null || t - anterior > passo * 2.5;
          d += `${quebra ? 'M' : 'L'}${x(t).toFixed(1)},${y(v).toFixed(1)}`;
          anterior = t;
        }
        if (series.length === 1 && d && d.split('M').length === 2) {
          const area = d.replace(/M([\d.]+),([\d.]+)/g, (mm, a, b) => `M${a},${y(0)}L${a},${b}`);
          const fimArea = pts.filter((p) => !vazio(p[1]));
          if (fimArea.length) {
            g.append(s('path', { d: `${area}L${x(fimArea[fimArea.length - 1][0]).toFixed(1)},${y(0)}Z`, fill: serie.cor, opacity: 0.1 }));
          }
        }
        g.append(s('path', { d, fill: 'none', stroke: serie.cor, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
        const ultimo = [...pts].reverse().find((p) => !vazio(p[1]));
        if (ultimo) {
          g.append(s('circle', { cx: x(ultimo[0]), cy: y(ultimo[1]), r: 3, fill: serie.cor },
            s('title', null, `${serie.nome}: ${op.formatoY ? op.formatoY(ultimo[1]) : dec(ultimo[1])}`)));
        }
      }
    }
    const legenda = series.length > 1 || op.legenda
      ? el('div', { class: 'legenda' }, series.map((x2) => el('span', null, el('i', { style: `background:${x2.cor}` }), x2.nome)),
        op.limite ? el('span', null, el('i', { style: 'background:var(--alto)' }), op.rotuloLimite || 'limite') : null)
      : null;
    trocar(alvo, g, legenda);
  }
  const CORES = [corVar('s1'), corVar('s2'), corVar('s3'), corVar('s4')];

  // -------------------------------------------------------------- rede --
  let ultimo = null;
  let emAndamento = false;

  async function buscar(url) {
    const r = await fetch(url, { headers: { Accept: 'application/json' }, credentials: 'same-origin', cache: 'no-store' });
    if (r.status === 401) {
      location.href = `/login?proximo=${encodeURIComponent(location.pathname + location.search)}`;
      throw new Error('sessão expirada');
    }
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }
  function urlApi(extra) {
    const q = new URLSearchParams(location.search);
    for (const [k, v] of Object.entries(extra || {})) q.set(k, v);
    const texto = q.toString();
    return api + (texto ? `?${texto}` : '');
  }
  function marcar(ok) {
    const alvo = raiz.querySelector('[data-atualizado]');
    if (!alvo) return;
    alvo.parentElement.classList.toggle('falhou', !ok);
    alvo.textContent = ok ? `ao vivo · atualizado às ${hora(Date.now() / 1000)}` : 'sem resposta do Sentinela, tentando de novo…';
  }
  async function atualizar() {
    if (emAndamento || document.hidden) return;
    emAndamento = true;
    try {
      const d = await buscar(urlApi());
      desenhar(d, true);
      marcar(true);
    } catch (e) {
      marcar(false);
    } finally {
      emAndamento = false;
    }
  }
  function contadorMenu(resumo) {
    if (!resumo) return;
    const total = (resumo.abertos || 0) + (resumo.reconhecidos || 0);
    let alvo = document.querySelector('[data-contador-incidentes]');
    const link = document.querySelector('.menu a[href="/incidentes"]');
    if (!total) { if (alvo) alvo.remove(); return; }
    if (!alvo && link) { alvo = el('span', { class: 'contador', 'data-contador-incidentes': '' }); link.append(alvo); }
    if (!alvo) return;
    alvo.textContent = total;
    alvo.className = `contador ${resumo.por_severidade && resumo.por_severidade.CRITICA ? 'critico' : resumo.abertos ? 'alto' : ''}`;
  }

  // ------------------------------------------------- listas com histórico --
  /** Mantém uma lista que cresce: novos itens entram no topo e "carregar mais" busca os antigos. */
  function listaViva(container, botao, criar, chaveAntes) {
    const estado = { ids: new Set(), maior: 0, menor: Infinity, filtro: location.search };
    function aplicar(itens, modo) {
      if (!container) return;
      if (modo === 'trocar') { container.replaceChildren(); estado.ids.clear(); estado.maior = 0; estado.menor = Infinity; }
      const novos = itens.filter((i) => !estado.ids.has(i.id));
      const nos = novos.map((i) => {
        const n = criar(i);
        if (modo === 'topo' && estado.maior) n.classList.add('novo');
        return n;
      });
      if (modo === 'mais') container.append(...nos);
      else container.prepend(...nos);
      for (const i of novos) {
        estado.ids.add(i.id);
        estado.maior = Math.max(estado.maior, i.id);
        estado.menor = Math.min(estado.menor, i.id);
      }
      while (container.children.length > 600) {
        const ult = container.lastElementChild;
        estado.ids.delete(Number(ult.dataset.id));
        ult.remove();
      }
      if (!container.children.length) {
        container.append(el(container.tagName === 'TBODY' ? 'tr' : 'li', { class: 'vazio-linha' },
          el(container.tagName === 'TBODY' ? 'td' : 'span', { colspan: 9, class: 'vazio' }, 'Nada encontrado com esses filtros.')));
      } else {
        const v = container.querySelector('.vazio-linha');
        if (v && container.children.length > 1) v.remove();
      }
      if (botao && modo !== 'topo') botao.hidden = itens.length < 40;
    }
    if (botao) {
      botao.addEventListener('click', async () => {
        botao.disabled = true;
        try {
          const d = await buscar(urlApi({ [chaveAntes]: estado.menor }));
          aplicar(d.feed || d.linhas || [], 'mais');
        } catch (e) { /* tenta de novo no próximo clique */ } finally { botao.disabled = false; }
      });
    }
    return {
      atualizar(itens, primeiraVez) {
        if (primeiraVez) aplicar(itens, 'trocar');
        else aplicar(itens.filter((i) => i.id > estado.maior), 'topo');
      },
    };
  }

  // ------------------------------------------------------------ páginas --
  const R = {};
  const nomeAmbiente = (d, id) => (d.nomes_ambientes && d.nomes_ambientes[id]) || id;

  function itemFeed(e, nomes, detalhado) {
    const classe = classeSev(e.severidade);
    const meta = [selo(nomes[e.ambiente] || e.ambiente, 'sem-ponto neutro'), selo((window.__TIPOS || {})[e.tipo] || e.tipo, classe)];
    if (detalhado) {
      if (e.porta) meta.push(selo(`porta ${e.porta}`, 'sem-ponto neutro'));
      if (e.cracha) meta.push(selo(e.cracha, 'sem-ponto neutro'));
      if (e.ip) meta.push(selo(`IP ${e.ip}`, 'sem-ponto neutro'));
      if (e.usuario && !e.cracha) meta.push(selo(`usuário ${e.usuario}`, 'sem-ponto neutro'));
    }
    return el('li', { class: `sev-${classe}`, 'data-id': e.id },
      el('span', { class: 'hora', title: diaHora(e.ts) }, detalhado ? diaHora(e.ts) : hora(e.ts)),
      el('div', { class: 'corpo' }, el('div', { class: 'resumo' }, e.resumo), el('div', { class: 'meta' }, meta)));
  }

  function situacaoAmbiente(a) {
    const api = a.checks && a.checks.api;
    const front = a.checks && a.checks.front;
    if (!a.url) return ['Sem URL configurada', 'neutro'];
    if (!api) return ['Aguardando checagem', 'neutro'];
    const falhas = Math.max(api.falhas_seguidas || 0, (front && front.falhas_seguidas) || 0);
    if (api.ok && (!front || front.ok)) return (api.lentas_seguidas || 0) >= 3 ? ['Lento', 'atencao'] : ['No ar', 'ok'];
    return falhas >= 3 ? ['Fora do ar', 'critico'] : ['Instável', 'atencao'];
  }

  R.visao = (d, repetido) => {
    window.__TIPOS = d.nomes_tipos || {};
    contadorMenu(d.incidentes.resumo);
    const g = d.geral;
    const faixa = $('[data-geral]');
    faixa.className = `faixa-status ${g.nivel}`;
    const prontos = d.cluster.pods_total ? `${d.cluster.pods_prontos} de ${d.cluster.pods_total} pods prontos` : 'Kubernetes aguardando coleta';
    trocar(faixa, el('span', { class: 'icone', 'aria-hidden': 'true' }, g.nivel === 'ok' ? '✓' : g.nivel === 'critico' ? '!' : '•'),
      el('div', null, el('strong', null, g.texto),
        el('span', { class: 'sub' }, `${d.ambientes.length} ambiente(s) monitorado(s) · ${prontos} · syslog ${dec(d.syslog.por_min)} msg/min`)));

    trocar($('[data-ambientes]'), d.ambientes.map((a) => {
      const [texto, classe] = situacaoAmbiente(a);
      const api = a.checks.api || {};
      const front = a.checks.front || {};
      const tls = a.tls || {};
      const jwt = a.jwt || {};
      const limiteJwt = jwt.intervalo ? jwt.intervalo * 1.5 + 120 : null;
      const classeJwt = vazio(jwt.idade) ? '' : (limiteJwt && jwt.idade > limiteJwt ? 'alto' : 'ok');
      const classeTls = vazio(tls.dias) ? '' : tls.dias < 3 ? 'critico' : tls.dias < 14 ? 'atencao' : 'ok';
      const totalAcessos = (a.liberados_1h || 0) + (a.negados_1h || 0);
      return el('article', { class: 'painel' },
        el('div', { class: 'ambiente-topo' },
          el('div', null, el('h3', null, a.nome),
            a.url ? el('a', { href: a.url, target: '_blank', rel: 'noopener noreferrer' }, a.url.replace(/^https?:\/\//, '')) : null),
          selo(texto, classe)),
        el('div', { class: 'metricas' },
          metrica('API', api.ok ? num(Math.round(api.latencia_ms)) : (api.erro ? 'falha' : '—'), api.ok ? `média 1 h: ${num(a.latencia_1h)} ms` : (api.erro || ''), api.ok ? '' : (api.erro ? 'critico' : ''), api.ok ? 'ms' : null),
          metrica('Painel', front.ok ? 'OK' : (front.erro ? 'falha' : '—'), front.ok ? `${num(Math.round(front.latencia_ms))} ms` : (front.erro || ''), front.ok ? 'ok' : (front.erro ? 'critico' : '')),
          metrica('Disponível 24 h', pct(a.uptime_24h), 'checagens da API', vazio(a.uptime_24h) ? '' : a.uptime_24h >= 99 ? 'ok' : a.uptime_24h >= 95 ? 'atencao' : 'critico'),
          metrica('Certificado', vazio(tls.dias) ? (a.url.startsWith('https') ? '—' : 'sem HTTPS') : `${Math.floor(tls.dias)} dias`, tls.emissor ? `emitido por ${tls.emissor}` : (tls.erro || ''), classeTls),
          metrica('Pods', a.pods.total ? `${a.pods.prontos}/${a.pods.total}` : '—', a.pods.total ? `${num(a.pods.reinicios)} reinício(s)` : 'sem dados do cluster', a.pods.total ? (a.pods.prontos === a.pods.total ? 'ok' : 'atencao') : ''),
          metrica('Banco', vazio(a.db_up) ? '—' : a.db_up >= 1 ? 'OK' : 'fora', 'segundo a API', vazio(a.db_up) ? '' : a.db_up >= 1 ? 'ok' : 'critico'),
          metrica('Chave JWT', vazio(jwt.idade) ? '—' : duracao(jwt.idade), jwt.intervalo ? `gira a cada ${duracao(jwt.intervalo)}` : '', classeJwt),
          metrica('Acessos 1 h', num(totalAcessos), `${num(a.negados_1h)} negados`, ''),
          metrica('Alertas 1 h', num(a.alertas_1h), 'gerados pela aplicação', a.alertas_1h ? 'atencao' : ''),
          metrica('Login errado 1 h', num(a.login_falhas_1h), 'no painel', a.login_falhas_1h >= 5 ? 'alto' : ''),
          metrica('Erros 5xx 1 h', num(a.erros5xx_1h), `de ${num(a.requisicoes_1h)} requisições`, a.erros5xx_1h ? 'atencao' : ''),
          metrica('Syslog', a.ultimo_syslog ? relativo(a.ultimo_syslog) : 'nada ainda', 'última mensagem', a.ultimo_syslog && Date.now() / 1000 - a.ultimo_syslog < 900 ? 'ok' : 'atencao')));
    }));

    const srv = d.servidor;
    const blocoSrv = $('[data-servidor]');
    if (srv.metricas) {
      const mt = srv.metricas;
      trocar(blocoSrv,
        el('p', { class: 'vazio' }, `${srv.host} · ${srv.ficha ? srv.ficha.sistema || '' : ''}`),
        medidor('CPU', mt.cpu_pct, pct(mt.cpu_pct)),
        medidor('Memória', 100 * mt.mem_usada / mt.mem_total, `${gb(mt.mem_usada)} de ${gb(mt.mem_total)}`),
        medidor('Disco', 100 * mt.disco_usado / mt.disco_total, `${gb(mt.disco_usado)} de ${gb(mt.disco_total)}`, [70, 80, 90]),
        lista([['Carga', `${dec(mt.load1)} · ${dec(mt.load5)} · ${dec(mt.load15)}`], ['Ligado há', duracao(mt.uptime)],
          ['Atualizado', relativo(srv.metricas_ts)]]));
    } else if (srv.no && !vazio(srv.no.cpu_uso)) {
      const n = srv.no;
      trocar(blocoSrv,
        el('p', { class: 'vazio' }, `${n.nome} · dados do Kubernetes (instale o agente para ver disco e SSH)`),
        medidor('CPU', 100 * n.cpu_uso / n.cpu_nucleos, pct(100 * n.cpu_uso / n.cpu_nucleos)),
        medidor('Memória', 100 * n.memoria_uso / n.memoria_bytes, `${gb(n.memoria_uso)} de ${gb(n.memoria_bytes)}`));
    } else {
      trocar(blocoSrv, nada('Aguardando o agente do servidor e a coleta do Kubernetes.'));
    }

    const sl = d.syslog;
    trocar($('[data-syslog]'),
      el('div', { class: 'metricas' },
        metrica('Agora', dec(sl.por_min), 'mensagens por minuto', sl.por_min ? 'ok' : 'atencao'),
        metrica('24 h', num(sl.total_24h), 'mensagens recebidas'),
        metrica('Descartadas', num(sl.saude.descartadas), 'fila cheia', sl.saude.descartadas ? 'atencao' : '')),
      el('div', { style: 'margin-top:.8rem' }, barrasH(sl.por_app, '', (i) => i.app)));

    const abertos = d.incidentes.abertos;
    trocar($('[data-incidentes]'), abertos.length
      ? el('ul', { class: 'mini-incidentes' }, abertos.map((i) => el('li', null,
        selo(i.severidade_nome, CLASSE_INC[i.severidade]), el('a', { class: 't', href: '/incidentes' }, i.titulo),
        el('span', { class: 'q' }, relativo(i.aberto_em)))))
      : el('p', { class: 'vazio' }, '✓ Nenhum incidente em aberto.'));

    const agora = d.agora;
    grafico($('[data-grafico-latencia]'), d.ambientes.map((a, i) => ({ nome: a.nome, cor: CORES[i % 4], pontos: d.graficos.latencia[a.id] || [] })),
      { inicio: agora - 3600, fim: agora, passo: 60, titulo: 'Tempo de resposta da API', formatoY: (v) => `${fNum.format(Math.round(v))} ms` });
    const ev = d.graficos.eventos;
    grafico($('[data-grafico-eventos]'), [
      { nome: 'Liberados', cor: corVar('s2'), pontos: ev.liberados },
      { nome: 'Negados', cor: corVar('atencao'), pontos: ev.negados },
      { nome: 'Alertas', cor: corVar('critico'), pontos: ev.alertas },
    ], { inicio: agora - 3600, fim: agora, passo: 60, barras: true, titulo: 'Acessos por minuto', legenda: true });

    const feed = $('[data-feed]');
    trocar(feed, d.feed.length ? d.feed.map((e) => itemFeed(e, d.nomes_ambientes || {}, false))
      : el('li', null, el('span', { class: 'vazio' }, 'Nenhum evento de segurança ainda.')));
  };

  R.disponibilidade = (d) => {
    trocar($('[data-alvos]'), d.alvos.length ? d.alvos.map((a) => {
      const e = a.estado || {};
      const [texto, classe] = !e.alvo ? ['Aguardando', 'neutro'] : e.ok ? ['No ar', 'ok'] : (e.falhas_seguidas >= 3 ? ['Fora do ar', 'critico'] : ['Falhou', 'atencao']);
      return el('article', { class: 'painel' },
        el('div', { class: 'ambiente-topo' },
          el('div', null, el('h3', null, `${a.nome} · ${a.ambiente}`), el('a', { href: a.url, target: '_blank', rel: 'noopener noreferrer' }, a.url.replace(/^https?:\/\//, ''))),
          selo(texto, classe)),
        el('div', { class: 'metricas' },
          metrica('Agora', e.ok ? num(Math.round(e.latencia_ms)) : (e.status ? `HTTP ${e.status}` : '—'), e.ok ? `há ${duracao(Date.now() / 1000 - (e.desde || d.agora))} no ar` : (e.erro || ''), e.ok ? ((e.latencia_ms || 0) > d.limite_latencia ? 'atencao' : '') : 'critico', e.ok ? 'ms' : null),
          metrica('Média 1 h', num(a.latencia_1h), '24 h: ' + num(a.latencia_24h) + ' ms', '', 'ms'),
          metrica('Disponível 1 h', pct(a.uptime_1h), '', a.uptime_1h >= 99 ? 'ok' : a.uptime_1h >= 95 ? 'atencao' : (vazio(a.uptime_1h) ? '' : 'critico')),
          metrica('24 h', pct(a.uptime_24h), `${num(a.checagens_24h)} checagens`),
          metrica('7 dias', pct(a.uptime_7d), '')),
        a.falhas.length ? el('div', { style: 'margin-top:.75rem' }, el('h2', null, 'Últimas falhas'),
          el('ul', { class: 'mini-incidentes' }, a.falhas.map((f) => el('li', null, el('span', { class: 'q' }, diaHora(f.ts)), el('span', { class: 't' }, f.erro || `HTTP ${f.status}`))))) : null);
    }) : el('article', { class: 'painel' }, nada('Nenhuma URL configurada. Defina ambientes.*.url no chart do Sentinela.')));

    grafico($('[data-grafico]'), d.alvos.map((a, i) => ({ nome: `${a.nome} · ${a.ambiente}`, cor: CORES[i % 4], pontos: d.series[a.alvo] || [] })),
      { inicio: d.agora - 6 * 3600, fim: d.agora, passo: 300, limite: d.limite_latencia, rotuloLimite: `limite (${num(d.limite_latencia)} ms)`,
        titulo: 'Tempo de resposta', formatoY: (v) => `${fNum.format(Math.round(v))} ms` });

    trocar($('[data-tls]'), d.tls.length ? tabela(['Domínio', 'Emissor', 'Vence em', 'Situação'], d.tls.map((t) => [
      el('span', { class: 'nome' }, t.host), t.emissor || '—', t.ok ? `${data(t.expira_em)} (${Math.floor(t.dias)} dias)` : '—',
      t.ok ? selo(t.dias < 14 ? 'Renovar' : 'Válido', t.dias < 3 ? 'critico' : t.dias < 14 ? 'atencao' : 'ok') : selo(t.erro || 'falha', 'critico'),
    ])) : nada('A primeira verificação do certificado acontece alguns segundos depois do início.'));
    trocar($('[data-certificados]'), tabelaCertificados(d.certificados));
  };

  function tabela(cabecalho, linhas) {
    return el('div', { class: 'tabela-rolagem' }, el('table', { class: 'tabela' },
      el('thead', null, el('tr', null, cabecalho.map((c) => el('th', null, c)))),
      el('tbody', null, linhas.map((l) => el('tr', null, l.map((c) => el('td', null, c)))))));
  }
  function tabelaCertificados(certs) {
    if (!certs || !certs.length) return nada('Nenhum certificado do cert-manager encontrado (ou o Sentinela ainda não leu o cluster).');
    return tabela(['Certificado', 'Domínios', 'Situação', 'Vence em'], certs.map((c) => [
      el('span', { class: 'nome' }, `${c.namespace}/${c.nome}`), c.dominios.join(', '),
      c.pronto ? selo('Emitido', 'ok') : selo(c.pronto === false ? 'Não emitido' : 'Aguardando', c.pronto === false ? 'alto' : 'neutro'),
      c.expira ? `${data(c.expira)}` : (c.mensagem || '—'),
    ]));
  }

  let filtroNs = '';
  R.infraestrutura = (d) => {
    const srv = d.servidor;
    const f = srv.ficha;
    const no = (d.nos || [])[0];
    trocar($('[data-ficha]'), f ? lista([
      ['Servidor', f.hostname], ['Sistema', f.sistema], ['Kernel', f.kernel], ['Processador', f.cpu_modelo],
      ['Núcleos', num(f.nucleos)], ['Memória', gb(f.mem_total)], ['Disco (/)', gb(f.disco_total)],
      ['Ligado desde', diaHora(f.boot)], ['IP privado', f.ip_privado], ['Agente', `${f.agente || '—'} · ficha ${relativo(srv.metricas_ts)}`],
    ]) : no ? el('div', null, lista([['Nó', no.nome], ['Sistema', no.sistema], ['Kernel', no.kernel], ['Kubernetes', no.kubelet],
      ['Runtime', no.runtime], ['Núcleos', num(no.cpu_nucleos)], ['Memória', gb(no.memoria_bytes)], ['Disco', gb(no.disco_bytes)]]),
    el('p', { class: 'vazio', style: 'margin-top:.75rem' }, 'Instale o agente (scripts/instalar-ec2.sh já faz isso) para ver disco, SSH e sudo.'))
      : nada('Aguardando o agente do servidor.'));

    const mt = srv.metricas;
    if (mt) {
      trocar($('[data-medidores]'),
        medidor('CPU', mt.cpu_pct, `${pct(mt.cpu_pct)} de ${num(f ? f.nucleos : null)} núcleos`),
        medidor('Memória', 100 * mt.mem_usada / mt.mem_total, `${gb(mt.mem_usada)} de ${gb(mt.mem_total)}`),
        medidor('Disco', 100 * mt.disco_usado / mt.disco_total, `${gb(mt.disco_usado)} de ${gb(mt.disco_total)} · livre ${gb(mt.disco_total - mt.disco_usado)}`, [70, 80, 90]),
        mt.swap_total ? medidor('Swap', 100 * mt.swap_usada / mt.swap_total, `${gb(mt.swap_usada)} de ${gb(mt.swap_total)}`) : null,
        lista([['Carga (1, 5, 15 min)', `${dec(mt.load1)} · ${dec(mt.load5)} · ${dec(mt.load15)}`],
          ['Rede', `↓ ${dec((mt.rede_rx_bps || 0) / 1024)} KB/s · ↑ ${dec((mt.rede_tx_bps || 0) / 1024)} KB/s`],
          ['Processos', num(mt.processos)], ['Ligado há', duracao(mt.uptime)]]));
    } else if (no && !vazio(no.cpu_uso)) {
      trocar($('[data-medidores]'),
        medidor('CPU', 100 * no.cpu_uso / no.cpu_nucleos, pct(100 * no.cpu_uso / no.cpu_nucleos)),
        medidor('Memória', 100 * no.memoria_uso / no.memoria_bytes, `${gb(no.memoria_uso)} de ${gb(no.memoria_bytes)}`));
    } else {
      trocar($('[data-medidores]'), nada('Sem medições ainda.'));
    }

    const seriesSrv = [];
    if (d.series.cpu_pct) seriesSrv.push({ nome: 'CPU %', cor: CORES[0], pontos: d.series.cpu_pct });
    if (d.series.mem_pct) seriesSrv.push({ nome: 'Memória %', cor: CORES[2], pontos: d.series.mem_pct });
    if (d.series.disco_pct) seriesSrv.push({ nome: 'Disco %', cor: CORES[3], pontos: d.series.disco_pct });
    grafico($('[data-grafico]'), seriesSrv, { inicio: d.agora - 6 * 3600, fim: d.agora, passo: 300, max: 100, titulo: 'Uso de recursos', formatoY: (v) => `${Math.round(v)}%` });

    const blocoNos = $('[data-nos]');
    if (!d.kube_ativo) trocar(blocoNos, nada('Coleta do Kubernetes desligada (SENTINELA_KUBE=0).'));
    else if (d.kube_erro) trocar(blocoNos, el('p', { class: 'aviso' }, `Sem acesso ao Kubernetes: ${d.kube_erro.erro}`));
    else trocar(blocoNos, (d.nos || []).map((n) => el('div', { class: 'ambiente-topo' },
      el('div', null, el('h3', null, n.nome), el('span', { class: 'vazio' }, `Kubernetes ${n.kubelet} · ${n.runtime} · coletado ${relativo(d.kube_ts)}`)),
      el('div', null, selo(n.pronto ? 'Pronto' : 'Indisponível', n.pronto ? 'ok' : 'critico'), ' ',
        n.pressoes.map((p) => selo(p, 'alto'))))), (d.kube_avisos || []).map((a) => el('p', { class: 'vazio' }, `⚠ ${a}`)));

    const apps = Object.entries(d.apps || {}).filter(([, v]) => v);
    trocar($('[data-apps]'), apps.length ? tabela(['Ambiente', 'Métricas lidas', 'Banco', 'Chave JWT ativa', 'Chaves válidas', 'Requisições', 'Respostas 5xx'],
      apps.map(([id, v]) => [d.nomes_ambientes[id] || id,
        v.raspados ? `${v.raspados}/${v.pods_api} pods` : selo(v.pods_api ? 'sem acesso' : 'sem pods', v.pods_api ? 'atencao' : 'neutro'),
        vazio(v.db_up) ? '—' : selo(v.db_up >= 1 ? 'OK' : 'Fora', v.db_up >= 1 ? 'ok' : 'critico'),
        vazio(v.jwt_idade) ? '—' : `há ${duracao(v.jwt_idade)}`, num(v.jwt_chaves), num(v.requisicoes), num(v.erros_5xx)]))
      : null);

    const sel = $('[data-filtro-ns]');
    const nss = [...new Set((d.pods || []).map((p) => p.namespace))].sort();
    if (sel && sel.options.length - 1 !== nss.length) {
      const atual = sel.value;
      sel.replaceChildren(el('option', { value: '' }, 'Todos'), nss.map((n) => el('option', { value: n }, n)));
      sel.value = atual;
      if (!sel.dataset.ligado) { sel.dataset.ligado = '1'; sel.addEventListener('change', () => { filtroNs = sel.value; desenhar(ultimo); }); }
    }
    const corpo = $('[data-pods] tbody');
    const linhas = [];
    let grupo = null;
    for (const p of d.pods || []) {
      if (filtroNs && p.namespace !== filtroNs) continue;
      if (p.namespace !== grupo) {
        grupo = p.namespace;
        const rotulo = d.namespaces_ambientes && d.namespaces_ambientes[grupo] ? `${grupo} · ${d.namespaces_ambientes[grupo]}` : grupo;
        linhas.push(el('tr', { class: 'grupo' }, el('td', { colspan: 7 }, rotulo)));
      }
      const fase = p.motivo || p.fase;
      const classe = p.fase === 'Succeeded' ? 'neutro' : p.pronto ? 'ok' : (p.motivo && /BackOff|Err|Error/.test(p.motivo)) || p.fase === 'Failed' ? 'critico' : 'atencao';
      linhas.push(el('tr', null,
        el('td', { class: 'nome' }, p.nome),
        el('td', null, selo(p.fase === 'Succeeded' ? 'Concluído' : p.pronto ? 'Rodando' : fase, classe)),
        el('td', { class: 'num' }, `${p.prontos}/${p.total}`),
        el('td', { class: `num ${p.reinicios ? '' : 'fraco'}`, title: p.ultimo_termino ? `último término: ${p.ultimo_termino}` : null }, num(p.reinicios)),
        el('td', { class: 'num fraco' }, vazio(p.cpu_m) ? '—' : `${dec(p.cpu_m)} m`),
        el('td', { class: 'num fraco' }, vazio(p.mem_mib) ? '—' : `${dec(p.mem_mib)} MiB`),
        el('td', { class: 'num fraco' }, p.criado ? duracao(d.agora - p.criado) : '—')));
    }
    trocar(corpo, linhas.length ? linhas : el('tr', null, el('td', { colspan: 7, class: 'vazio' }, 'Sem pods (ou o Kubernetes ainda não foi lido).')));

    trocar($('[data-eventos-kube]'), (d.eventos || []).length ? el('ul', { class: 'mini-incidentes' }, d.eventos.slice(0, 30).map((e) => el('li', null,
      el('span', { class: 'q' }, relativo(e.ultimo)),
      el('span', { class: 't' }, el('strong', null, `${e.motivo} `), el('span', { class: 'fraco' }, `${e.namespace || ''} ${e.objeto}`), el('br'), e.mensagem,
        e.quantidade > 1 ? el('span', { class: 'vazio' }, ` (${num(e.quantidade)}×)`) : null))))
      : el('p', { class: 'vazio' }, '✓ Nenhum aviso na última hora.'));
    trocar($('[data-certificados]'), tabelaCertificados(d.certificados));
  };

  let feedSeg = null;
  R.seguranca = (d, repetido) => {
    window.__TIPOS = d.nomes_tipos || {};
    const c = d.contagens || {};
    const soma = (...tipos) => tipos.reduce((t, x) => t + (c[x] || 0), 0);
    trocar($('[data-numeros]'),
      numero('Acessos negados', soma('ACESSO_NEGADO'), 'atencao'),
      numero('Acessos liberados', soma('ACESSO_LIBERADO')),
      numero('Alertas da aplicação', soma('ALERTA_SEGURANCA'), soma('ALERTA_SEGURANCA') ? 'alto' : ''),
      numero('Senhas erradas no painel', soma('LOGIN_FALHA', 'SENTINELA_LOGIN_FALHA'), soma('LOGIN_FALHA', 'SENTINELA_LOGIN_FALHA') >= 5 ? 'alto' : ''),
      numero('Falhas de SSH', soma('SSH_FALHA', 'SSH_USUARIO_INVALIDO'), soma('SSH_FALHA', 'SSH_USUARIO_INVALIDO') ? 'atencao' : ''),
      numero('Comandos com sudo', soma('SUDO_EXECUTADO')),
      numero('Rotações de chave JWT', soma('CHAVE_JWT_ROTACIONADA')));
    grafico($('[data-grafico]'), [
      { nome: 'Acessos negados', cor: corVar('atencao'), pontos: d.serie.negados },
      { nome: 'Alertas', cor: corVar('critico'), pontos: d.serie.alertas },
      { nome: 'Falhas de autenticação', cor: CORES[2], pontos: d.serie.autenticacao },
    ], { inicio: d.agora - 86400, fim: d.agora, passo: 900, titulo: 'Eventos de segurança em 24 horas' });
    trocar($('[data-motivos]'), barrasH(d.por_motivo, 'negacao', (i) => i.nome || i.motivo));
    trocar($('[data-alertas]'), barrasH(d.por_alerta, 'alerta', (i) => i.nome || i.motivo));
    trocar($('[data-portas]'), barrasH(d.top_portas, '', (i) => i.porta));
    trocar($('[data-ips]'), d.top_ips.length ? tabela(['IP', 'Falhas', 'Última'], d.top_ips.map((i) => [el('span', { class: 'nome' }, i.ip), num(i.n), relativo(i.ultimo)]))
      : el('p', { class: 'vazio' }, '✓ Nenhuma falha de login registrada.'));
    preencherSelect($('[data-sel-ambiente]'), d.ambientes.map((a) => [a, (d.nomes_ambientes || {})[a] || a]), d.filtros.ambiente, 'Todas');
    preencherSelect($('[data-sel-tipo]'), d.tipos.map((t) => [t.id, t.nome]), d.filtros.tipo, 'Todos');
    if (!feedSeg) feedSeg = listaViva($('[data-feed]'), $('[data-mais]'), (e) => itemFeed(e, d.nomes_ambientes || {}, true), 'antes');
    feedSeg.atualizar(d.feed, !repetido);
  };
  function numero(rotulo, valor, classe) {
    return el('div', { class: `numero ${classe || ''}` }, el('span', { class: 'valor' }, num(valor)), el('span', { class: 'rotulo' }, rotulo));
  }
  function preencherSelect(sel, opcoes, atual, rotuloTodos) {
    if (!sel) return;
    const chave = JSON.stringify(opcoes);
    if (sel.dataset.chave === chave) return;
    sel.dataset.chave = chave;
    sel.replaceChildren(el('option', { value: '' }, rotuloTodos), opcoes.map(([v, t]) => el('option', { value: v }, t)));
    sel.value = atual || '';
  }

  let tabelaSyslog = null;
  R.syslog = (d, repetido) => {
    const sd = d.saude || {};
    trocar($('[data-numeros]'),
      numero('Mensagens por minuto', d.por_min, d.por_min ? '' : 'atencao'),
      numero('Recebidas em 24 h', d.total_24h),
      numero('Aviso ou pior (24 h)', d.avisos_24h, d.avisos_24h ? 'atencao' : ''),
      numero('Descartadas', sd.descartadas || 0, sd.descartadas ? 'alto' : ''),
      numero('Conexões TCP abertas', sd.conexoes_tcp || 0),
      numero(`Porta ${d.porta} (UDP e TCP)`, sd.recebidas || 0));
    grafico($('[data-grafico]'), Object.entries(d.series).map(([nome, pts], i) => ({ nome, cor: CORES[i % 4], pontos: pts })),
      { inicio: d.agora - 3600, fim: d.agora, passo: 60, titulo: 'Mensagens por minuto' });
    trocar($('[data-fontes]'), d.por_app.length ? tabela(['Aplicação', 'Mensagens', 'Hosts', 'Última'], d.por_app.map((a) => [
      el('span', { class: 'nome' }, a.app || '(sem app)'), num(a.n), num(a.hosts), relativo(a.ultimo)]))
      : nada('Nenhuma mensagem recebida ainda. Confira o encaminhamento do rsyslog.'));
    preencherSelect($('[data-sel-app]'), d.apps.map((a) => [a, a]), d.filtros.app, 'Todas');
    if (!tabelaSyslog) {
      tabelaSyslog = listaViva($('[data-linhas] tbody'), $('[data-mais]'), (l) => {
        const msg = el('td', { class: 'msg' }, l.mensagem.length > 240 ? `${l.mensagem.slice(0, 240)}…` : l.mensagem);
        const tr = el('tr', { 'data-id': l.id, title: 'Toque para ver a mensagem inteira' },
          el('td', { class: 'hora' }, diaHora(l.recebido)),
          el('td', null, selo(NOMES_SEV[l.severidade] || l.severidade, classeSev(l.severidade))),
          el('td', { class: 'fraco' }, `${l.origem} (${l.protocolo})`),
          el('td', null, el('span', { class: 'nome' }, l.app || '—'), el('br'), el('span', { class: 'fraco' }, [l.host, l.msgid].filter(Boolean).join(' · '))),
          msg);
        tr.addEventListener('click', () => {
          const aberto = msg.classList.toggle('expandida');
          msg.textContent = aberto ? l.mensagem : (l.mensagem.length > 240 ? `${l.mensagem.slice(0, 240)}…` : l.mensagem);
        });
        return tr;
      }, 'antes');
    }
    tabelaSyslog.atualizar(d.linhas, !repetido);
  };

  R.incidentes = (d) => {
    contadorMenu(d.resumo);
    const bloco = $('[data-lista-incidentes]');
    if (!d.lista.length) {
      trocar(bloco, el('div', { class: 'faixa-status ok' }, el('span', { class: 'icone' }, '✓'),
        el('div', null, el('strong', null, d.status === 'resolvidos' ? 'Nenhum incidente resolvido nos últimos 30 dias' : 'Nenhum incidente em aberto'),
          el('span', { class: 'sub' }, `${num(d.resolvidos_24h)} resolvido(s) nas últimas 24 horas`))));
    } else {
      trocar(bloco, d.lista.map((i) => {
        const resolvido = i.status === 'RESOLVIDO';
        const acoes = [];
        if (admin && !resolvido) {
          if (i.status === 'ABERTO') acoes.push(botaoAcao(i.id, 'reconhecer', 'Estou cuidando'));
          acoes.push(botaoAcao(i.id, 'resolver', 'Resolver'));
        }
        return el('article', { class: `incidente ${CLASSE_INC[i.severidade] || ''} ${resolvido ? 'resolvido' : ''}` },
          el('div', { class: 'cab' }, selo(i.severidade_nome, CLASSE_INC[i.severidade]),
            selo(resolvido ? 'Resolvido' : i.status === 'RECONHECIDO' ? `Em atendimento por ${i.reconhecido_por}` : 'Aberto', resolvido ? 'ok' : i.status === 'RECONHECIDO' ? 'info' : 'neutro'),
            el('h3', null, i.titulo)),
          i.detalhe ? el('p', null, i.detalhe) : null,
          resolvido && i.resolucao ? el('p', null, `Resolução: ${i.resolucao}`) : null,
          el('div', { class: 'rodape-inc' },
            el('span', null, `Regra ${i.regra}`),
            el('span', null, `aberto ${diaHora(i.aberto_em)}`),
            resolvido ? el('span', null, `resolvido ${diaHora(i.resolvido_em)} (durou ${duracao(i.resolvido_em - i.aberto_em)})`) : el('span', null, `atualizado ${relativo(i.atualizado_em)}`),
            i.ocorrencias > 1 ? el('span', null, `${num(i.ocorrencias)} ocorrências`) : null,
            acoes.length ? el('span', { class: 'acoes' }, acoes) : null));
      }));
    }
    const lim = d.limiares;
    trocar($('[data-limiares]'), `Limites atuais: latência ${num(lim.latencia_ms)} ms · CPU ${lim.cpu_pct}% · memória ${lim.memoria_pct}% · disco ${lim.disco_pct}% · certificado ${lim.certificado_dias} dias · SSH ${lim.ssh_falhas} falhas/10 min · login ${lim.login_falhas} falhas/5 min · silêncio do syslog ${lim.silencio_min} min. Avisos pelo Telegram: ${d.telegram ? 'ligados' : 'desligados'}.`);
    trocar($('[data-catalogo] tbody'), d.catalogo.map((r) => el('tr', null, el('td', { class: 'nome' }, r.regra),
      el('td', null, selo(r.severidade, { Crítica: 'critica', Alta: 'alta', Média: 'media' }[r.severidade] || 'info')), el('td', null, r.descricao))));
  };
  function botaoAcao(id, acao, rotulo) {
    return el('button', {
      class: `botao pequeno ${acao === 'resolver' ? '' : 'fantasma'}`, type: 'button',
      onclick: async (ev) => {
        ev.currentTarget.disabled = true;
        try {
          await fetch(`/incidentes/${id}/${acao}`, { method: 'POST', credentials: 'same-origin',
            headers: { 'X-CSRF-Token': CSRF, Accept: 'application/json' } });
        } finally { atualizar(); }
      },
    }, rotulo);
  }

  // -------------------------------------------------------------- início --
  let desenhado = false;
  function desenhar(d, repetido) {
    if (!d) return;
    ultimo = d;
    const f = R[pagina];
    if (f) f(d, repetido === undefined ? desenhado : repetido);
    desenhado = true;
  }
  try {
    desenhar(JSON.parse(blocoDados.textContent), false);
    marcar(true);
  } catch (e) {
    marcar(false);
  }
  setInterval(atualizar, intervalo);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) atualizar(); });
  let espera;
  window.addEventListener('resize', () => { clearTimeout(espera); espera = setTimeout(() => desenhar(ultimo, true), 200); });
})();
