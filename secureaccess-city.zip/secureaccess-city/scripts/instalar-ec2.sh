#!/usr/bin/env bash
# Instala o SecureAccess City numa EC2 Ubuntu com MicroK8s, do começo ao fim.
#
# Uso (dentro da pasta do projeto, na VM):
#   bash scripts/instalar-ec2.sh meudesafio.duckdns.org seu@email.com
#
# Argumentos opcionais, nesta ordem:
#   3º domínio da homologação (padrão: staging.<domínio de produção>)
#   4º domínio do Sentinela   (padrão: sentinela.<domínio de produção>)
#
# Variáveis opcionais:
#   SEM_STAGING=1    instala só a produção (economiza memória)
#   SEM_SENTINELA=1  não instala o Sentinela (monitoramento, syslog e agente)
#   SCAN=0           pula a análise de vulnerabilidades (só para destravar)
#   TAG=1.0.1        versão das imagens
#   TELEGRAM_TOKEN e TELEGRAM_CHAT  avisos de incidente no celular (opcional)
#
# Pode rodar de novo quantas vezes quiser: cada passo confere o que já existe.
set -euo pipefail

passo() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
aviso() { printf '\033[33m!!  %s\033[0m\n' "$*"; }

# Aceita o domínio de qualquer jeito que a pessoa colar: tira "https://",
# barra final, caminho e letras maiúsculas.
limpar_dominio() {
  local d
  d="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
  d="${d#http://}"; d="${d#https://}"; d="${d%%/*}"; d="${d%%:*}"
  printf '%s' "$d"
}
dominio_valido() { printf '%s' "$1" | grep -Eq '^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$'; }

DOMINIO="$(limpar_dominio "${1:?Informe o domínio de produção. Ex.: bash scripts/instalar-ec2.sh meudesafio.duckdns.org seu@email.com}")"
EMAIL="${2:?Informe seu e-mail, usado nos avisos do certificado HTTPS}"
DOMINIO_STAGING="$(limpar_dominio "${3:-staging.$DOMINIO}")"
DOMINIO_SENTINELA="$(limpar_dominio "${4:-sentinela.$DOMINIO}")"
TAG="${TAG:-1.0.0}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COM_STAGING=1; [ "${SEM_STAGING:-0}" = "1" ] && COM_STAGING=0
COM_SENTINELA=1; [ "${SEM_SENTINELA:-0}" = "1" ] && COM_SENTINELA=0
SENTINELA_PORTA_NO=30514
# IP privado do servidor: o rsyslog e o agente mandam o syslog para o Sentinela por ele.
IP_PRIVADO="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for (i = 1; i <= NF; i++) if ($i == "src") { print $(i + 1); exit }}')"
[ -n "$IP_PRIVADO" ] || IP_PRIVADO="$(hostname -I 2>/dev/null | awk '{print $1}')"

DOMINIOS=("$DOMINIO")
[ "$COM_STAGING" = 1 ] && DOMINIOS+=("$DOMINIO_STAGING")
[ "$COM_SENTINELA" = 1 ] && DOMINIOS+=("$DOMINIO_SENTINELA")

for d in "${DOMINIOS[@]}"; do
  if ! dominio_valido "$d"; then
    aviso "Domínio inválido: '$d'. Use só o nome, sem https:// (ex.: meudesafio.duckdns.org)."
    exit 1
  fi
done
case "$EMAIL" in *@*.*) ;; *) aviso "E-mail inválido: '$EMAIL'."; exit 1 ;; esac

# ----------------------------------------------------------------------------
passo "1/9 Conferindo a máquina"
MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
DISCO_GB=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
echo "Memória: ${MEM_MB} MB | Disco livre: ${DISCO_GB} GB"
if [ "$MEM_MB" -lt 3500 ]; then
  aviso "Pouca memória. Use uma instância com pelo menos 4 GB (recomendado: m7i-flex.large, 8 GB)."
  exit 1
fi
if [ "$DISCO_GB" -lt 8 ]; then
  aviso "Pouco disco livre. Aumente o volume para 30 GB no console da AWS."
  exit 1
fi

# ----------------------------------------------------------------------------
passo "2/9 Kubernetes (MicroK8s) e addons"
if ! command -v microk8s >/dev/null 2>&1; then
  echo "Instalando o MicroK8s..."
  sudo snap install microk8s --classic
  sudo usermod -aG microk8s "$USER"
fi
sudo microk8s status --wait-ready >/dev/null
for addon in dns hostpath-storage ingress metrics-server cert-manager registry; do
  sudo microk8s enable "$addon" >/dev/null
done
mkdir -p "$HOME/.kube"
sudo microk8s config > "$HOME/.kube/config"
chmod 600 "$HOME/.kube/config"
if ! command -v kubectl >/dev/null 2>&1; then sudo snap install kubectl --classic; fi
hash -r
kubectl get nodes

# ----------------------------------------------------------------------------
passo "3/9 Docker e Helm"
if ! command -v docker >/dev/null 2>&1; then
  if ! curl -fsSL https://get.docker.com | sudo sh; then
    # Versões muito novas do Ubuntu às vezes ainda não têm o repositório oficial do Docker.
    aviso "O instalador oficial do Docker não funcionou nesta versão do Ubuntu; usando o pacote do próprio Ubuntu."
    sudo apt-get update -y
    sudo apt-get install -y docker.io
    sudo apt-get install -y docker-buildx >/dev/null 2>&1 || true
    sudo systemctl enable --now docker
  fi
  sudo usermod -aG docker "$USER"
fi
if docker info >/dev/null 2>&1; then DOCKER="docker"; else DOCKER="sudo docker"; fi
if ! command -v helm >/dev/null 2>&1; then sudo snap install helm --classic; fi
hash -r
helm version --short

# ----------------------------------------------------------------------------
passo "4/9 Domínios"
MEU_IP=$(curl -fsS --max-time 5 https://checkip.amazonaws.com 2>/dev/null || true)
echo "IP público desta máquina: ${MEU_IP:-não identificado} | IP privado: ${IP_PRIVADO:-não identificado}"
for d in "${DOMINIOS[@]}"; do
  ip=$(getent hosts "$d" | awk '{print $1}' | head -1 || true)
  if [ -z "$ip" ]; then
    aviso "$d não resolve. Crie o nome no DuckDNS apontando para ${MEU_IP:-o IP elástico}."
  elif [ -n "$MEU_IP" ] && [ "$ip" != "$MEU_IP" ]; then
    aviso "$d aponta para $ip, mas esta máquina é $MEU_IP. Atualize o IP no DuckDNS."
  else
    echo "$d -> $ip (ok)"
  fi
done

# ----------------------------------------------------------------------------
passo "5/9 Emissor de certificados HTTPS (Let's Encrypt)"
if kubectl get clusterissuer letsencrypt >/dev/null 2>&1; then
  echo "Emissor letsencrypt já existe."
else
  # O webhook do cert-manager leva alguns segundos para aceitar pedidos.
  for tentativa in $(seq 1 30); do
    if kubectl apply -f - >/dev/null 2>&1 <<EOF
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: ${EMAIL}
    privateKeySecretRef:
      name: letsencrypt-key
    solvers:
      - http01:
          ingress:
            ingressClassName: traefik
EOF
    then echo "Emissor criado."; break; fi
    [ "$tentativa" = 30 ] && { aviso "Não consegui criar o emissor. Confira: kubectl get pods -n cert-manager"; exit 1; }
    sleep 5
  done
fi

# ----------------------------------------------------------------------------
passo "6/9 Syslog no nó (rsyslog recebe os eventos de segurança)"
# Gera a configuração do rsyslog; com o Sentinela ligado, inclui o encaminhamento.
gerar_conf_rsyslog() {
  local destino="$1"
  if [ -n "$destino" ]; then
    awk -v alvo="$destino" -v porta="$SENTINELA_PORTA_NO" '
      /@@ENCAMINHAR_SENTINELA@@/ {
        print "    action(type=\"omfwd\" target=\"" alvo "\" port=\"" porta "\" protocol=\"tcp\""
        print "           template=\"RSYSLOG_SyslogProtocol23Format\" TCP_Framing=\"octet-counted\""
        print "           queue.type=\"LinkedList\" queue.size=\"20000\" queue.timeoutEnqueue=\"0\""
        print "           action.resumeRetryCount=\"-1\" action.resumeInterval=\"10\")"
        next
      }
      { print }' "$ROOT/observability/rsyslog-secureaccess.conf"
  else
    cat "$ROOT/observability/rsyslog-secureaccess.conf"
  fi
}
ENCAMINHA="$COM_SENTINELA"
configurar_syslog() {
  if ! command -v rsyslogd >/dev/null 2>&1; then
    sudo apt-get install -y rsyslog || return 1
  fi
  sudo install -d -o syslog -g adm -m 0750 /var/log/secureaccess || return 1
  sudo cp "$ROOT/observability/logrotate-secureaccess" /etc/logrotate.d/secureaccess || return 1
  local destino=""
  [ "$COM_SENTINELA" = 1 ] && destino="$IP_PRIVADO"
  gerar_conf_rsyslog "$destino" | sudo tee /etc/rsyslog.d/30-secureaccess.conf >/dev/null || return 1
  if ! sudo rsyslogd -N1 >/dev/null 2>&1; then
    if [ -n "$destino" ]; then
      aviso "O rsyslog recusou o encaminhamento para o Sentinela; seguindo só com os arquivos locais."
      gerar_conf_rsyslog "" | sudo tee /etc/rsyslog.d/30-secureaccess.conf >/dev/null
      ENCAMINHA=0
    fi
    if ! sudo rsyslogd -N1 >/dev/null 2>&1; then
      sudo rm -f /etc/rsyslog.d/30-secureaccess.conf
      return 1
    fi
  fi
  sudo systemctl restart rsyslog
}
if configurar_syslog; then
  echo "rsyslog configurado: /var/log/secureaccess/seguranca.log"
  if [ "$COM_SENTINELA" = 1 ] && [ "$ENCAMINHA" = 1 ]; then
    echo "Encaminhando também para o Sentinela em $IP_PRIVADO:$SENTINELA_PORTA_NO (TCP)."
  fi
else
  aviso "Não consegui configurar o rsyslog. A aplicação funciona normalmente; os logs seguem no Kubernetes (kubectl logs)."
fi

# ----------------------------------------------------------------------------
passo "7/9 Imagens (build + análise de vulnerabilidades)"
COMPONENTES="api web"; [ "$COM_SENTINELA" = 1 ] && COMPONENTES="api web sentinela"
DOCKER="$DOCKER" COMPONENTES="$COMPONENTES" bash "$ROOT/scripts/build-local.sh" "$TAG"

# ----------------------------------------------------------------------------
passo "8/9 Deploy com Helm"
bash "$ROOT/scripts/deploy.sh" prod "$DOMINIO" "$TAG"
if [ "$COM_STAGING" = 1 ]; then
  bash "$ROOT/scripts/deploy.sh" staging "$DOMINIO_STAGING" "$TAG"
fi

# ----------------------------------------------------------------------------
passo "9/9 Sentinela (monitoramento, syslog e agente do servidor)"
if [ "$COM_SENTINELA" = 1 ]; then
  URL_STAGING=""; [ "$COM_STAGING" = 1 ] && URL_STAGING="https://$DOMINIO_STAGING"
  bash "$ROOT/scripts/deploy-sentinela.sh" "$DOMINIO_SENTINELA" "https://$DOMINIO" "$URL_STAGING" "$TAG"
  if [ -n "$IP_PRIVADO" ]; then
    sudo bash "$ROOT/agente/instalar-agente.sh" "$IP_PRIVADO" "$SENTINELA_PORTA_NO" \
      || aviso "O agente não subiu. O Sentinela funciona sem ele (sem disco, SSH e sudo). Veja: journalctl -u sentinela-agente -n 30"
  else
    aviso "Não descobri o IP privado; instale o agente depois: sudo bash agente/instalar-agente.sh <IP privado>"
  fi
else
  echo "Sentinela desligado (SEM_SENTINELA=1)."
fi

senha() { kubectl -n secureaccess-prod get secret sa-prod-secrets -o jsonpath="{.data.$1}" | base64 -d; }
senha_sentinela() { kubectl -n sentinela get secret sentinela-segredos -o jsonpath="{.data.$1}" | base64 -d; }
cat <<EOF

------------------------------------------------------------------
SecureAccess City no ar.

  Produção:     https://$DOMINIO
EOF
[ "$COM_STAGING" = 1 ] && echo "  Homologação:  https://$DOMINIO_STAGING  (senhas próprias: secret sa-staging-secrets)"
cat <<EOF

  admin    $(senha ADMIN_PASSWORD)
  auditor  $(senha AUDITOR_PASSWORD)   (só leitura, bom para os avaliadores)
EOF
if [ "$COM_SENTINELA" = 1 ]; then
  cat <<EOF

  Sentinela:    https://$DOMINIO_SENTINELA
    admin      $(senha_sentinela SENTINELA_ADMIN_PASSWORD)
    avaliador  $(senha_sentinela SENTINELA_AVALIADOR_PASSWORD)   (só leitura)
EOF
fi
cat <<EOF

O cadeado (HTTPS) leva 1 ou 2 minutos. Acompanhe com:
  kubectl get certificate -A
Use sempre https://; sem o cadeado o login não mantém a sessão.
------------------------------------------------------------------
EOF
