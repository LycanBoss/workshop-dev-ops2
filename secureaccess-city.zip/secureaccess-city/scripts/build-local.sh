#!/usr/bin/env bash
# Gera as imagens na VM, escaneia com Trivy e só publica no registro local
# do MicroK8s (localhost:32000) se não houver CVE alta/crítica corrigível.
# Uso: bash scripts/build-local.sh 1.0.0
#
# Variáveis opcionais:
#   DOCKER="sudo docker"  quando o seu usuário ainda não está no grupo docker
#   SCAN=0                pula a análise (só para destravar um deploy; registre no relatório)
set -euo pipefail

TAG="${1:-1.0.0}"
REGISTRY="${REGISTRY:-localhost:32000}"
DOCKER="${DOCKER:-docker}"
SCAN="${SCAN:-1}"
# Fixe a versão do Trivy (veja a mais recente em github.com/aquasecurity/trivy/releases).
TRIVY_IMAGE="${TRIVY_IMAGE:-aquasec/trivy:0.58.0}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CACHE="$HOME/.cache/trivy"
mkdir -p "$CACHE"

trivy() {
  $DOCKER run --rm \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v "$CACHE:/root/.cache/" \
    -v "$ROOT:/src:ro" \
    "$TRIVY_IMAGE" "$@"
}

if [ "$SCAN" = "1" ]; then
  echo "==> 1/3 Dependências e segredos no código-fonte (antes de gerar qualquer imagem)"
  trivy fs --scanners vuln,secret --severity HIGH,CRITICAL --ignore-unfixed --exit-code 1 /src
else
  echo "!!  SCAN=0: análise de vulnerabilidades DESLIGADA. Rode de novo com a análise antes da entrega."
fi

for component in api web; do
  image="$REGISTRY/secureaccess-$component:$TAG"
  echo "==> 2/3 Build de $image"
  $DOCKER build -t "$image" "$ROOT/$component"
  if [ "$SCAN" = "1" ]; then
    echo "==> 3/3 Análise da imagem $image"
    trivy image --severity HIGH,CRITICAL --ignore-unfixed --exit-code 1 "$image"
  fi
  $DOCKER push "$image"
done

echo "Imagens publicadas com a tag $TAG em $REGISTRY."
