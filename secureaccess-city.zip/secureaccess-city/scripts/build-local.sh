#!/usr/bin/env bash
# Gera as imagens na VM, escaneia com Trivy e só publica no registro local
# do MicroK8s (localhost:32000) se não houver CVE alta/crítica corrigível.
# Uso: bash scripts/build-local.sh 1.1.1
#
# Variáveis opcionais:
#   DOCKER="sudo docker"  quando o seu usuário ainda não está no grupo docker
#   SCAN=0                pula a análise (só para destravar um deploy; registre no relatório)
#   TRIVY_IMAGE=...       outra versão do Trivy
#   COMPONENTES="api web"  só algumas imagens (padrão: api web sentinela)
set -euo pipefail

TAG="${1:-1.1.1}"
REGISTRY="${REGISTRY:-localhost:32000}"
DOCKER="${DOCKER:-docker}"
SCAN="${SCAN:-1}"
# Versão fixada de propósito. Em março de 2026 o Trivy sofreu um ataque à
# cadeia de suprimentos (CVE-2026-33634): as versões 0.69.4, 0.69.5 e 0.69.6
# e a tag "latest" daquele período foram adulteradas. A 0.69.3 é a versão que
# o próprio aviso de segurança da Aqua indica como segura. Nunca use "latest".
TRIVY_IMAGE="${TRIVY_IMAGE:-aquasec/trivy:0.69.3}"
# Base de vulnerabilidades: tenta vários espelhos, porque um deles pode estar
# fora do ar ou incompleto (aconteceu com o mirror.gcr.io).
DB_REPOS="${TRIVY_DB_REPOS:-public.ecr.aws/aquasecurity/trivy-db:2 mirror.gcr.io/aquasec/trivy-db:2 ghcr.io/aquasec/trivy-db:2}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CACHE="$HOME/.cache/trivy"
mkdir -p "$CACHE"

trivy() {
  $DOCKER run --rm \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v "$CACHE:/root/.cache/" \
    -v "$ROOT:/src:ro" \
    "$TRIVY_IMAGE" "$@"
}

if [ "$SCAN" = "1" ]; then
  echo "==> 0/3 Base de vulnerabilidades do Trivy"
  ok=0
  for repo in $DB_REPOS; do
    echo "    baixando de $repo"
    if trivy image --download-db-only --db-repository "$repo"; then ok=1; break; fi
    echo "    falhou; tentando o próximo espelho"
  done
  if [ "$ok" != "1" ]; then
    echo "Não consegui baixar a base de vulnerabilidades de nenhum espelho."
    echo "Tente de novo em alguns minutos ou, para destravar o deploy, rode com SCAN=0 e registre no relatório."
    exit 1
  fi
  SKIP="--skip-db-update --skip-java-db-update"

  echo "==> 1/3 Dependências e segredos no código-fonte (antes de gerar qualquer imagem)"
  # shellcheck disable=SC2086
  trivy fs $SKIP --scanners vuln,secret --severity HIGH,CRITICAL --ignore-unfixed --exit-code 1 /src
else
  echo "!!  SCAN=0: análise de vulnerabilidades DESLIGADA. Rode de novo com a análise antes da entrega."
fi

for component in ${COMPONENTES:-api web sentinela}; do
  image="$REGISTRY/secureaccess-$component:$TAG"
  echo "==> 2/3 Build de $image"
  $DOCKER build -t "$image" "$ROOT/$component"
  if [ "$SCAN" = "1" ]; then
    echo "==> 3/3 Análise da imagem $image"
    # shellcheck disable=SC2086
    trivy image $SKIP --severity HIGH,CRITICAL --ignore-unfixed --exit-code 1 "$image"
  fi
  $DOCKER push "$image"
done

echo "Imagens publicadas com a tag $TAG em $REGISTRY."
