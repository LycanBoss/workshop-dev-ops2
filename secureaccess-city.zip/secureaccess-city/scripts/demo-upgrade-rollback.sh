#!/usr/bin/env bash
# Roteiro de demonstração de upgrade e rollback para a apresentação.
# Uso: ./scripts/demo-upgrade-rollback.sh staging staging.meudesafio.duckdns.org
set -euo pipefail

ENVIRONMENT="${1:?informe staging ou prod}"
HOST="${2:?informe o domínio}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CHART="$ROOT/helm/secureaccess"
case "$ENVIRONMENT" in
  staging) RELEASE=sa-staging; NAMESPACE=secureaccess-staging; VALUES="$CHART/values-staging.yaml" ;;
  prod)    RELEASE=sa-prod;    NAMESPACE=secureaccess-prod;    VALUES="$CHART/values-prod.yaml" ;;
  *) exit 1 ;;
esac
pause() { read -r -p ">> $1 (Enter para continuar) " _; }

echo "== Situação atual"
helm history "$RELEASE" -n "$NAMESPACE"
pause "Agora um upgrade: rotação de chave a cada 5 minutos e 2 réplicas da API"

helm upgrade "$RELEASE" "$CHART" -n "$NAMESPACE" -f "$VALUES" \
  --set ingress.host="$HOST" \
  --reuse-values \
  --set api.jwt.rotationIntervalSeconds=300 \
  --set api.replicas=2 \
  --wait --description "upgrade: rotação de 5 min e 2 réplicas"
kubectl -n "$NAMESPACE" get pods -l app.kubernetes.io/component=api
helm history "$RELEASE" -n "$NAMESPACE"
pause "Agora o rollback para a revisão anterior"

helm rollback "$RELEASE" -n "$NAMESPACE" --wait
kubectl -n "$NAMESPACE" get pods -l app.kubernetes.io/component=api
helm history "$RELEASE" -n "$NAMESPACE"
echo "== O banco e os segredos não mudam no rollback: dados e chaves continuam os mesmos."
