#!/usr/bin/env bash
# Instala ou atualiza um ambiente com Helm.
# Uso: ./scripts/deploy.sh staging staging.meudesafio.duckdns.org 1.0.0
#      ./scripts/deploy.sh prod meudesafio.duckdns.org 1.0.0
set -euo pipefail

ENVIRONMENT="${1:?informe staging ou prod}"
HOST="${2:?informe o domínio (ex.: meudesafio.duckdns.org)}"
TAG="${3:-1.0.0}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CHART="$ROOT/helm/secureaccess"

case "$ENVIRONMENT" in
  staging) RELEASE=sa-staging; NAMESPACE=secureaccess-staging; VALUES="$CHART/values-staging.yaml" ;;
  prod)    RELEASE=sa-prod;    NAMESPACE=secureaccess-prod;    VALUES="$CHART/values-prod.yaml" ;;
  *) echo "Ambiente inválido: $ENVIRONMENT (use staging ou prod)"; exit 1 ;;
esac

helm lint "$CHART" -f "$VALUES" --set ingress.host="$HOST"

helm upgrade --install "$RELEASE" "$CHART" \
  --namespace "$NAMESPACE" --create-namespace \
  -f "$VALUES" \
  --set ingress.host="$HOST" \
  --set image.tag="$TAG" \
  --wait --timeout 10m \
  --description "deploy $TAG em $(date -u +%Y-%m-%dT%H:%M:%SZ)"

helm test "$RELEASE" -n "$NAMESPACE" --logs
helm history "$RELEASE" -n "$NAMESPACE"
