#!/usr/bin/env bash
# Desastre controlado: upgrade que quebra o sistema, detecção e rollback com Helm.
#
# A história:
#   1.0.0  versão em produção, funcionando.
#   1.1.0  nova função (nome do dono do crachá na tela de alertas) com um defeito:
#          a consulta pede a coluna "nome_enc", que não existe (a certa é "name_enc").
#          Os pods sobem, as sondas de saúde passam e o "helm test" aprova, mas o
#          painel e a tela de alertas passam a dar erro para quem usa.
#   rollback  "helm rollback" volta para a 1.0.0 em segundos.
#   1.1.1  a mesma função, corrigida, sobe normalmente.
#
# Uso (na VM, dentro da pasta do projeto):
#   bash scripts/desastre-controlado.sh preparar              # gera as imagens 1.1.0 e 1.1.1 (faça antes da apresentação)
#   bash scripts/desastre-controlado.sh executar [prod|staging]   # o desastre ao vivo (padrão: prod)
#   bash scripts/desastre-controlado.sh situacao [prod|staging]   # versão atual e histórico do Helm
#
# Variáveis opcionais:
#   SEM_PAUSA=1   não espera Enter entre as etapas
#   SCAN=0        pula o Trivy no build (só para destravar; registre no relatório)
#   REFAZER=1     gera as imagens de novo mesmo que já existam
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ACAO="${1:-}"
AMBIENTE="${2:-prod}"
VERSAO_BASE="1.0.0"
VERSAO_RUIM="1.1.0"
VERSAO_BOA="1.1.1"
REGISTRO="${REGISTRY:-localhost:32000}"
PASTA="$HOME/.secureaccess-desastre"
COPIA_RUIM="$PASTA/projeto-$VERSAO_RUIM"

case "$AMBIENTE" in
  prod) REL=sa-prod; NS=secureaccess-prod; NOME="Produção" ;;
  staging) REL=sa-staging; NS=secureaccess-staging; NOME="Homologação" ;;
  *) echo "Ambiente inválido: $AMBIENTE (use prod ou staging)"; exit 1 ;;
esac

if docker info >/dev/null 2>&1; then DOCKER="docker"; else DOCKER="sudo docker"; fi

etapa() { printf '\n\033[1;36m━━ %s\033[0m\n' "$*"; }
ok() { printf '\033[32m✔ %s\033[0m\n' "$*"; }
ruim() { printf '\033[31m✘ %s\033[0m\n' "$*"; }
aviso() { printf '\033[33m!! %s\033[0m\n' "$*"; }
pausa() {
  [ "${SEM_PAUSA:-0}" = "1" ] && return 0
  printf '\n\033[1m>> %s\033[0m ' "$1"
  read -r _ </dev/tty || true
}

json() { python3 -c "import json, sys; d = json.load(sys.stdin); $1"; }

tem_imagem() {
  curl -fsS "http://$REGISTRO/v2/secureaccess-$1/tags/list" 2>/dev/null \
    | python3 -c 'import json, sys; t = json.load(sys.stdin).get("tags") or []; sys.exit(0 if sys.argv[1] in t else 1)' "$2"
}

# ------------------------------------------------------------- preparar --
preparar_ruim() {
  etapa "Preparando a $VERSAO_RUIM (com o defeito plantado)"
  rm -rf "$COPIA_RUIM"
  mkdir -p "$PASTA"
  cp -a "$ROOT" "$COPIA_RUIM"
  local arquivo="$COPIA_RUIM/api/src/routes.js"
  if ! grep -q 'c\.name_enc AS titular_enc' "$arquivo"; then
    ruim "Não achei a consulta da versão 1.1 em api/src/routes.js. Este projeto é a versão certa?"
    exit 1
  fi
  # O defeito: "nome_enc" no lugar de "name_enc". Só a consulta dos alertas muda.
  sed -i 's/c\.name_enc AS titular_enc/c.nome_enc AS titular_enc/' "$arquivo"
  sed -i "s/^appVersion: .*/appVersion: \"$VERSAO_RUIM\"/" "$COPIA_RUIM/helm/secureaccess/Chart.yaml"
  echo "Diferença entre a $VERSAO_RUIM e a $VERSAO_BOA:"
  diff -u "$ROOT/api/src/routes.js" "$arquivo" | sed -n '3,20p' || true
  DOCKER="$DOCKER" COMPONENTES="api web" bash "$COPIA_RUIM/scripts/build-local.sh" "$VERSAO_RUIM"
  ok "Imagens $VERSAO_RUIM publicadas no registro do cluster"
}

preparar_boa() {
  etapa "Preparando a $VERSAO_BOA (corrigida)"
  DOCKER="$DOCKER" COMPONENTES="api web" bash "$ROOT/scripts/build-local.sh" "$VERSAO_BOA"
  ok "Imagens $VERSAO_BOA publicadas no registro do cluster"
}

preparar() {
  if [ "${REFAZER:-0}" = "1" ] || ! tem_imagem api "$VERSAO_RUIM" || ! tem_imagem web "$VERSAO_RUIM" || [ ! -d "$COPIA_RUIM" ]; then
    preparar_ruim
  else
    ok "Imagens $VERSAO_RUIM já estão no registro (REFAZER=1 para gerar de novo)"
  fi
  if [ "${REFAZER:-0}" = "1" ] || ! tem_imagem api "$VERSAO_BOA" || ! tem_imagem web "$VERSAO_BOA"; then
    preparar_boa
  else
    ok "Imagens $VERSAO_BOA já estão no registro"
  fi
}

# --------------------------------------------------------------- consulta --
dominio() { helm get values "$REL" -n "$NS" -o json | json 'print(d["ingress"]["host"])'; }
versao_atual() { helm get values "$REL" -n "$NS" -o json | json 'print(d.get("image", {}).get("tag", "?"))'; }
revisao_atual() { helm history "$REL" -n "$NS" -o json | json 'print(max(r["revision"] for r in d))'; }

revisao_com_versao() {
  local alvo="$1" rev
  for rev in $(helm history "$REL" -n "$NS" -o json | json 'print(" ".join(str(r["revision"]) for r in sorted(d, key=lambda r: -r["revision"])))'); do
    if [ "$(helm get values "$REL" -n "$NS" --revision "$rev" -o json 2>/dev/null | json 'print(d.get("image", {}).get("tag", ""))')" = "$alvo" ]; then
      echo "$rev"
      return 0
    fi
  done
  return 1
}

entrar() {
  local senha
  senha="$(kubectl -n "$NS" get secret "$REL-secrets" -o jsonpath='{.data.AUDITOR_PASSWORD}' | base64 -d)"
  SENHA="$senha" python3 -c 'import json, os; print(json.dumps({"username": "auditor", "password": os.environ["SENHA"]}))' \
    | curl -fsS -X POST "https://$HOST/api/auth/login" -H 'Content-Type: application/json' --data @- \
    | json 'print(d["token"])'
}

codigo() { curl -s -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $1" "https://$HOST$2"; }

mostrar_versao() {
  curl -fsS "https://$HOST/api/info" | json 'print("   /api/info: versão %s, ambiente %s" % (d["version"], d["environment"]))' || ruim "/api/info não respondeu"
}

conferir() {
  local token alertas feed
  token="$(entrar)"
  alertas="$(codigo "$token" /api/alerts)"
  feed="$(codigo "$token" /api/feed)"
  mostrar_versao
  [ "$alertas" = 200 ] && ok "Tela de alertas: HTTP $alertas" || ruim "Tela de alertas: HTTP $alertas"
  [ "$feed" = 200 ] && ok "Painel ao vivo: HTTP $feed" || ruim "Painel ao vivo: HTTP $feed"
  [ "$alertas" = 200 ] && [ "$feed" = 200 ]
}

sentinela_url() {
  kubectl -n sentinela get ingress sentinela -o jsonpath='{.spec.rules[0].host}' 2>/dev/null || true
}

# ---------------------------------------------------------------- executar --
executar() {
  command -v helm >/dev/null && command -v kubectl >/dev/null || { ruim "Rode na VM, onde estão helm e kubectl."; exit 1; }
  helm status "$REL" -n "$NS" >/dev/null 2>&1 || { ruim "Release $REL não encontrada no namespace $NS."; exit 1; }
  HOST="$(dominio)"
  local sentinela; sentinela="$(sentinela_url)"

  etapa "0. Antes do desastre: $NOME ($HOST)"
  preparar
  local atual; atual="$(versao_atual)"
  if [ "$atual" != "$VERSAO_BASE" ]; then
    local base_rev
    if base_rev="$(revisao_com_versao "$VERSAO_BASE")"; then
      aviso "$NOME está na versão $atual. Voltando para a $VERSAO_BASE (revisão $base_rev) para a história começar do jeito certo."
      helm rollback "$REL" "$base_rev" -n "$NS" --wait --timeout 10m
    else
      aviso "Não achei uma revisão $VERSAO_BASE no histórico; a demonstração parte da versão $atual."
    fi
  fi
  BASE_REV="$(revisao_atual)"
  helm history "$REL" -n "$NS" --max 5
  conferir || aviso "Algo já estava com problema antes do desastre; confira antes de continuar."
  echo
  echo "   Mostre no celular: https://$HOST (login, painel e tela Alertas funcionando)."
  [ -n "$sentinela" ] && echo "   Mostre o Sentinela: https://$sentinela (Visão geral sem incidentes da aplicação)."
  pausa "Enter para publicar a versão $VERSAO_RUIM"

  etapa "1. Upgrade para a $VERSAO_RUIM (com o defeito)"
  local inicio; inicio=$(date +%s)
  bash "$COPIA_RUIM/scripts/deploy.sh" "$AMBIENTE" "$HOST" "$VERSAO_RUIM"
  ok "O Helm deu o deploy como sucesso em $(( $(date +%s) - inicio )) s: pods prontos e teste de fumaça aprovado."
  echo "   Repare: as sondas de saúde e o 'helm test' não usam a tela de alertas, então nada acusou o defeito."

  etapa "2. O sistema quebrou para quem usa"
  conferir || true
  echo
  echo "   Simulando operadores abrindo o painel por 1 minuto..."
  local token erros=0 total=0 c
  token="$(entrar)"
  for _ in $(seq 1 15); do
    for caminho in /api/alerts /api/feed; do
      c="$(codigo "$token" "$caminho")"
      total=$((total + 1))
      [ "$c" = 500 ] && erros=$((erros + 1))
    done
    sleep 4
  done
  ruim "$erros de $total requisições terminaram em erro 500."
  echo
  echo "   A causa, pelo log da API (o mesmo que chega ao Sentinela por syslog):"
  kubectl -n "$NS" logs -l "app.kubernetes.io/instance=$REL,app.kubernetes.io/component=api" --since=5m --tail=300 2>/dev/null \
    | grep '"ERRO_INTERNO"' | tail -1 \
    | json 'print("   rota:", d.get("route"), "| erro:", d.get("error"))' || echo "   (sem log de erro ainda)"
  echo
  echo "   No celular: depois do login aparece \"A operação não foi concluída\" no painel e em Alertas."
  if [ -n "$sentinela" ]; then
    echo "   No Sentinela (https://$sentinela):"
    echo "     - Incidentes: \"Erros internos na API ($NOME)\" e \"API respondendo com erro ($NOME)\";"
    echo "     - Segurança, tipo \"Erro interno da API\": a mesma mensagem do log;"
    echo "     - Visão geral: o site continua \"No ar\". A checagem externa passa; quem pegou foi o log."
  fi
  pausa "Enter para fazer o ROLLBACK"

  etapa "3. Rollback para a revisão $BASE_REV ($VERSAO_BASE)"
  local rev_ruim; rev_ruim="$(revisao_atual)"
  inicio=$(date +%s)
  helm rollback "$REL" "$BASE_REV" -n "$NS" --wait --timeout 10m
  kubectl -n "$NS" rollout status "deploy/$REL-api" --timeout=5m >/dev/null
  kubectl -n "$NS" rollout status "deploy/$REL-web" --timeout=5m >/dev/null
  ok "Rollback concluído em $(( $(date +%s) - inicio )) s."
  conferir && ok "Sistema funcionando de novo." || ruim "Ainda há erro; veja kubectl -n $NS get pods"
  helm history "$REL" -n "$NS" --max 5
  echo
  echo "   O que o rollback desfez: imagens, configuração e manifestos da revisão $rev_ruim."
  echo "   O que ele NÃO desfaz: dados do banco e Secrets. Por isso esta versão não mexeu no esquema do banco."
  [ -n "$sentinela" ] && echo "   No Sentinela, os incidentes se resolvem sozinhos em até 5 minutos, com a duração registrada."
  pausa "Enter para publicar a correção $VERSAO_BOA"

  etapa "4. Correção: upgrade para a $VERSAO_BOA"
  bash "$ROOT/scripts/deploy.sh" "$AMBIENTE" "$HOST" "$VERSAO_BOA"
  conferir && ok "Versão $VERSAO_BOA no ar." || ruim "A $VERSAO_BOA ainda tem erro; faça o rollback: helm rollback $REL -n $NS"
  echo
  echo "   Alertas com o nome do dono do crachá (como aparece na tela):"
  token="$(entrar)"
  curl -fsS -H "Authorization: Bearer $token" "https://$HOST/api/alerts?limit=200" \
    | json '
com = [a for a in d["items"] if a.get("citizen")]
sem = [a for a in d["items"] if a.get("badge") and not a.get("citizen")]
for a in com[:3]:
    print("   %s  %s: %s (%s)" % (a["time_local"], a["label"], a["citizen"], a["badge"]))
if not com:
    print("   Ainda não há alerta com crachá cadastrado; aparece no próximo uso de crachá revogado ou suspenso.")
print("   (%d alerta(s) com crachá não cadastrado aparecem como Não cadastrado)" % len(sem))'

  etapa "Histórico final (bom para o relatório)"
  helm history "$REL" -n "$NS" --max 8
  echo
  echo "Resumo: revisão $BASE_REV ($VERSAO_BASE) → $rev_ruim ($VERSAO_RUIM, defeito) → rollback → $(revisao_atual) ($VERSAO_BOA, corrigida)."
}

situacao() {
  HOST="$(dominio)"
  echo "$NOME: https://$HOST, versão $(versao_atual), revisão $(revisao_atual)"
  helm history "$REL" -n "$NS" --max 8
  conferir || true
}

case "$ACAO" in
  preparar) preparar ;;
  executar) executar ;;
  situacao|status) situacao ;;
  *)
    echo "Uso: bash scripts/desastre-controlado.sh preparar | executar [prod|staging] | situacao [prod|staging]"
    exit 1 ;;
esac
