'use strict';

// Comportamento do painel. Todo conteúdo vindo da API é inserido com
// textContent (nunca innerHTML), para que nenhum dado vire código na página.

(function () {
  const body = document.body;

  // Confirmação antes de ações sensíveis (revogar crachá, rotacionar chave...).
  document.addEventListener('submit', (ev) => {
    const msg = ev.target.dataset ? ev.target.dataset.confirm : null;
    if (msg && !window.confirm(msg)) ev.preventDefault();
  });

  if (body.dataset.page !== 'painel') return;

  const SVG = 'http://www.w3.org/2000/svg';
  const feed = document.getElementById('feed');
  const alertList = document.getElementById('alert-list');
  const live = document.getElementById('live-status');
  const liveText = document.getElementById('live-text');
  const chartBox = document.getElementById('chart');
  const canManage = body.dataset.canManage === 'sim';
  const csrf = body.dataset.csrf;
  const SEVERITY = { CRITICA: 'Crítica', ALTA: 'Alta', MEDIA: 'Média' };
  const MAX_ROWS = 80;

  let cursor = { ae: feed.dataset.ae || '0', al: feed.dataset.al || '0' };
  let series = [];
  try { series = JSON.parse(chartBox.dataset.series || '[]'); } catch (e) { series = []; }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }

  function setLive(ok) {
    live.dataset.state = ok ? 'ativo' : 'parado';
    liveText.textContent = ok ? 'Recebendo leituras' : 'Sem resposta da API; tentando de novo';
  }

  function eventRow(e) {
    const li = el('li', `feed-row ${e.decision === 'LIBERADO' ? 'is-pass' : 'is-deny'} is-new`);
    li.dataset.at = e.at;
    const t = el('time', 'feed-time', e.time_local);
    t.dateTime = e.at;
    const mark = el('span', 'feed-mark');
    mark.setAttribute('aria-hidden', 'true');
    const box = el('div');
    const status = el('p', 'feed-status');
    const icon = el('span', 'icon', e.decision === 'LIBERADO' ? '✓' : '✕');
    icon.setAttribute('aria-hidden', 'true');
    status.append(icon, e.decision === 'LIBERADO' ? 'Liberado' : `Negado: ${String(e.reason_text || '').toLowerCase()}`);
    const who = el('p', 'feed-who', e.citizen || 'Pessoa não identificada');
    const meta = el('p', 'feed-meta');
    meta.append(`${e.door_name} (`, el('span', 'nowrap', e.door), `), ${e.building_name}. `,
      el('span', 'nowrap', `${e.method === 'BIOMETRIA' ? 'Digital' : 'Crachá'} ${e.badge}`), '.');
    box.append(status, who, meta);
    li.append(t, mark, box);
    return li;
  }

  function alertRow(a) {
    const li = el('li', 'feed-row is-alert is-new');
    li.dataset.at = a.at;
    const t = el('time', 'feed-time', a.time_local);
    t.dateTime = a.at;
    const mark = el('span', 'feed-mark');
    mark.setAttribute('aria-hidden', 'true');
    const box = el('div');
    const status = el('p', 'feed-status');
    const icon = el('span', 'icon', '⚠');
    icon.setAttribute('aria-hidden', 'true');
    status.append(icon, `Alerta ${(SEVERITY[a.severity] || a.severity).toLowerCase()}: ${String(a.label).toLowerCase()}`);
    box.append(status, el('p', 'feed-meta', a.details));
    li.append(t, mark, box);
    return li;
  }

  function actionForm(id, action, label) {
    const f = el('form', 'inline-form');
    f.method = 'post';
    f.action = `/alertas/${encodeURIComponent(id)}/${action}`;
    const token = el('input');
    token.type = 'hidden';
    token.name = 'csrf_token';
    token.value = csrf;
    const btn = el('button', 'btn btn-secondary btn-small', label);
    btn.type = 'submit';
    f.append(token, btn);
    return f;
  }

  function alertItem(a) {
    const li = el('li', 'alert-item');
    const top = el('div', 'alert-top');
    top.append(el('span', `sev sev-${a.severity}`, SEVERITY[a.severity] || a.severity), el('span', 'alert-title', a.label), el('span', 'alert-time', a.time_local));
    li.append(top, el('p', 'alert-details', a.details));
    if (canManage) {
      const actions = el('div', 'alert-actions');
      actions.append(actionForm(a.id, 'reconhecer', 'Assumir atendimento'), actionForm(a.id, 'resolver', 'Marcar como resolvido'));
      li.append(actions);
    }
    return li;
  }

  async function getJson(url) {
    const r = await fetch(url, { headers: { Accept: 'application/json' }, credentials: 'same-origin', cache: 'no-store' });
    if (r.status === 401) {
      window.location.href = '/login?next=/';
      throw new Error('sessão expirada');
    }
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }

  async function pollFeed() {
    const data = await getJson(`/painel/feed?ae=${encodeURIComponent(cursor.ae)}&al=${encodeURIComponent(cursor.al)}`);
    const items = [
      ...data.events.map((e) => ({ at: e.at, node: () => eventRow(e) })),
      ...data.alerts.map((a) => ({ at: a.at, node: () => alertRow(a) })),
    ].sort((x, y) => (x.at < y.at ? -1 : 1));
    if (items.length) {
      const empty = document.getElementById('feed-empty');
      if (empty) empty.remove();
      for (const it of items) feed.prepend(it.node());
      while (feed.children.length > MAX_ROWS) feed.lastElementChild.remove();
    }
    const fresh = data.alerts.filter((a) => a.status !== 'RESOLVIDO').sort((x, y) => (x.id - y.id));
    if (data.alerts.length) pollDashboard().catch(() => {});
    if (fresh.length) {
      const empty = document.getElementById('alerts-empty');
      if (empty) empty.remove();
      for (const a of fresh) alertList.prepend(alertItem(a));
      while (alertList.children.length > 20) alertList.lastElementChild.remove();
    }
    cursor = { ae: String(data.cursor.ae), al: String(data.cursor.al) };
    setTimeout(() => feed.querySelectorAll('.is-new').forEach((n) => n.classList.remove('is-new')), 1200);
  }

  function setText(id, value) {
    const n = document.getElementById(id);
    if (n) n.textContent = value;
  }

  async function pollDashboard() {
    const d = await getJson('/painel/dados');
    setText('k-liberados', d.today.liberados.toLocaleString('pt-BR'));
    setText('k-negados', d.today.negados.toLocaleString('pt-BR'));
    setText('k-taxa', `${d.today.denial_rate.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}% das leituras`);
    setText('k-alertas', d.alerts_open.total.toLocaleString('pt-BR'));
    setText('k-criticos', `${d.alerts_open.CRITICA} crítico(s)`);
    setText('k-online', String(d.doors.online));
    if (d.jwt) setText('next-rotation', d.jwt.next_rotation_local);
    series = d.series;
    drawChart();
    fillTable();
  }

  // ------------------------------------------------------------ gráfico --

  function niceStep(max) {
    const raw = Math.max(1, max) / 4;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const n = raw / mag;
    return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * mag;
  }

  function svg(tag, attrs) {
    const n = document.createElementNS(SVG, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, String(v));
    return n;
  }

  // Barra com cantos arredondados só no topo (dado), reta na base.
  function topRounded(x, y, w, h, r) {
    const rr = Math.min(r, w / 2, h);
    return `M${x},${y + h} V${y + rr} Q${x},${y} ${x + rr},${y} H${x + w - rr} Q${x + w},${y} ${x + w},${y + rr} V${y + h} Z`;
  }

  function drawChart() {
    if (!chartBox || !series.length) return;
    chartBox.querySelectorAll('svg, .chart-tip').forEach((n) => n.remove());
    const W = Math.max(300, chartBox.clientWidth);
    const H = 210;
    const m = { l: 34, r: 6, t: 10, b: 26 };
    const iw = W - m.l - m.r;
    const ih = H - m.t - m.b;
    const max = Math.max(1, ...series.map((s) => s.liberado + s.negado));
    const step = niceStep(max);
    const top = Math.ceil(max / step) * step;
    const y = (v) => m.t + ih - (v / top) * ih;
    const slot = iw / series.length;
    const bw = Math.min(24, Math.max(3, slot - 2));
    const root = svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'chart', role: 'img', 'aria-label': 'Leituras liberadas e negadas por minuto nos últimos 30 minutos' });

    for (let v = 0; v <= top; v += step) {
      root.append(svg('line', { class: 'grid', x1: m.l, x2: W - m.r, y1: y(v), y2: y(v) }));
      const lbl = svg('text', { class: 'axis-label', x: m.l - 6, y: y(v) + 4, 'text-anchor': 'end' });
      lbl.textContent = v.toLocaleString('pt-BR');
      root.append(lbl);
    }

    const tip = el('div', 'chart-tip');
    tip.hidden = true;

    series.forEach((s, i) => {
      const x = m.l + i * slot + (slot - bw) / 2;
      const base = y(0);
      const hp = base - y(s.liberado);
      const hn = base - y(s.negado);
      const gap = s.liberado && s.negado ? 2 : 0;
      if (s.liberado) {
        const path = s.negado ? `M${x},${base} V${base - hp} H${x + bw} V${base} Z` : topRounded(x, base - hp, bw, hp, 4);
        root.append(svg('path', { class: 'bar-pass', d: path }));
      }
      if (s.negado) {
        root.append(svg('path', { class: 'bar-deny', d: topRounded(x, base - hp - gap - hn, bw, hn, 4) }));
      }
      if (i % 5 === 4 || i === series.length - 1) {
        const lbl = svg('text', { class: 'axis-label', x: m.l + i * slot + slot / 2, y: H - 6, 'text-anchor': 'middle' });
        lbl.textContent = s.minute;
        root.append(lbl);
      }
      const hit = svg('rect', { class: 'hit', x: m.l + i * slot, y: m.t, width: slot, height: ih });
      const show = () => {
        tip.textContent = `${s.minute}: ${s.liberado} liberada(s), ${s.negado} negada(s)`;
        tip.style.left = `${((m.l + i * slot + slot / 2) / W) * 100}%`;
        tip.style.top = `${(Math.min(y(s.liberado + s.negado), base - 4) / H) * 100}%`;
        tip.hidden = false;
      };
      hit.addEventListener('pointerenter', show);
      hit.addEventListener('pointerdown', show);
      hit.addEventListener('pointerleave', () => { tip.hidden = true; });
      root.append(hit);
    });

    chartBox.append(root, tip);
  }

  function fillTable() {
    const tbody = document.querySelector('#chart-table tbody');
    if (!tbody) return;
    tbody.replaceChildren(...series.map((s) => {
      const tr = el('tr');
      const n1 = el('td', 'num', String(s.liberado));
      const n2 = el('td', 'num', String(s.negado));
      tr.append(el('td', null, s.minute), n1, n2);
      return tr;
    }));
  }

  // ------------------------------------------------------------ ciclo --

  function loop(fn, ms) {
    const run = async () => {
      if (!document.hidden) {
        try {
          await fn();
          setLive(true);
        } catch (e) {
          setLive(false);
        }
      }
      setTimeout(run, ms);
    };
    setTimeout(run, ms);
  }

  drawChart();
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(drawChart, 150);
  });
  loop(pollFeed, 3000);
  loop(pollDashboard, 10000);
}());
