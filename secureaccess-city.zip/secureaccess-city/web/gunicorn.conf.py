"""Configuração do gunicorn para o front em produção."""

bind = "0.0.0.0:8000"
workers = 2
threads = 4
worker_class = "gthread"
timeout = 30
graceful_timeout = 20
keepalive = 5
worker_tmp_dir = "/tmp"  # o sistema de arquivos do container é somente leitura
limit_request_line = 4096
limit_request_fields = 60

# Log de acesso em JSON, sem query string (%(U)s), para não registrar dados pessoais.
accesslog = "-"
errorlog = "-"
access_log_format = (
    '{"ts":"%(t)s","level":"info","service":"secureaccess-web","event":"HTTP_REQUISICAO",'
    '"category":"http","method":"%(m)s","route":"%(U)s","status":%(s)s,"duration_ms":%(M)s,'
    '"source_ip":"%({x-forwarded-for}i)s"}'
)
