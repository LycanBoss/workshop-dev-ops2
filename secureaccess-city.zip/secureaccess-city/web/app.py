"""Painel do operador da SecureAccess City (front em Python/Flask).

O navegador conversa só com este front. O front guarda o token JWT da API
na sessão (cookie assinado, HttpOnly) e chama a API servidor a servidor,
dentro do cluster. Assim o token nunca fica acessível a JavaScript.
"""

from __future__ import annotations

import hmac
import os
import re
import secrets
import threading
import time
from functools import wraps

import requests
from flask import (
    Flask,
    abort,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.middleware.proxy_fix import ProxyFix

ROLE_LABELS = {"ADMIN": "Administrador", "OPERADOR": "Operador", "AUDITOR": "Auditor"}
ENV_LABELS = {"development": "Desenvolvimento", "test": "Teste", "staging": "Homologação", "production": "Produção"}
CATEGORY_LABELS = {"SERVIDOR": "Servidor", "TERCEIRIZADO": "Terceirizado", "VISITANTE": "Visitante", "SEGURANCA": "Segurança"}
STATUS_LABELS = {"ATIVO": "Ativo", "SUSPENSO": "Suspenso", "REVOGADO": "Revogado"}
ALERT_STATUS_LABELS = {"ABERTO": "Aberto", "RECONHECIDO": "Em atendimento", "RESOLVIDO": "Resolvido"}
SEVERITY_LABELS = {"CRITICA": "Crítica", "ALTA": "Alta", "MEDIA": "Média"}
LEVEL_LABELS = {1: "Público", 2: "Restrito", 3: "Crítico"}
KEY_STATE_LABELS = {"ATIVA": "Assinando tokens", "SOMENTE_VERIFICACAO": "Só verifica tokens já emitidos", "EXPIRADA": "Expirada"}

SCENARIOS = [
    ("ACESSO_VALIDO", "Acesso válido", "Um servidor autorizado passa o crachá numa porta do seu prédio."),
    ("BIOMETRIA_VALIDA", "Biometria válida", "Leitura de digital de alguém cadastrado com biometria."),
    ("CRACHA_DESCONHECIDO", "Crachá desconhecido", "Um número de crachá que não existe é apresentado."),
    ("CRACHA_REVOGADO", "Crachá revogado", "Alguém tenta usar um crachá já revogado. Gera alerta."),
    ("NIVEL_INSUFICIENTE", "Nível insuficiente", "Servidora de nível público tenta abrir a porta do gabinete."),
    ("FORCA_BRUTA", "Força bruta", "Seis crachás inventados em sequência na mesma catraca. Gera alerta."),
    ("VARREDURA_CRACHA", "Crachá clonado", "O mesmo crachá desconhecido testado em três prédios. Gera alerta."),
    ("PORTA_FORCADA", "Porta forçada", "O sensor da porta abre sem leitura válida. Alerta crítico."),
    ("CARONA", "Entrada de carona", "Duas pessoas passam com uma única leitura."),
    ("SABOTAGEM", "Sabotagem do leitor", "A tampa do leitor de crachá é removida. Alerta crítico."),
]
SCENARIO_CODES = {code for code, _, _ in SCENARIOS}

CODE_RE = re.compile(r"^[A-Z0-9-]{2,32}$")
BUILDING_RE = re.compile(r"^[A-Z0-9]{2,16}$")
SEARCH_RE = re.compile(r"^[A-Za-z0-9-]{1,20}$")


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, field: str | None = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.field = field


class ApiUnavailable(Exception):
    pass


class SessionExpired(Exception):
    pass


class ApiClient:
    """Cliente HTTP da API. Uma sessão requests por thread (o gunicorn usa threads)."""

    def __init__(self, base_url: str, timeout=(3, 10)):
        self.base = base_url.rstrip("/")
        self.timeout = timeout
        self.local = threading.local()

    def _http(self) -> requests.Session:
        if not hasattr(self.local, "http"):
            s = requests.Session()
            s.trust_env = False  # chamada interna: nunca passa por proxy
            self.local.http = s
        return self.local.http

    def call(self, method, path, token=None, json=None, params=None, client_ip=None):
        headers = {"Accept": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        if client_ip:
            headers["X-Forwarded-For"] = client_ip
        try:
            r = self._http().request(method, self.base + path, headers=headers, json=json, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise ApiUnavailable(str(exc)) from exc
        try:
            body = r.json()
        except ValueError:
            body = {}
        if r.status_code >= 400:
            raise ApiError(r.status_code, body.get("error", "ERRO"), body.get("message", "A API recusou a operação."), body.get("field"))
        return body


def _env_bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None or v == "":
        return default
    return v.lower() in ("1", "true", "yes", "sim", "on")


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app_env = os.environ.get("APP_ENV", "development")
    secret_key = os.environ.get("SECRET_KEY")
    if not secret_key:
        if app_env not in ("development", "test"):
            raise RuntimeError("Segredo obrigatório ausente: SECRET_KEY")
        secret_key = "somente-desenvolvimento-troque-esta-chave"

    https = app_env in ("staging", "production")
    app.config.update(
        SECRET_KEY=secret_key,
        SESSION_COOKIE_NAME="sa_session",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=_env_bool("SESSION_COOKIE_SECURE", https),
        PERMANENT_SESSION_LIFETIME=8 * 3600,
        MAX_CONTENT_LENGTH=64 * 1024,
        APP_ENV=app_env,
        API_URL=os.environ.get("API_URL", "http://localhost:3000"),
        APP_VERSION=os.environ.get("APP_VERSION", "1.0.0"),
        GIT_COMMIT=os.environ.get("GIT_COMMIT", "local"),
        HSTS=_env_bool("HSTS", app_env == "production"),
        CITY_NAME=os.environ.get("CITY_NAME", "Cidade Inteligente"),
    )
    if test_config:
        app.config.update(test_config)

    # Um proxy confiável na frente (Traefik): o IP real é o último do X-Forwarded-For.
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)
    api = ApiClient(app.config["API_URL"])
    app.extensions["api"] = api

    # ------------------------------------------------------------ helpers --

    def client_ip():
        return request.remote_addr or ""

    def store_token(body):
        session["token"] = body["token"]
        session["token_exp"] = time.time() + int(body.get("expires_in", 600))
        session["user"] = {"username": body["username"], "role": body["role"]}

    def fresh_token():
        token = session.get("token")
        if not token:
            raise SessionExpired()
        if session.get("token_exp", 0) - time.time() < 120:
            try:
                body = api.call("POST", "/api/auth/refresh", token=token, client_ip=client_ip())
            except ApiError as exc:
                if exc.status == 401:
                    raise SessionExpired() from exc
                raise
            store_token(body)
        return session["token"]

    def api_call(method, path, **kwargs):
        try:
            return api.call(method, path, token=fresh_token(), client_ip=client_ip(), **kwargs)
        except ApiError as exc:
            if exc.status == 401:
                raise SessionExpired() from exc
            raise

    def role():
        return (session.get("user") or {}).get("role")

    def login_required(roles=None):
        def deco(fn):
            @wraps(fn)
            def wrapper(*args, **kwargs):
                if not session.get("token"):
                    if request.path.startswith("/painel/"):
                        return jsonify(error="SESSAO_EXPIRADA"), 401
                    return redirect(url_for("login", next=request.full_path.rstrip("?")))
                if roles and role() not in roles:
                    abort(403)
                return fn(*args, **kwargs)
            return wrapper
        return deco

    def safe_next(target):
        if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
            return target
        return None

    def ensure_csrf():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(32)
        return session["csrf"]

    # --------------------------------------------------------- segurança --

    @app.before_request
    def check_csrf():
        if request.method == "POST":
            sent = request.form.get("csrf_token", "")
            expected = session.get("csrf", "")
            if not sent or not expected or not hmac.compare_digest(sent, expected):
                abort(400, description="Formulário expirado. Recarregue a página e tente de novo.")

    @app.after_request
    def security_headers(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; font-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'; object-src 'none'"
        )
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        if app.config["HSTS"]:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if session.get("token") or request.path.startswith("/painel/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.context_processor
    def inject():
        return {
            "user": session.get("user"),
            "role": role(),
            "csrf_token": ensure_csrf(),
            "env": app.config["APP_ENV"],
            "env_label": ENV_LABELS.get(app.config["APP_ENV"], app.config["APP_ENV"]),
            "version": app.config["APP_VERSION"],
            "commit": app.config["GIT_COMMIT"][:12],
            "city": app.config["CITY_NAME"],
            "ROLE_LABELS": ROLE_LABELS,
            "CATEGORY_LABELS": CATEGORY_LABELS,
            "STATUS_LABELS": STATUS_LABELS,
            "ALERT_STATUS_LABELS": ALERT_STATUS_LABELS,
            "SEVERITY_LABELS": SEVERITY_LABELS,
            "LEVEL_LABELS": LEVEL_LABELS,
            "KEY_STATE_LABELS": KEY_STATE_LABELS,
        }

    # ------------------------------------------------------------ erros --

    @app.errorhandler(SessionExpired)
    def on_session_expired(_exc):
        session.pop("token", None)
        session.pop("user", None)
        if request.path.startswith("/painel/"):
            return jsonify(error="SESSAO_EXPIRADA"), 401
        flash("Sua sessão expirou. Entre novamente.", "info")
        return redirect(url_for("login", next=request.full_path.rstrip("?")))

    @app.errorhandler(ApiUnavailable)
    def on_api_down(_exc):
        if request.path.startswith("/painel/"):
            return jsonify(error="API_INDISPONIVEL"), 503
        return render_template("erro.html", status=503, title="A API não respondeu",
                               message="O serviço de controle de acesso está fora do ar ou reiniciando. Tente de novo em alguns segundos."), 503

    @app.errorhandler(ApiError)
    def on_api_error(exc):
        if request.path.startswith("/painel/"):
            return jsonify(error=exc.code, message=exc.message), exc.status
        title = "Sem permissão" if exc.status == 403 else "A operação não foi concluída"
        return render_template("erro.html", status=exc.status, title=title, message=exc.message), exc.status

    @app.errorhandler(400)
    def on_400(exc):
        return render_template("erro.html", status=400, title="Requisição inválida", message=exc.description), 400

    @app.errorhandler(403)
    def on_403(_exc):
        return render_template("erro.html", status=403, title="Sem permissão",
                               message="Seu perfil não tem acesso a esta área."), 403

    @app.errorhandler(404)
    def on_404(_exc):
        return render_template("erro.html", status=404, title="Página não encontrada",
                               message="Confira o endereço ou volte para o painel."), 404

    # ----------------------------------------------------------- saúde --

    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}

    # ----------------------------------------------------------- login --

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()[:64]
            password = request.form.get("password", "")[:200]
            if not username or not password:
                return render_template("login.html", error="Informe usuário e senha.", username=username), 400
            try:
                body = api.call("POST", "/api/auth/login", json={"username": username, "password": password}, client_ip=client_ip())
            except ApiError as exc:
                messages = {
                    401: "Usuário ou senha incorretos.",
                    423: "Conta bloqueada por 5 minutos depois de várias senhas incorretas.",
                    429: "Muitas tentativas seguidas. Aguarde um minuto e tente de novo.",
                    422: "Usuário em formato inválido.",
                }
                status = exc.status if exc.status in messages else 400
                return render_template("login.html", error=messages.get(exc.status, exc.message), username=username), status
            nxt = safe_next(request.args.get("next"))
            session.clear()
            session.permanent = True
            store_token(body)
            ensure_csrf()
            return redirect(nxt or url_for("painel"))
        if session.get("token"):
            return redirect(url_for("painel"))
        return render_template("login.html")

    @app.post("/sair")
    def logout():
        session.clear()
        flash("Você saiu do painel.", "info")
        return redirect(url_for("login"))

    # ----------------------------------------------------------- painel --

    @app.get("/")
    @login_required()
    def painel():
        dashboard = api_call("GET", "/api/dashboard")
        feed = api_call("GET", "/api/feed")
        return render_template("painel.html", d=dashboard, feed=feed, page="painel")

    @app.get("/painel/dados")
    @login_required()
    def painel_dados():
        return jsonify(api_call("GET", "/api/dashboard"))

    @app.get("/painel/feed")
    @login_required()
    def painel_feed():
        params = {}
        for key in ("ae", "al"):
            raw = request.args.get(key, "")
            if raw.isdigit():
                params[key] = raw
        return jsonify(api_call("GET", "/api/feed", params=params))

    # ---------------------------------------------------------- eventos --

    @app.get("/eventos")
    @login_required()
    def eventos():
        filters = {
            "decision": request.args.get("decision", "") if request.args.get("decision") in ("LIBERADO", "NEGADO") else "",
            "building": request.args.get("building", "").upper() if BUILDING_RE.match(request.args.get("building", "").upper()) else "",
            "door": request.args.get("door", "").upper() if CODE_RE.match(request.args.get("door", "").upper()) else "",
            "badge": request.args.get("badge", "").upper() if CODE_RE.match(request.args.get("badge", "").upper()) else "",
        }
        params = {k: v for k, v in filters.items() if v}
        before = request.args.get("before", "")
        if before.isdigit():
            params["before"] = before
        params["limit"] = 50
        data = api_call("GET", "/api/events", params=params)
        buildings = api_call("GET", "/api/buildings")["items"]
        doors = api_call("GET", "/api/doors")["items"]
        next_params = {k: v for k, v in filters.items() if v}
        if data.get("next_before"):
            next_params["before"] = data["next_before"]
        return render_template("eventos.html", items=data["items"], filters=filters, buildings=buildings, doors=doors,
                               next_url=url_for("eventos", **next_params) if data.get("next_before") else None,
                               is_paged=bool(params.get("before")), page="eventos")

    # ---------------------------------------------------------- alertas --

    @app.get("/alertas")
    @login_required()
    def alertas():
        tab = request.args.get("status", "ATIVOS")
        if tab not in ("ATIVOS", "RESOLVIDO", "TODOS"):
            tab = "ATIVOS"
        params = {"limit": 200}
        if tab != "TODOS":
            params["status"] = tab
        items = api_call("GET", "/api/alerts", params=params)["items"]
        return render_template("alertas.html", items=items, tab=tab, page="alertas")

    @app.post("/alertas/<int:alert_id>/<acao>")
    @login_required(roles=("ADMIN", "OPERADOR"))
    def alerta_acao(alert_id, acao):
        if acao not in ("reconhecer", "resolver"):
            abort(404)
        path = f"/api/alerts/{alert_id}/{'ack' if acao == 'reconhecer' else 'resolve'}"
        try:
            api_call("POST", path)
            flash(f"Alerta #{alert_id} {'em atendimento' if acao == 'reconhecer' else 'resolvido'}.", "ok")
        except ApiError as exc:
            if exc.status not in (404, 409):
                raise
            flash(exc.message, "erro")
        return redirect(url_for("alertas", status=request.form.get("tab", "ATIVOS")))

    # ---------------------------------------------------------- crachás --

    # A busca usa POST para que o documento (CPF) nunca apareça na URL,
    # no histórico do navegador ou nos logs de acesso do proxy.
    @app.route("/crachas", methods=["GET", "POST"])
    @login_required()
    def crachas():
        src = request.form if request.method == "POST" else request.args
        raw = src.get("q", "").strip()
        digits = re.sub(r"[.\-\s]", "", raw)
        q = digits if digits.isdigit() and len(digits) == 11 else raw.upper()
        status = src.get("status", "")
        params = {}
        if q and SEARCH_RE.match(q):
            params["q"] = q
        elif q:
            flash("Busque pelo número do crachá (ex.: SA-10001) ou pelo documento com 11 dígitos.", "erro")
        if status in ("ATIVO", "SUSPENSO", "REVOGADO"):
            params["status"] = status
        items = api_call("GET", "/api/citizens", params=params)["items"]
        return render_template("crachas.html", items=items, q=raw, status=status, page="crachas")

    @app.post("/crachas/<int:citizen_id>/status")
    @login_required(roles=("ADMIN", "OPERADOR"))
    def cracha_status(citizen_id):
        status = request.form.get("status", "")
        if status not in ("ATIVO", "SUSPENSO", "REVOGADO"):
            abort(400, description="Situação inválida.")
        body = {"status": status}
        reason = request.form.get("reason", "").strip()[:160]
        if reason:
            body["reason"] = reason
        try:
            r = api_call("POST", f"/api/citizens/{citizen_id}/status", json=body)
            verbs = {"ATIVO": "reativado", "SUSPENSO": "suspenso", "REVOGADO": "revogado"}
            flash(f"Crachá {r['badge']} {verbs[status]}.", "ok")
        except ApiError as exc:
            if exc.status not in (403, 404, 409, 422):
                raise
            flash(exc.message, "erro")
        return redirect(request.form.get("back") if safe_next(request.form.get("back")) else url_for("crachas"))

    @app.route("/crachas/novo", methods=["GET", "POST"])
    @login_required(roles=("ADMIN",))
    def cracha_novo():
        buildings = api_call("GET", "/api/buildings")["items"]
        form = {}
        error = None
        if request.method == "POST":
            form = {
                "name": request.form.get("name", "").strip(),
                "document": request.form.get("document", "").strip(),
                "category": request.form.get("category", ""),
                "department": request.form.get("department", "").strip(),
                "access_level": request.form.get("access_level", "1"),
                "buildings": request.form.getlist("buildings"),
                "valid_until": request.form.get("valid_until", "").strip(),
                "all_hours": request.form.get("all_hours") == "on",
                "biometric_template": request.form.get("biometric_template", "").strip(),
            }
            payload = {k: v for k, v in form.items() if v not in ("", None)}
            payload["all_hours"] = form["all_hours"]
            payload["access_level"] = int(form["access_level"]) if form["access_level"].isdigit() else 0
            try:
                created = api_call("POST", "/api/citizens", json=payload)
                flash(f"Crachá {created['badge']} emitido.", "ok")
                return redirect(url_for("crachas", q=created["badge"]))
            except ApiError as exc:
                if exc.status not in (409, 422):
                    raise
                error = exc.message
        return render_template("cracha_novo.html", buildings=buildings, form=form, error=error, page="crachas"), (422 if error else 200)

    # ----------------------------------------------------------- portas --

    @app.get("/portas")
    @login_required()
    def portas():
        doors = api_call("GET", "/api/doors")["items"]
        groups = []
        for d in doors:
            if not groups or groups[-1]["code"] != d["building"]:
                groups.append({"code": d["building"], "name": d["building_name"], "hours": d["hours"], "open": d["building_open"], "doors": []})
            groups[-1]["doors"].append(d)
        return render_template("portas.html", groups=groups, page="portas")

    # -------------------------------------------------------- segurança --

    @app.get("/seguranca")
    @login_required(roles=("ADMIN", "AUDITOR"))
    def seguranca():
        keys = api_call("GET", "/api/security/keys")
        only_failures = request.args.get("falhas") == "1"
        params = {"limit": 150}
        if only_failures:
            params["outcome"] = "FALHA"
        audit = api_call("GET", "/api/audit", params=params)["items"]
        info = api.call("GET", "/api/info")
        return render_template("seguranca.html", keys=keys, audit=audit, only_failures=only_failures, info=info, page="seguranca")

    @app.post("/seguranca/rotacionar")
    @login_required(roles=("ADMIN",))
    def rotacionar():
        r = api_call("POST", "/api/security/keys/rotate")
        flash(f"Nova chave {r['kid']} ativa. Tokens já emitidos continuam válidos até expirar.", "ok")
        return redirect(url_for("seguranca"))

    # -------------------------------------------------------- simulador --

    @app.route("/simulador", methods=["GET", "POST"])
    @login_required(roles=("ADMIN",))
    def simulador():
        enabled = api_call("GET", "/api/dashboard").get("simulation_enabled", False)
        result = None
        if request.method == "POST":
            scenario = request.form.get("scenario", "")
            if scenario not in SCENARIO_CODES:
                abort(400, description="Cenário desconhecido.")
            try:
                result = api_call("POST", "/api/simulate", json={"scenario": scenario})
                result["label"] = next(label for code, label, _ in SCENARIOS if code == scenario)
            except ApiError as exc:
                if exc.status != 403:
                    raise
                flash(exc.message, "erro")
        return render_template("simulador.html", scenarios=SCENARIOS, enabled=enabled, result=result, page="simulador")

    return app


if __name__ == "__main__":  # pragma: no cover - uso local apenas
    create_app().run(host="127.0.0.1", port=int(os.environ.get("PORT", "8000")), debug=False)
