"""Testes do front (python -m unittest). A API é substituída por um dublê."""

import os
import re
import sys
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("APP_ENV", "test")

from app import ApiError, ApiUnavailable, create_app  # noqa: E402

DASH = {
    "today": {"liberados": 10, "negados": 2, "total": 12, "denial_rate": 16.7},
    "alerts_open": {"CRITICA": 1, "ALTA": 0, "MEDIA": 0, "total": 1},
    "doors": {"online": 9, "total": 9},
    "series": [{"minute": "10:00", "liberado": 1, "negado": 0}] * 30,
    "denied_reasons": [{"reason": "CREDENCIAL_DESCONHECIDA", "label": "Credencial não cadastrada", "count": 2}],
    "top_denied_doors": [],
    "jwt": {"active_kid": "kabc123", "next_rotation_local": "11:00"},
    "simulation_enabled": True,
}
EVENT = {
    "id": 1, "at": "2026-10-20T13:00:00.000Z", "time_local": "10:00:00", "date_local": "20/10/2026",
    "door": "PREF-CAT01", "door_name": "Catraca", "building": "PREF", "building_name": "Prefeitura",
    "badge": "SA-10001", "citizen": "<script>alert(1)</script>", "method": "CRACHA", "decision": "LIBERADO",
    "reason": "OK", "reason_text": "Acesso autorizado", "source": "catraca",
}


class FakeApi:
    def __init__(self):
        self.calls = []
        self.fail_with = None
        self.expire_token = False

    def call(self, method, path, token=None, json=None, params=None, client_ip=None):
        self.calls.append((method, path, token, json, params, client_ip))
        if self.fail_with:
            raise self.fail_with
        if path == "/api/auth/login":
            if json["password"] != "certa":
                raise ApiError(401, "CREDENCIAIS_INVALIDAS", "Usuário ou senha inválidos")
            role = {"admin": "ADMIN", "auditor": "AUDITOR"}.get(json["username"], "OPERADOR")
            return {"token": f"tok-{json['username']}", "expires_in": 900, "username": json["username"], "role": role}
        if self.expire_token and path != "/api/auth/refresh":
            raise ApiError(401, "TOKEN_EXPIRADO", "Token expirado")
        if path == "/api/auth/refresh":
            return {"token": "tok-renovado", "expires_in": 900, "username": "admin", "role": "ADMIN"}
        if path == "/api/dashboard":
            return DASH
        if path == "/api/feed":
            return {"events": [EVENT], "alerts": [], "cursor": {"ae": 1, "al": 0}}
        if path == "/api/citizens":
            return {"items": []}
        if path == "/api/security/keys":
            return {"rotation_interval_sec": 3600, "operator_token_ttl_sec": 900, "device_token_ttl_sec": 300, "keys": []}
        if path == "/api/audit":
            return {"items": []}
        if path == "/api/info":
            return {"version": "1.0.0", "commit": "abc", "environment": "test"}
        if path == "/api/security/keys/rotate":
            return {"kid": "knova123"}
        return {"items": []}


class WebTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True})
        self.fake = FakeApi()
        self.app.extensions["api"].call = self.fake.call
        self.client = self.app.test_client()

    def csrf(self, path="/login"):
        html = self.client.get(path).get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)

    def login(self, username="admin"):
        token = self.csrf()
        return self.client.post("/login", data={"username": username, "password": "certa", "csrf_token": token})

    def test_login_redirects_and_keeps_token_out_of_html(self):
        r = self.login()
        self.assertEqual(r.status_code, 302)
        html = self.client.get("/").get_data(as_text=True)
        self.assertIn("Painel ao vivo", html)
        self.assertNotIn("tok-admin", html)

    def test_wrong_password_shows_message(self):
        token = self.csrf()
        r = self.client.post("/login", data={"username": "admin", "password": "errada", "csrf_token": token})
        self.assertEqual(r.status_code, 401)
        self.assertIn("Usuário ou senha incorretos", r.get_data(as_text=True))

    def test_post_without_csrf_is_rejected(self):
        self.login()
        r = self.client.post("/seguranca/rotacionar", data={})
        self.assertEqual(r.status_code, 400)
        self.assertFalse(any(c[1] == "/api/security/keys/rotate" for c in self.fake.calls))

    def test_admin_can_rotate_with_csrf(self):
        self.login()
        token = self.csrf("/seguranca")
        r = self.client.post("/seguranca/rotacionar", data={"csrf_token": token})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(any(c[1] == "/api/security/keys/rotate" for c in self.fake.calls))

    def test_security_headers(self):
        r = self.client.get("/login")
        csp = r.headers["Content-Security-Policy"]
        self.assertIn("script-src 'self'", csp)
        self.assertIn("frame-ancestors 'none'", csp)
        self.assertNotIn("unsafe-inline", csp)
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")

    def test_api_data_is_escaped(self):
        self.login()
        html = self.client.get("/").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;", html)

    def test_role_restrictions(self):
        self.login("auditor")
        self.assertEqual(self.client.get("/simulador").status_code, 403)
        self.assertEqual(self.client.get("/crachas/novo").status_code, 403)
        self.assertEqual(self.client.get("/seguranca").status_code, 200)

    def test_expired_session_goes_back_to_login(self):
        self.login()
        self.fake.expire_token = True
        r = self.client.get("/eventos")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])
        j = self.client.get("/painel/dados")
        self.assertEqual(j.status_code, 401)

    def test_token_is_refreshed_before_expiry(self):
        self.login()
        with self.client.session_transaction() as s:
            s["token_exp"] = time.time() + 30
        self.client.get("/painel/dados")
        self.assertTrue(any(c[1] == "/api/auth/refresh" for c in self.fake.calls))

    def test_document_search_uses_post_and_stays_out_of_url(self):
        self.login()
        token = self.csrf("/crachas")
        r = self.client.post("/crachas", data={"q": "000.123.456-78", "csrf_token": token})
        self.assertEqual(r.status_code, 200)
        sent = [c for c in self.fake.calls if c[1] == "/api/citizens"][-1]
        self.assertEqual(sent[4]["q"], "00012345678")

    def test_open_redirect_is_blocked(self):
        token = self.csrf()
        r = self.client.post("/login?next=//evil.example", data={"username": "admin", "password": "certa", "csrf_token": token})
        self.assertEqual(r.headers["Location"], "/")

    def test_api_down_returns_503(self):
        self.login()
        self.fake.fail_with = ApiUnavailable("conexão recusada")
        r = self.client.get("/eventos")
        self.assertEqual(r.status_code, 503)
        self.assertIn("A API não respondeu", r.get_data(as_text=True))

    def test_client_ip_is_forwarded_to_api(self):
        token = self.csrf()
        self.client.post("/login", data={"username": "admin", "password": "certa", "csrf_token": token},
                         headers={"X-Forwarded-For": "203.0.113.9"})
        login_call = [c for c in self.fake.calls if c[1] == "/api/auth/login"][-1]
        self.assertEqual(login_call[5], "203.0.113.9")


if __name__ == "__main__":
    unittest.main()
