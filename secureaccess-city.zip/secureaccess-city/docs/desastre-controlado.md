# Desastre controlado: upgrade, quebra e rollback

Roteiro do teste de upgrade e rollback do Desafio 3. Uma versão nova vai para o ar com um defeito, o sistema quebra para quem usa, o Sentinela detecta e o Helm devolve a versão anterior. Depois, a correção sobe.

| Versão | O que é |
|---|---|
| **1.0.0** | versão em produção, funcionando |
| **1.1.0** | função nova: **nome do dono do crachá na tela de alertas**, com um defeito |
| rollback | `helm rollback` volta para a 1.0.0 |
| **1.1.1** | a mesma função, corrigida |

## A função nova

Na tela **Alertas** e na lista de alertas do **Painel ao vivo** entra a informação "Titular do crachá":

- o **nome** de quem é dono do crachá citado no alerta (por exemplo, quem tentou usar um crachá revogado);
- **"Não cadastrado"** quando o crachá não existe (crachá clonado ou inventado, força bruta);
- **"—"** quando o alerta não envolve crachá (porta forçada, sabotagem, porta aberta).

O nome continua cifrado no banco (AES-256-GCM). A API só decifra na resposta para operadores autenticados, e ele nunca vai para os logs. Do ponto de vista da LGPD, o uso tem finalidade clara: identificar quem está envolvido num incidente de segurança. A tela só aparece para perfis que já viam os crachás.

## O defeito plantado (e por que ele passa despercebido)

Na 1.1.0, a consulta dos alertas pede a coluna `c.nome_enc`. A coluna certa é `c.name_enc`. É o tipo de erro comum quando se mistura português e inglês no código. O resultado:

| Verificação | Resultado na 1.1.0 |
|---|---|
| `helm upgrade --wait` (pods prontos) | ✔ passa |
| Sondas `/healthz` e `/readyz` | ✔ passam |
| `helm test` (teste de fumaça) | ✔ passa |
| Checagem externa do Sentinela (`/api/info` e `/login`) | ✔ passa: o site está "no ar" |
| Painel ao vivo e tela Alertas, depois do login | ✘ **"A operação não foi concluída"** (erro 500) |

O site responde e as checagens dizem que está tudo bem, mas quem entra não consegue trabalhar. Quem acusa o problema são os **logs**: cada erro 500 vira um evento `ERRO_INTERNO` no syslog, e o Sentinela abre os incidentes **"Erros internos na API"** e **"API respondendo com erro"**, com a mensagem exata do banco.

Os testes automatizados pegariam o defeito: o teste "painel, feed, eventos, alertas e portas respondem" falha com a 1.1.0. Na demonstração, o deploy é feito direto da VM, pulando o pipeline. Essa é a lição.

A 1.1.0 **não mexe no esquema do banco**, de propósito. O `helm rollback` desfaz imagens, configuração e manifestos, mas não desfaz dados nem Secrets. Uma migração de banco exigiria um plano de volta próprio.

## Como fazer

### 0. Atualizar o projeto na VM

Substitua o `secureaccess-city.zip` no GitHub pela versão nova e, na VM:

```bash
cd ~ && rm -rf secureaccess-city secureaccess-city.zip
wget -O secureaccess-city.zip https://github.com/LycanBoss/workshop-dev-ops2/raw/main/secureaccess-city.zip
unzip -q secureaccess-city.zip && cd secureaccess-city
```

Não precisa rodar o instalador antes. Se rodar, a produção vai direto para a 1.1.1, e o roteiro volta para a 1.0.0 sozinho antes de começar.

### 1. Preparar (antes da apresentação, uns 10 minutos)

```bash
bash scripts/desastre-controlado.sh preparar
```

Gera e escaneia com o Trivy as imagens da **1.1.0** (com o defeito, montada numa cópia separada em `~/.secureaccess-desastre`) e da **1.1.1** (a correta), e publica as duas no registro do cluster. Assim a apresentação não fica esperando build.

### 2. Ensaiar na homologação (recomendado)

```bash
bash scripts/desastre-controlado.sh executar staging
```

### 3. Executar ao vivo

```bash
bash scripts/desastre-controlado.sh executar prod
```

O roteiro para em cada etapa e espera Enter:

| Etapa | O que acontece | O que mostrar |
|---|---|---|
| **0. Antes** | confere a 1.0.0 no ar e mostra o `helm history` | celular: painel e Alertas funcionando; Sentinela sem incidentes da aplicação |
| **1. Upgrade 1.1.0** | `helm upgrade --wait` e `helm test` passam | "o Helm achou que deu tudo certo" |
| **2. Quebrou** | o roteiro simula operadores abrindo o painel por 1 minuto, conta os erros 500 e mostra a causa no log | celular: erro depois do login; Sentinela → **Incidentes** ("Erros internos na API"), **Segurança** com filtro "Erro interno da API" (a mensagem `nome_enc`), **Visão geral** ainda "No ar" |
| **3. Rollback** | `helm rollback` para a revisão da 1.0.0, com o tempo cronometrado | celular voltando a funcionar; `helm history` com a linha "Rollback to N" |
| **4. Correção 1.1.1** | upgrade para a versão corrigida | tela Alertas com a coluna "Titular do crachá"; no terminal, exemplos de alertas com o nome |

Os incidentes do Sentinela se resolvem sozinhos até 5 minutos depois do rollback, quando a janela de erros esvazia. A duração fica registrada na aba **Resolvidos**, e é um bom print para o relatório.

Para ver a situação a qualquer momento: `bash scripts/desastre-controlado.sh situacao prod`.

## Para o relatório

- **Print do `helm history`** no fim, com as revisões 1.0.0 → 1.1.0 → Rollback → 1.1.1. A coluna APP VERSION mostra cada versão.
- **Print do celular quebrado e do celular de volta.**
- **Prints do Sentinela:**
  - o incidente aberto;
  - a linha do tempo com o erro `nome_enc`;
  - o incidente resolvido com a duração.
- **Tempos**, que o roteiro mostra:
  - quanto o upgrade levou;
  - quanto tempo o sistema ficou quebrado (entre as etapas 1 e 3);
  - quanto o rollback levou.
- **Lições:**
  1. Sonda de saúde verde não garante que o sistema funciona; é preciso olhar erros e logs.
  2. Pular o pipeline custa caro: os testes teriam barrado a 1.1.0.
  3. O rollback do Helm é rápido porque as imagens anteriores continuam no registro.
  4. O rollback não desfaz banco nem Secrets.

## Se algo sair diferente

| Situação | O que fazer |
|---|---|
| "Release sa-prod não encontrada" | Rode na VM, depois do instalador. Confira com `helm list -A`. |
| O roteiro parou no meio (erro, queda do SSH) | Rode `bash scripts/desastre-controlado.sh situacao prod`. Se ficou na 1.1.0, volte com `helm rollback sa-prod -n secureaccess-prod` (sem número volta uma revisão) ou rode `executar` de novo, que recomeça da 1.0.0. |
| Upgrade para a 1.1.0 travou em "waiting" | Imagem não encontrada: rode `preparar` de novo com `REFAZER=1`. |
| Sentinela não abriu incidente | Confira a página Syslog (chegam mensagens `secureaccess`?). Os incidentes precisam de pelo menos 5 erros em 5 minutos; o roteiro gera cerca de 30. |
| Quer refazer tudo do zero | `bash scripts/desastre-controlado.sh executar prod`: ele volta sozinho para a revisão 1.0.0 mais recente. |
