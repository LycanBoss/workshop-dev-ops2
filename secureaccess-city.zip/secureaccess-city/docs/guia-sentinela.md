# Guia do Sentinela

O Sentinela é o monitoramento e o SIEM do SecureAccess City. Ele roda no mesmo cluster da aplicação, como um segundo chart Helm, e tem domínio próprio (`https://sentinela.<seu domínio>`). Faz quatro coisas:

1. **Recebe syslog** (UDP e TCP, RFC 5424 e RFC 3164): os eventos da API e os do servidor chegam a ele.
2. **Checa se o sistema está no ar** pelo domínio público, do mesmo jeito que um celular acessa: DNS, HTTPS, roteamento e aplicação.
3. **Acompanha a infraestrutura**: servidor (com um agente leve), Kubernetes (pods, nós, avisos, certificados) e as métricas da API.
4. **Abre incidentes** quando algo sai do normal, e opcionalmente avisa no celular pelo Telegram.

Nada de biblioteca externa no navegador nem serviço pago: é Python (Flask) com SQLite num volume persistente.

## O que é monitorado

| Área | O quê | Como |
|---|---|---|
| Disponibilidade | API (`/api/info`) e painel (`/login`) de produção e homologação; tempo de resposta; disponibilidade em 1 h, 24 h e 7 dias | requisição HTTPS a cada 30 s pelo domínio público |
| Certificado HTTPS | emissor, data de vencimento, dias restantes; certificados do cert-manager que não foram emitidos | conexão TLS a cada 30 min e leitura do cert-manager |
| Servidor | ficha (sistema, kernel, processador, núcleos, memória, disco, IP), CPU, memória em GB, disco em GB, carga, rede, processos | agente `sentinela-agente` (systemd) a cada 30 s |
| Segurança do servidor | logins SSH aceitos e recusados, usuários inexistentes, uso de `sudo`, processos mortos por falta de memória (OOM) | agente lendo o journal |
| Kubernetes | nó (pronto, pressões de memória e disco), todos os pods (situação, reinícios, CPU, memória), avisos (`BackOff`, `FailedScheduling`...) | API do Kubernetes, só leitura, a cada 20 s |
| Aplicação | banco respondendo, idade da chave JWT ativa (a rotação está acontecendo?), requisições e erros 5xx | métricas Prometheus da API (porta 9464) |
| SIEM | acessos liberados e negados (com motivo, porta e crachá), alertas de invasão, falhas de login no painel, contas bloqueadas, tokens rejeitados, rotações de chave, erros internos, deploys | syslog da API, repassado pelo rsyslog do servidor |

As 27 regras de incidente, com gravidade e limites, ficam na página **Incidentes** do próprio Sentinela. Exemplos: site fora do ar por 3 checagens seguidas, pod em `CrashLoopBackOff`, disco acima de 80%, rotação de chave JWT atrasada, força bruta no SSH (10 falhas do mesmo IP em 10 minutos), porta forçada registrada pela aplicação, syslog parado há 15 minutos.

## Como funciona

```mermaid
flowchart LR
  subgraph EC2["EC2 (Ubuntu + MicroK8s)"]
    subgraph APP["secureaccess-prod / secureaccess-staging"]
      A["API Node"]
    end
    R["rsyslog do servidor<br/>/var/log/secureaccess"]
    AG["sentinela-agente<br/>(systemd, sem root)"]
    subgraph SN["namespace sentinela"]
      S["Sentinela<br/>syslog :5514, painel, regras"]
      DB[("SQLite<br/>volume persistente")]
    end
    K["API do Kubernetes"]
    I["Traefik + HTTPS"]
  end
  CEL["Celular / navegador"]
  TG["Telegram (opcional)"]

  A -- "syslog UDP 514" --> R
  R -- "syslog TCP 30514 (com fila)" --> S
  AG -- "métricas, SSH, sudo, OOM<br/>syslog TCP 30514" --> S
  S -- "só leitura" --> K
  S -- "métricas :9464" --> A
  S -- "checa pelo domínio" --> I
  S --- DB
  CEL -- HTTPS --> I --> S
  S -. "incidentes" .-> TG
```

Por que no mesmo cluster: não tem custo extra, não precisa abrir porta nenhuma na AWS (o syslog chega pela rede interna do servidor), é instalado com Helm como o resto do projeto e tem acesso direto ao Kubernetes. A limitação está no fim deste guia.

## Colocar para rodar

O instalador da aplicação já faz tudo: o passo 9 sobe o Sentinela, liga o encaminhamento do rsyslog e instala o agente.

### 1. Atualizar o projeto no GitHub

No seu computador, substitua o `secureaccess-city.zip` no repositório `LycanBoss/workshop-dev-ops2` pela versão nova (pelo site do GitHub: abra o arquivo, **Delete file**, depois **Add file → Upload files**).

### 2. Trocar a pasta na VM

Os dados ficam no cluster, não na pasta, então pode apagar e baixar de novo sem perder nada:

```bash
cd ~
rm -rf secureaccess-city secureaccess-city.zip
wget -O secureaccess-city.zip https://github.com/LycanBoss/workshop-dev-ops2/raw/main/secureaccess-city.zip
unzip -q secureaccess-city.zip && cd secureaccess-city
```

### 3. Rodar o instalador

```bash
bash scripts/instalar-ec2.sh controledeacessoesuda.duckdns.org lycanrew03@gmail.com 2>&1 | tee ~/instalacao.log
```

O que muda em relação à instalação anterior:

- **Passo 4:** confere também `sentinela.controledeacessoesuda.duckdns.org`. O DuckDNS resolve qualquer subdomínio para o mesmo IP, então não precisa criar nada lá.
- **Passo 6:** o rsyslog passa a repassar os eventos para o Sentinela.
- **Passo 7:** gera e escaneia uma terceira imagem, `secureaccess-sentinela`.
- **Passo 8:** atualiza produção e homologação. A NetworkPolicy agora libera a porta de métricas da API para o namespace `sentinela`.
- **Passo 9:** instala o Sentinela com Helm, roda o `helm test` dele e instala o agente no servidor.

No fim, o quadro mostra os endereços e as senhas, inclusive as do Sentinela. Para ver só o final do log: `tail -40 ~/instalacao.log`.

Para subir só o Sentinela depois, sem refazer o resto:

```bash
bash scripts/deploy-sentinela.sh sentinela.controledeacessoesuda.duckdns.org \
  https://controledeacessoesuda.duckdns.org https://staging.controledeacessoesuda.duckdns.org
sudo bash agente/instalar-agente.sh "$(hostname -I | awk '{print $1}')"
```

### 4. Entrar

Abra **https://sentinela.controledeacessoesuda.duckdns.org**. O certificado leva 1 ou 2 minutos na primeira vez.

| Usuário | Perfil | Pode |
|---|---|---|
| `admin` | Administrador | tudo, inclusive marcar incidentes como "estou cuidando" e resolvidos |
| `avaliador` | Somente leitura | ver todas as páginas; bom para os avaliadores |

As senhas são geradas na instalação. Para ver de novo:

```bash
kubectl -n sentinela get secret sentinela-segredos -o jsonpath='{.data.SENTINELA_ADMIN_PASSWORD}' | base64 -d; echo
kubectl -n sentinela get secret sentinela-segredos -o jsonpath='{.data.SENTINELA_AVALIADOR_PASSWORD}' | base64 -d; echo
```

Cinco senhas erradas seguidas bloqueiam o usuário por 15 minutos, e cada tentativa vira evento na página Segurança.

## Conferir se está tudo funcionando

```bash
kubectl -n sentinela get pods,svc,certificate        # pod Running 1/1, certificado READY True
helm test sentinela -n sentinela --logs              # painel, banco e syslog TCP
systemctl status sentinela-agente --no-pager         # active (running)
logger --server "$(hostname -I | awk '{print $1}')" --port 30514 --tcp --rfc5424 -t teste "olá, Sentinela"
```

No painel:

- **Syslog:** aparecem as aplicações `secureaccess`, `sentinela-agente` e `teste`. A mensagem do `logger` deve estar lá.
- **Visão geral:** produção "No ar", com tempo de resposta, certificado, pods, banco e chave JWT preenchidos.
- **Infraestrutura:** ficha do servidor e lista de pods.
- **Segurança:** acessos negados e alertas das catracas simuladas chegando.

## Roteiro de demonstração

Cada item mostra uma parte diferente. Todos são seguros de fazer na frente dos avaliadores.

1. **SIEM ao vivo.** No SecureAccess de homologação, abra **Simulador** e dispare **Força bruta** e **Porta forçada**. Em segundos o Sentinela mostra os eventos na página Segurança, e a porta forçada vira incidente crítico.
2. **Site fora do ar.** Desligue o painel da homologação e espere cerca de 1,5 minuto:
   ```bash
   kubectl -n secureaccess-staging scale deploy sa-staging-web --replicas=0
   ```
   Aparece o incidente "Painel fora do ar (Homologação)". Ligue de novo (`--replicas=1`) e o incidente se resolve sozinho, com a duração registrada.
3. **Pod com problema.** Peça uma imagem que não existe:
   ```bash
   kubectl -n secureaccess-staging set image deploy/sa-staging-simulator simulator=localhost:32000/nao-existe:1
   ```
   Surge "Pod com falha (ImagePullBackOff)". Volte com `helm rollback sa-staging -n secureaccess-staging`, o que ainda serve de demonstração de rollback.
4. **Força bruta no SSH.** De outro computador, tente entrar 10 vezes com um usuário que não existe (`ssh teste@<IP público>`). O incidente mostra o IP de origem. Só funciona se a porta 22 estiver aberta para esse computador.
5. **Rotação de chave.** No SecureAccess, rotacione a chave JWT na tela Segurança. O evento aparece no Sentinela e a idade da chave na Visão geral volta a zero.

## Avisos no celular (opcional)

1. No Telegram, fale com **@BotFather**, mande `/newbot` e guarde o token.
2. Mande qualquer mensagem para o seu bot e abra `https://api.telegram.org/bot<TOKEN>/getUpdates` no navegador. O número em `"chat":{"id":...}` é o seu chat.
3. Na VM:
   ```bash
   TELEGRAM_TOKEN='123456:ABC...' TELEGRAM_CHAT='987654321' bash scripts/deploy-sentinela.sh \
     sentinela.controledeacessoesuda.duckdns.org https://controledeacessoesuda.duckdns.org \
     https://staging.controledeacessoesuda.duckdns.org
   ```

O token fica no Secret do Kubernetes, nunca no ConfigMap. Vão avisos de incidentes de gravidade alta e crítica, e de quando se resolvem, com limite de 30 por hora para não lotar o celular. A página Incidentes mostra se os avisos estão ligados.

## Segurança do próprio Sentinela

Pontos para o relatório:

- **Kubernetes:**
  - lê o cluster com uma ClusterRole só de leitura e sem acesso a Secrets: vê tudo, não altera nada e não lê senha nenhuma;
  - container sem root, sistema de arquivos somente leitura, sem capabilities, seccomp padrão;
  - grava só no volume `/data`.
- **Painel:**
  - senhas guardadas como hash scrypt em memória;
  - sessão com cookie `__Host-`, HttpOnly, Secure e SameSite=Strict;
  - token CSRF em todo POST;
  - CSP sem `unsafe-inline`, HSTS e bloqueio após 5 senhas erradas;
  - dois perfis (admin e somente leitura);
  - todo login e ação fica auditado.
- **Syslog:**
  - tamanho máximo por mensagem e por quadro TCP;
  - fila com limite: o excesso é descartado e contado, nunca trava;
  - até 64 conexões TCP;
  - lista opcional de redes permitidas (`syslog.origensPermitidas`);
  - a porta 30514 não é aberta na AWS.
- **Agente:**
  - roda com usuário dinâmico do systemd, sem root, só com o grupo `systemd-journal`;
  - sistema somente leitura (`ProtectSystem=strict`), sem privilégios novos;
  - limite de 96 MB de memória e 10% de CPU.
- **Pipeline:** a imagem passa pelo mesmo Trivy das outras e o `requirements.txt` entra no `pip-audit` e no Dependabot.

## Limitações (honestas)

- **Mesma máquina.** Se a EC2 inteira cair, o Sentinela cai junto e não consegue avisar. Para cobrir isso, um checador externo gratuito (UptimeRobot, por exemplo) apontando para o domínio, ou o Sentinela num segundo servidor, como era o plano original.
- **Histórico curto.** O syslog bruto fica 24 h, os eventos 7 dias e as medições 3 dias. É ajustável em `retencao.*` no chart.
- **Uma réplica.** O receptor de syslog e o SQLite têm um dono só. Para alta disponibilidade, o caminho seria um banco externo e um receptor por nó.

## Se algo não funcionar

| Sintoma | O que fazer |
|---|---|
| Página Syslog sem `secureaccess` | Veja se os eventos chegam ao servidor: `sudo tail /var/log/secureaccess/eventos.log`. Se chegam, confira o encaminhamento: `grep omfwd /etc/rsyslog.d/30-secureaccess.conf` e `sudo systemctl status rsyslog`. Plano B, a API mandando direto para o Sentinela: `helm upgrade sa-prod helm/secureaccess -n secureaccess-prod --reuse-values --set api.syslog.mode=host --set api.syslog.host=sentinela-syslog.sentinela.svc.cluster.local --set api.syslog.port=5514`. |
| Infraestrutura sem ficha do servidor | `sudo journalctl -u sentinela-agente -n 30`. Reinstale com `sudo bash agente/instalar-agente.sh <IP privado>`. |
| "Sem métricas da API" | O chart da aplicação precisa liberar o namespace `sentinela`: rode o instalador de novo ou `bash scripts/deploy.sh prod <domínio>`. |
| "Sentinela sem acesso ao Kubernetes" | `kubectl get clusterrolebinding \| grep sentinela` e `kubectl -n sentinela logs deploy/sentinela`. |
| Produção aparece "Fora do ar", mas o site abre no celular | O Sentinela checa pelo domínio. Confira se o IP do DuckDNS é o IP público atual da EC2 (ele muda ao parar e ligar a instância sem IP elástico). |
| Certificado do Sentinela não sai | `kubectl -n sentinela describe certificate sentinela-tls`. Confira se o domínio resolve para o IP público e se a porta 80 está aberta. |
| Pod `Pending` | `kubectl -n sentinela describe pod` (falta de memória ou volume). |
| Esqueci a senha | Veja os comandos da seção Entrar. Para gerar novas: `kubectl -n sentinela delete secret sentinela-segredos` e depois `bash scripts/deploy-sentinela.sh ...`. |

## Atualizar e remover

- **Atualizar:** rode o instalador de novo, ou `scripts/deploy-sentinela.sh` com uma `TAG` nova depois do build. Histórico, senhas e incidentes são preservados.
- **Remover:**
  ```bash
  helm uninstall sentinela -n sentinela
  sudo systemctl disable --now sentinela-agente
  ```
  O volume e o Secret ficam guardados de propósito (`helm.sh/resource-policy: keep`). Para apagar tudo: `kubectl delete namespace sentinela`.
