# Relatório técnico — Desafio 3: SecureAccess City

> Roteiro para o relatório entregue no repositório da disciplina. As seções marcadas com **[preencher]** dependem da equipe (prints, datas, divisão de tarefas). As demais já trazem o conteúdo técnico.

## 1. Objetivo

Implantar, de forma orquestrada com Helm no Kubernetes, uma aplicação de cidade inteligente com foco em DevSecOps: uma API que controla catracas e portas dos prédios públicos por crachá digital ou biometria, com gestão de segredos, análise de dependências e auditoria centralizada.

## 2. Arquitetura

- Infraestrutura: EC2 Ubuntu 24.04 (m7i-flex.large, 8 GB, 30 GB de disco) com IP elástico, MicroK8s, Traefik como ingress, cert-manager com Let's Encrypt e domínio DuckDNS.
- Aplicação: front em Python (Flask), API em Node.js, MySQL 8.4 em StatefulSet, simulador de catracas.
- Observabilidade: logs JSON coletados pelo Loki, métricas no Prometheus, painel no Grafana, e syslog (RFC 5424) para o rsyslog do nó.
- Ambientes: `secureaccess-staging` e `secureaccess-prod`, cada um uma release Helm do mesmo chart.

Diagrama: ver README. **[preencher: print do painel e do `kubectl get all`]**

## 3. Recursos do Kubernetes utilizados

| Recurso | Uso |
|---|---|
| Deployment | API, front e simulador, com RollingUpdate sem indisponibilidade |
| StatefulSet + PVC | MySQL com volume persistente (subchart) |
| Service | API (HTTP e métricas), front, MySQL (normal e headless) |
| Ingress + Middleware | HTTPS e redirecionamento HTTP → HTTPS no Traefik |
| Secret | senhas e chaves, gerado na instalação e preservado nos upgrades |
| ConfigMap | configuração não sensível por ambiente |
| NetworkPolicy | só a API fala com o banco; Prometheus só na porta de métricas |
| HorizontalPodAutoscaler + PDB | escala e disponibilidade em produção |
| ResourceQuota + LimitRange | limites de consumo por ambiente |
| ServiceMonitor | coleta das métricas da API |
| CronJob | backup do MySQL para o S3 (opcional) |
| Pod de teste (hook) | `helm test` de fumaça |

## 4. Estrutura do chart

- `templates/_helpers.tpl` concentra nomes, labels, imagem e endurecimento de segurança (blocos reutilizáveis via `include`).
- `range` gera a lista de segredos de cada contêiner, os HPAs/PDBs e as regras de NetworkPolicy.
- `if` liga e desliga simulador, ingress, redirecionamento, ServiceMonitor e backup; `.Capabilities.APIVersions.Has` só cria Middleware e ServiceMonitor se o cluster tiver essas CRDs.
- `lookup` reaproveita o Secret existente, e a anotação `helm.sh/resource-policy: keep` impede que `helm uninstall` apague as chaves.
- Anotações `checksum/config` e `checksum/secret` reiniciam os pods quando a configuração muda.
- Subchart `charts/mysql` declarado como dependência no `Chart.yaml`, com `condition: mysql.enabled` para trocar por um banco externo.
- `values-staging.yaml` e `values-prod.yaml` mudam só o que difere entre ambientes.

## 5. Comandos utilizados

**[preencher com as saídas reais; os principais estão abaixo]**

```bash
bash scripts/instalar-ec2.sh <dominio> <email>   # ou os passos manuais abaixo
microk8s enable hostpath-storage ingress metrics-server cert-manager dashboard registry
bash scripts/build-local.sh 1.0.0
bash scripts/deploy.sh staging staging.<dominio> 1.0.0
bash scripts/deploy.sh prod <dominio> 1.0.0
helm test sa-prod -n secureaccess-prod
helm upgrade sa-staging ./helm/secureaccess -n secureaccess-staging --reuse-values --set api.jwt.rotationIntervalSeconds=300
helm history sa-staging -n secureaccess-staging
helm rollback sa-staging -n secureaccess-staging
```

## 6. Resultados

**[preencher: prints do painel no celular, do `helm history`, do Grafana com alertas, do pipeline e do SBOM]**

Testes automatizados: 18 testes de integração da API e 13 do front, cobrindo regras de acesso, detecção de ataques, rotação de chave, perfis, CSRF, cabeçalhos de segurança e escape de dados.

## 7. Problemas encontrados e soluções

| Problema | Causa | Solução |
|---|---|---|
| `microk8s status` falhava com traceback | instância t3.micro com 908 MB de RAM; o MicroK8s não ficava de pé | trocar para m7i-flex.large (8 GB) e aumentar o disco para 30 GB |
| `kubectl` tentava `localhost:8080` | havia um kubectl instalado como snap próprio, sem configuração | `microk8s config > ~/.kube/config` |
| Ingress de teste sem endereço e ignorado | classe criada com nome inexistente; o addon do MicroK8s usa Traefik | recriar com `--class=traefik` |
| Página abria na VM (`curl` 200) mas não no celular | grupo de segurança sem as portas 80 e 443 | liberar HTTP/HTTPS para qualquer IPv4 e SSH só para o IP do operador |
| Risco de perder os dados cifrados num `helm uninstall` | o Secret com as chaves seria apagado junto | `lookup` para reaproveitar valores e `helm.sh/resource-policy: keep` |
| Rotação de chave com 2 réplicas da API | as duas poderiam rotacionar ao mesmo tempo | trava nomeada do MySQL (`GET_LOCK`); só uma rotaciona e a outra recarrega |
| Base de vulnerabilidades do Trivy não baixava (`BLOB_UNKNOWN` no mirror.gcr.io) | espelho padrão da base com um arquivo faltando | o build baixa a base uma vez, tentando três espelhos em sequência (ECR Public, mirror.gcr.io, GHCR), e os scans usam `--skip-db-update` |
| O próprio scanner de segurança foi alvo de ataque | em março de 2026 versões do Trivy e tags do trivy-action foram adulteradas (CVE-2026-33634) | versão do Trivy fixada na 0.69.3 e trivy-action na 0.35.0, as indicadas como seguras pela Aqua; nunca usar `latest` |
| Domínio passado com `https://` e barra final | o instalador usava o texto como veio | o instalador limpa e valida o domínio antes de usar |
| IP público mudou depois de parar e ligar a instância | a EC2 estava sem IP elástico | associar um IP elástico e atualizar o DuckDNS |
| Trivy barrou o build antes de gerar a imagem | `certifi` 2026.7.22, usado pelo front em Python, trazia raízes da emSign cujas chaves intermediárias foram comprometidas (GHSA-6q48-6c7w-9gw2, crítica) | dependência atualizada para 2026.10.19, a versão corrigida que o próprio Trivy indicou; scan repetido até passar. Prova de que o portão de segurança do pipeline funciona |
| `helm test --logs` acusava erro mesmo com o teste aprovado (`pods "sa-prod-smoke-test" not found`) | a política `hook-succeeded` apagava o pod de teste assim que ele passava, antes de o Helm ler os logs; com `set -e`, o instalador parava antes da homologação | política de remoção só `before-hook-creation`: o pod fica guardado até o próximo teste |
| **[preencher]** | | |

## 8. Aprendizados

**[preencher com a análise da equipe]** Sugestões de pontos: diferença entre recurso da VM e limite do pod; por que segredos não vão no `values.yaml`; o que o rollback do Helm desfaz e o que não desfaz (dados e Secret); custo de dependências na superfície de ataque; logs estruturados como base de um SIEM.

## 9. Divisão de tarefas

**[preencher]**
